Old version not yet available in this project
See setup.txt to use project

//README.txt

Pour compiler:
javac *.java

Pour Executer :
java -cp .:/usr/share/java/mysql.jar processor.QS

La version actuelle utilise comme évaluateur mysql
Il faut donc avoir une BD avec un user et un mot de passe a donner dans les trois variables
		String dataBase = "test";
		String user = "berlin";
		String mdp = "berlin";

Un exemple de création de base de donnée mysql est donné dans le repertoire Examples/Prof
Fichier DataBase.sql
Pour l'exécuter dans mysql, après s'etre connecté : source DataBase.sql

Les sous répertoires Berlin1 Paper Paper2 et Prof contiennent des exemple traités avce mysql

		
Pour fonctionner il y a besoin de 7 fichiers dans le sous répertoire donné dans la variable :
		String directory = "Examples/Prof/";

Les fichiers :

KeyConstraint.dlp  // les contraintes de clé
PosConstraint.dlp  // les contraintes positives
NegConstraint.dlp  // les contraintes négatives
infRulesSet.dlp	   // les règles d'inférences
queriesSet.dlp     // les requêtes (seul la première est évaluée)
processor.ArrayListSchema.dlp         // le schéma de la BD
SchemaSparql.dlp   // le schéma version sparql de la BD


