package processor.algebra

/**
 * Created with IntelliJ IDEA.
 * User: luizcelso
 * Date: 12/26/12
 * Time: 4:20 PM
 * To change this template use File | Settings | File Templates.
 */
class Constants {
    final static String OUTBOUND = 'OUTBOUND' //direction for in* and SA
    final static String INBOUND = 'INBOUND'  //direction for in* and SA
    final static String BOTH = 'BOTH'     //direction for in* and SA
}
