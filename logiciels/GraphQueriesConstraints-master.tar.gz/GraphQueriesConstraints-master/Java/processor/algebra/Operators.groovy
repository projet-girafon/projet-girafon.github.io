package processor.algebra


/**
 * Created with IntelliJ IDEA.
 * User: luizcelso
 * Date: 2/4/15
 * Time: 12:28 PM
 * To change this template use File | Settings | File Templates.
 */
class Operators {
    GroovyShell sh = new GroovyShell()

    public Relation select (Relation t, Closure condition){
        Relation t2 = new Relation()
        for (row in t){
            //println("row ",row);
            if (condition(row)) t2.addRow(row)
        }
        return t2
    }

    public Relation select (Relation t, String condition){
        Closure c = this.sh.evaluate("{it -> " + condition + "}")
        //println("In relation ");
        //t.print();
        //print(" with condition "+condition);
        //println("{it -> " + condition + "}")
        //print(" closure : ",c);
        Relation t2=select(t, c);
        //println(" Result size"+t2.getSize());
        return t2;
    }


    /**
     * Projects the columns in a list of indices
     * @param relation Input Relation
     * @param columns Indices of the columns to be projected 
     * @return New relation
     */
    Relation project (Relation relation, List columns){
        if (!columns || relation.size == 0) return relation
        assert columns.every{it < relation.getArity()}, "Wooops, relation arity (${relation.getArity()}) smaller than some index to project (${columns})"
        Relation tOut = new Relation()
        List newRow
        for (row in relation) {
            newRow = []
            for (int i in 0..columns.size()-1) newRow[i] = row[columns[i]]
            tOut.addRow(newRow)
        }
        return tOut
    }

    /**
     * Projects the columns in a list of
     * @param relation Input Relation
     * @param columns Attribute names of the columns to be projected
     * @return New relation
     */
    Relation projectWithSchema (Relation t, List columns){
        if (!columns) return t
        assert t.getSchema().containsAll(columns), "Wooops, table schema does not contain all attributes to project"
        Relation tOut = new Relation()
        Map newRow
        for (row in t) {
            newRow = [:]
            for (c in columns) newRow[c] = row[c]
            tOut.addRow(newRow)
        }
        return tOut
    }

    Relation step(Relation V, Relation E, direction){
        //TODO: filter labels (add parameter)
        assert "id" in V.getSchema(), "First table must have an 'id' column"

        assert "id" in E.getSchema(), "Second table must have an 'id' column"
        assert "id_n" in E.getSchema(), "Second table must have an 'id_n' column"

        Relation tOut = new Relation()
        Relation vIn

        if ("id_n" in V.getSchema()) vIn = V.copy()
        else    vIn = set(V, ["it.id_n = it.id"])



        if (direction == Constants.INBOUND) tOut =  stepIn(vIn, E, [])
        else if (direction == Constants.OUTBOUND) tOut =  stepOut(vIn, E, [])
        else if (direction == Constants.BOTH) tOut =  union(stepIn(vIn, E, []), stepOut(vIn, E, []))


/*        for (v in V){
            for (e in E){
                if ((v.id_n == e.id_n) && (direction != Constants.OUTBOUND)){  //BOTH or INBOUND
                    def newW = e.clone()
                    newW.id_n = newW.id
                    newW.remove('id')
                    tOut.addRow(v.clone().plus(newW))

                }
                else if ((v.id_n == e.id) && (direction != Constants.INBOUND)){  //BOTH or OUTBOUND
                    def newW = e.clone()
                    newW.remove('id')
                    tOut.addRow(v.clone().plus(newW))

                }
            }
        }   */

        return tOut
    }

    Relation set (t, List setFunctions){
        //setup and execute set functions
        Relation tOut = new Relation()
        List setClosures = []
        for (f in setFunctions) setClosures.add(this.sh.evaluate("{it -> " + f + "}"))
        for (row in t) {
            setClosures.each{it(row)}
            tOut.addRow(row)
        }
        return tOut

    }

    Relation map (t, List mapFunctions){
        if (!mapFunctions) return t
        //setup and execute set functions
        Relation tOut = new Relation()
        List mapClosures = []
        for (f in mapFunctions) mapClosures.add(this.sh.evaluate("{it -> " + f + "}"))

        Relation tCount = reduce(t, ["id"], [[aggr:"sum", func:"1", as:"c"]])
        tCount = projectWithSchema(set(tCount, ["it.idCount = it.id"]), ["idCount", "c"])
        t = tetaJoin(t, tCount, {it.id == it.idCount})

        for (row in t) {
            mapClosures.each{it(row)}
            tOut.addRow(row)
        }
        return tOut
    }

    Relation stepOut(Relation V, Relation E, def follow = [], String newIdName = "id_n"){
        Relation tOut = new Relation()

        //E = rename(E, [["id", "E_id"], ["id_n", "E_id_n"]])
        E = renameAll(E, "E", "")

        tOut =  tetaJoin(V, E, {it.id_n == it.E_id})
        tOut = rename(tOut, [["E_id_n", newIdName]])

        return tOut

    }

    Relation stepIn(Relation V, Relation E, def follow = [], String newIdName = "id_n"){
        Relation tOut = new Relation()

        //E = rename(E, [["id", "E_id"], ["id_n", "E_id_n"]])
        E = renameAll(E, "E", "")

        tOut =  tetaJoin(V, E, {it.id_n == it.E_id_n})
        tOut = rename(tOut, [["E_id", newIdName]])

        return tOut

    }

    Relation stepMap(Relation R, Relation E, Relation V, Object direction, Object follow = [], List mapFunctions){
        //TODO: filter labels (add parameter)
        assert "id" in R.getSchema(), "First table must have an 'id' column"
        assert "id" in E.getSchema(), "Second table must have an 'id' column"
        assert "id_n" in E.getSchema(), "Second table must have an 'id_n' column"

        Relation tOut = new Relation()
        Relation t = new Relation()
        //V.print()


        if (!("id_n" in R.getSchema())) R = set(R, ["it.id_n = it.id"])

        R = set(R, ["it.id_old = it.id_n"])

        if (direction == Constants.INBOUND) t =  stepIn(R, E, [], "newId")
        else if (direction == Constants.OUTBOUND) t =  stepOut(R, E, [], "newId")
        else if (direction == Constants.BOTH) t =  union(stepIn(R, E, [], "newId"), stepOut(R, E, [], "newId"))

        if (V.getSize()>0) {
            V = renameAll(V, "V", "")
            t = tetaJoin(t, V, {it.newId == it.V_id})
        }

        //t.print()

        List mapClosures = []
        for (f in mapFunctions) mapClosures.add(this.sh.evaluate("{it -> " + f + "}"))

        Relation tCount = reduce(t, ["id_old"], [[aggr:"sum", func:"1", as:"c"]])
        tCount = projectWithSchema(set(tCount, ["it.idCount = it.id_old"]), ["idCount", "c"])
        //tCount.print()

        t = tetaJoin(t, tCount, {it.id_old == it.idCount})
        //t.print()

        for (row in t) {
            mapClosures.each{it(row)}
            tOut.addRow(row)
        }

        tOut = rename(tOut, [["newId", "id_n"]])
        //tOut.print()

        return tOut

    }

    //public Relation beta (Relation t, Integer n, Closure condition, direction, follow, List set, List mapFunctions, List reduceFunctions, List updateFunctions) {}

    public Relation beta (Relation t, Relation e, Relation v, Integer n, Closure condition, Object direction, Object follow, List setFunctions, List mapFunctions, List reduceGroupBy, List reduceFunctions, List updateFunctions, List stopConditions = []) {
        //TODO: check schemas
        //TODO: check arguments
        if (n < 1) return t

        //Relation tOut = new Relation()
        Relation tNew = t.copy()
        tNew = set(tNew, ['it.id_n = it.id'])


        if (setFunctions) tNew = set(tNew, setFunctions)
        Relation tOut = tNew

        Integer i = 0
        while (i++ < n){
            //tNew.print()
            tNew = stepMap(tNew, e, v, direction, follow, mapFunctions)
            //tNew.print()

            //if (reduceFunctions) tNew = reduce(tNew, reduceGroupBy, reduceFunctions )
            if (reduceGroupBy) tNew = reduce(tNew, reduceGroupBy, reduceFunctions )
            //tNew.print()

            if (updateFunctions) tOut = update(tOut, tNew, reduceGroupBy, updateFunctions)
            else tOut = tNew
            //tOut.print()

            if (stopConditions) for (c in stopConditions){
                def test = c[0]
                if (tOut."$test"(c[1])) {
                    println i
                    return tOut
                }
            }
        }

        return tOut

    }



    Relation reduce(Relation t, List group, List <Map> reduceFunctionsIn){
        //aggregation example:
        // [aggr:"min", func:"it.dist", as:"minDist"]

        if (! t.getSize()) return t

        Relation tOut = new Relation()

        t.orderAsc(group)

        List postClosures = [] //closures that do no aggregate (workaround)

        List <Map> reduceFunctions = []
        //setup reduce functions
        for (f in reduceFunctionsIn) {
            if (f.aggr == 'post'){//not to be run during grouping (workaround since we don't have expr parsing)
                postClosures.add(f.func)
            }else{
                f.closure = this.sh.evaluate("{it -> " + f.func + "}")
                f.group = []
                reduceFunctions.add(f)

            }
        }

        def i = 0
        def cRow = t.getRowAt(0)
        for (row in t){

            if (!(group.every{row[it] == cRow[it]}) ) {
                //for (row in t) setClosures.each{it(row)}
                for (f in reduceFunctions) {
                    cRow[f.as] = (f.group."${f.aggr}"())
                    //if (!cRow[f.as]) cRow[f.as] = 0 // in case previous returns null
                    f.group = []
                }
                tOut.addRow(cRow)
                cRow = row

            }

            for (f in reduceFunctions) f.group.add( f.closure(row))
        }

        //execute for the last row
        for (f in reduceFunctions)
            cRow[f.as] = (f.group."${f.aggr}"())
        tOut.addRow(cRow)

        if (postClosures) tOut = set(tOut, postClosures)


        return tOut
    }

    Relation aggregate(Relation t, String ids, String variable, String function, String parameter){
        //return reduce(t, ids.split(','), [[aggr:function, func:"it.$parameter", as:variable]]);
        return reduce(t,ids.split(',')*.trim(), [[aggr:function, func:"it.\"$parameter\"", as:variable]]);
    }

    Relation aggregate(Relation t, Map m){
        //return reduce(t, ids.split(','), [[aggr:function, func:"it.$parameter", as:variable]]);
        def ids = m.ids
        def variable = m.variable
        def function = m.function
        def parameter = m.parameter
        return reduce(t,ids, [[aggr:function, func:"it[$parameter]", as:variable]]);
    }

    public Relation update(Relation oldT, Relation newT, List group, List updateFunctions){
        //TODO: asset it has a group and functions
        if (!updateFunctions) return t
        //setup and execute set functions
        Relation tOut = new Relation()
        List updateClosures = []
        for (f in updateFunctions) updateClosures.add(this.sh.evaluate("{current, newV -> " + f + "}"))

        for (rOld in oldT){
            def addedO = false
            for (rNew in newT){
                if (group.every{rOld."$it" == rNew."$it"}){
                    //Map newRow = rOld
                    updateClosures.each{it(rOld, rNew)}
                    tOut.addRow(rOld)
                    addedO = true
                }
            }
            if (!addedO) tOut.addRow(rOld)
        }

        //another pass to complete the full join
        for (rNew in newT){
            def addedO = false
            for (rOld in oldT){
                if (group.every{rOld."$it" == rNew."$it"}){
                    addedO = true
                }
            }
            if (!addedO) tOut.addRow(rNew)
        }

        return tOut
    }


    public Relation rename(Relation t, List renamings){
        Relation tOut = new Relation()
        for (r in renamings) {
            assert (r.size()==2 && r[0]!=r[1]), "Wooops, $r is not a valid attribute renaming."
            assert (t.getSchema().contains(r[0])), "Wooooops, cannot rename ${r[0]} because it doesn't exist!"
        }

        for (row in t) {
            for (r in renamings){
                row[r[1]] = row[r[0]]
                row.remove(r[0])
            }
            tOut.addRow(row)
        }
        return tOut
    }

    public Relation renameAll(Relation t, String prefix, String suffix = ""){
        Relation tOut = new Relation()
        Map newRow
        for (row in t) {
            newRow = [:]
            for (a in row){
                def newName = a.key
                if (prefix) newName = prefix + "_" + newName
                if (suffix) newName = newName + "_" + suffix
                newRow[newName] = a.value
            }
            tOut.addRow(newRow)
        }
        return tOut
    }

    public Relation tetaJoin(Relation A, Relation B, Closure condition){
        Relation tOut = new Relation()
        for (rA in A)
            for (rB in B){
                List newRow = rA.plus(rB)
                if (condition(newRow)) tOut.addRow(newRow)
            }
        return tOut
    }

    public Relation tetaLeftJoin(Relation A, Relation B, Closure condition){
        Relation tOut = new Relation()
        for (rA in A){
            def added = false
            for (rB in B){
                List newRow = rA.plus(rB)
                if (condition(newRow)) {
                    tOut.addRow(newRow)
                    added = true
                }

            }
            if (!added) tOut.addRow(rA)
        }
        return tOut
    }

    public union (Relation t1, Relation t2){
        Relation tOut = t1.copy()
        for (row in t2) tOut.addRow(row)
        return tOut
    }

    public unique (Relation t){

        return t.unique()
    }

    Relation reduceDeprecated(Relation t, List <Map> reduceFunctions){
        //aggregation example:
        // [aggr:"min", func:"it.dist", as:"minDist"]

        Relation tOut = new Relation()

        if (! t.getSize()) return t
                print("Test de la relation "+negbInst.getName()+ " avec la condition : "+condi);

        t.orderAsc('id_n')

        //setup reduce functions
        for (f in reduceFunctions) {
            f.closure = this.sh.evaluate("{it -> " + f.func + "}")
            f.group = []
        }

        def i = 0
        def cRow = t.getRowAt(0)
        t.each{

            if ((it.id_n != cRow.id_n) ) { //|| (! t.iterator().hasNext())
                //for (row in t) setClosures.each{it(row)}
                for (f in reduceFunctions) {
                    cRow[f.as] = (f.group."${f.aggr}"())
                    f.group = []
                }
                tOut.addRow(cRow)
                cRow = it

            }

            for (f in reduceFunctions) f.group.add( f.closure(it))
        }

        //execute for the last row
        for (f in reduceFunctions)
            cRow[f.as] = (f.group."${f.aggr}"())
        tOut.addRow(cRow)


        return tOut
    }

}
