package processor.algebra

import processor.LinkedListRules

/**
 * Created with IntelliJ IDEA.
 * User: luizcelso
 * Date: 2/2/15
 * Time: 8:27 PM
 * To change this template use File | Settings | File Templates.
 */

/**
 * Relation class stores facts as lists of values. A relation has a schema (which should not be useful for reasoning).
 */
class Relation implements Iterable{
    private List <List> contents = [] //list of facts
    private schema = [] //list with attribute names
    Integer size = 0 //number of facts stored

    Relation(){}

    Relation(List schema){
        this.schema = schema
    }

    Relation(List schema, List <List> t){
        //assert t.size() > 0, "Wooops, can't create table from empty list"
        this.schema = schema
        for (r in t){
            assert r.size() == this.getSchema().size(), "Woops, row size ($r.size()) is different from schema (${this.getSchema().size()}) size"
            this.addRow(r)
        }
    }

    Relation(List sch, LinkedListRules rules){
        assert rules.size() > 0, "Wooops, can't create table from empty list"
        this.schema = sch
        for (r in rules){
            List newRow = []
            int i = 0
            for (t in r.getHead().getTuple()) {
                newRow[i++] = t.name
            }

            this.addRow(newRow)
        }
    }

    List getSchema(){
        //if there is no schema but has rows, return a schema that is the list of positions for the size of the row
        if (this.schema.isEmpty() && !this.contents.isEmpty()) return (0..this.contents[0].size()-1);
        return this.schema;
    }

    def addRow(List row){
        this.contents.add(row.clone())
        this.size++
    }

    Integer getSize(){return this.size}

    Integer getArity(){return this.getSchema().size()}

    // add Jac 9/03/2017
    def addAll(Relation r2){
        //assert this.schema.equals(r2.schema), "addAll in Relation with distinct schema";
        for(r in r2.contents){
            addRow(r);
        }
    }

    Relation unique(){
        return new Relation(this.getSchema(), this.contents.unique() as List <List>)
    }

    def orderAsc(column) {
        this.contents.sort{a,b -> a[column] <=> b[column]}
    }

    def orderAsc(List attributes) {
        for (attr in attributes.reverse())
            this.contents.sort{a,b -> a[attr] <=> b[attr]}
    }

    def orderDesc(column) {
        this.contents.sort{a,b -> b[column] <=> a[column]}
    }

    def orderDesc(List attributes) {
        for (attr in attributes.reverse())
            this.contents.sort{a,b -> b[attr] <=> a[attr]}
    }

    List getRowAt(Integer index){
        return this.contents[index].clone()
    }

    List getRawContents(){
        return this.contents
    }

    Relation copy() {
        Relation clone= new Relation();
        //TODO: clone of a clone
        this.contents.each{clone.addRow(it)}

        return clone;
    }

    Boolean testEvery(Closure test){
        return this.contents.every(test)
    }

    Boolean testAny(Closure test){
        return this.contents.any(test)
    }


    def print(int count = 0){
        println "XXXXXXX relation XXXXXXXXX"
        println this.getSchema()

        if (!this.size) {
            println "XXXXXXX 0 rows XXXXXXXXX"
            return
        }

        if ((count < 1) || (count > this.size)) count = this.size

        for (row in this.contents[0..(count-1)]){
            //println this.schema.collect{(row[it] == null)?"<null>":(row[it].class == String)?"'" + row[it] + "'":(row[it].class == Double)?String.format("%1\$,.2f", row[it]):row[it]}
            println([0..(this.schema.size() -1)].collect{(row[it] == null)?"<null>":(row[it].class == String)?"'" + row[it] + "'":(row[it].class == Double)?String.format("%1\$,.2f", row[it]):row[it]})
        }
        println "XXXXXXX ${this.size} rows XXXXXXXXX"
    }

    void removeAll(){
        contents = [] //list of facts
        size = 0
    }

    @Override
    Iterator iterator() {
        Integer counter = 0
        [hasNext: { counter < this.size },
                next: { counter++;return this.contents[counter -1].clone() }] as Iterator
    }

}
