package processor

import processor.algebra.Operators
import processor.algebra.Relation

/**
 * Created by luizcelso on 09/01/17.
 */
class MemoryProcessor implements Processor {
    protected LinkedListRules keyConstraintsSet, posConstraintsSet, negConstraintsSet, infRulesSet;
    ArrayListSchema sch, schSp;
    public Map <String, Relation> db = [:];
    GroovyShell sh = new GroovyShell();
    Operators basicOpr = new Operators();
    Relation lastResult;
    static int verbose =2;

    public Relation processQuery(Query q, AssignExpression assignExpr){

        println("XXXXXXXXXXXXXXXXXXXXX query to process "+q+ " with AssExpr : "+ assignExpr);
        // apply algo 1 here on q
        int ncpb = q.algo1(posConstraintsSet, negConstraintsSet);
        if(verbose>0) System.out.println("query after algo1 : " + q);
        if(ncpb != -1){
            if(verbose>2) System.out.println("STOP  query maps the negative constraint number  " + ncpb);
            return;
        }
        else{
            if(verbose>2) System.out.println("No problem with negative constraints");
        }

        String headName = q.getHead().getName().replace('?','');
        ArrayList<Element> tupleHead = q.getHead().getTuple();
        Relation resp;

        if (headName in q.getBody().collect{it.getName()})
            resp = this.processRecursiveQuery(q, assignExpr);
        else resp = this.processSimpleQuery(q, assignExpr);

        if(headName in this.db) {
            if(resp != this.db[headName]) resp.addAll(this.db[headName]);
        }
        this.db[headName] = resp;
        if(verbose>1) {
            println("Relation : " + headName);
            resp.print();
        }
        this.lastResult = resp;
        return resp;

    }

    Relation processRecursiveQuery(Query q, AssignExpression assignExpr) {
        String headName = q.getHead().getName().replace('?','');
        ArrayList<Element> tuple;
        Relation resp, respTemp;
        respTemp = this.db[headName];
        int i
        while (true) {

            resp = respTemp.copy(); //TODO: probably doesn't need the resp variable..
            this.db[headName] = resp;

            (respTemp, tuple) = this.processQueryBody(q.getBody(), assignExpr); //not easily translated to java. the best would be to implement relation with the elements as a schema

            // add to take account constraints
            respTemp = this.processValidator(respTemp, tuple, q);

            ArrayList<Element> tupleHead = q.getHead().getTuple();
            respTemp = this.processProjections(respTemp, tuple, tupleHead);
            respTemp = this.basicOpr.union(respTemp, resp);
            respTemp = respTemp.unique();

            println "processing iteration ${i+1}..."

            if (respTemp.size == resp.size) break;
            if (i++>3) {
                println "IMPORTANT: Stopped after 5 recursive calls.";
                break;
            }
        }
        return resp;
    }




    public Relation processSimpleQuery(Query q, AssignExpression assignExpr){
        String headName = q.getHead().getName().replace('?','');
        ArrayList<Element> tuple;
        Relation resp;
        (resp, tuple) = this.processQueryBody(q.getBody(), assignExpr); //not easily translated to java

        // add to take account constraints
        resp = this.processValidator(resp, tuple, q);

        ArrayList<Element> tupleHead = q.getHead().getTuple();
        resp = this.processProjections(resp, tuple, tupleHead);
        resp = resp.unique();

 
        return resp;
    }

    Relation processValidator(Relation relation, ArrayList<Element> elements, Query q) {

        Relation validAnswer = new Relation();
        // For each solution
        int j = 0;
        while(j<relation.getSize()) {
            List l = relation.getRowAt(j);
            // substitution from this solution
            Substitution subst = new Substitution();
            //Variable var;
            int ind = 0;
            for (Element var in elements) {
                String str = l.get(ind).toString();
                subst.putValue(var as Variable, new Constant(str));
                ind++;
            }
            //print("La substitution de la solution " + subst);

            // instancied query with substitution
            Query qInst = subst.applySub(q);
            LinkedListRules newQueries = qInst.algo2(negConstraintsSet, keyConstraintsSet, posConstraintsSet);
            //println("\n\n For the answer : " + qInst);
            //println("Queries to check  " + newQueries);
            int nbq=0;
            boolean valid = true;
            while(nbq<newQueries.size() && valid){
                Query qc = newQueries.get(nbq);
                Atome negbInst = qc.getBody().get(0);
                String condi="";
                int pos=0;
                for(Element el in negbInst.getTuple()){
                    if(el.isConstant()){
                        if(condi.length()!=0) condi += " && "
                        condi +="it["+pos+"]=="+"'"+el+"'";
                    }
                    pos++;
                }
                // if two atoms in the query (sub-query for key constraint)
                if(qc.getBody().size()==2){
                    Atome neq = qc.getBody().get(1);
                    // second atom must by NotEqual
                    assert neq.getName()=="NotEqual", "Invalid predicate ${neq.getName()}. Not NotEqual.";
                    Element ec=neq.getTuple().get(0);
                    Element ev=neq.getTuple().get(1);
                    if(ec.isVariable()){
                        Element eaux=ec;
                        ec=ev;
                        ev=eaux;
                    }
                    // find position of variable ev in negbInst
                    pos = 0
                    Element el = negbInst.getTuple().get(pos);
                    while(el.getName() != ev.getName()){
                        pos+=1;
                        el = negbInst.getTuple().get(pos);
                    }
                    condi +=" && it["+pos+"]!="+ec;
                }
                Relation result= new Relation();
                //print("Test de la relation "+negbInst.getName()+ " avec la condition : "+condi);
                result = this.basicOpr.select(this.db[negbInst.getName()], condi)
                if(result.getSize() >0){
                    print("Test de la relation "+negbInst.getName()+ " avec la condition : "+condi);
                    println(" is not valide because "+ qc + " has solution in IDB");
                    valid = false;
                }
                else{
                    //println(" is valid ");
                    nbq++
                }
            }
            if(valid){
                validAnswer.addRow(l);
            }
            j++;
        }
        return validAnswer;
    }

/**
     * Processes a conjunctive query
     * @param atomes: list of atoms to join
     * @return returns two values (a tuple with two values): the result relation (result of the join) and the list of elements corresponding to the new relation (concatenation of the elements in the atoms).
     */
    def processQueryBody(ArrayList<Atome> atomes, AssignExpression assignExpr) {
        Queue<Atome> queue = new LinkedList<>(atomes.asList());  //queue of atoms to process
        Atome atom1 = queue.remove(); //first atom to process, first in the queue
        Atome atom2;
        ArrayList<Element> tuple1, tuple2; //tuple1 are the elements of the current processing relation
        tuple1 = atom1.getTuple().clone();

        assert this.db.containsKey(atom1.getName()), "Invalid predicate ${atom1.getName()}. Not IDB nor EDB."
        Relation rel1 = this.db[atom1.getName()]; //base relation

        rel1 = this.processSelections(rel1, tuple1);

        while (queue.size()){  //while there are relations to join (atoms in the queue)
            atom2 = queue.remove();
            assert this.db.containsKey(atom2.getName()), "Invalid predicate ${atom2.getName()}. Not IDB nor EDB."
            Relation rel2 = this.db[atom2.getName()]; //second relation to be joined
            tuple2 = atom2.getTuple();
            rel2 = this.processSelections(rel2, tuple2);
            rel1 = this.processJoin(rel1, tuple1, rel2, tuple2);
            tuple1.addAll(tuple2); //tuple of the processed relation must be completed with the tuple of the last relation joined
        }


        //if there is an assigment expression to process
        if (assignExpr != null){
            if(verbose>2){System.out.print(" tuple1 : "+tuple1+ " et rel1 :"); rel1.print();}
            (rel1, tuple1) = this.processAssignExpr(rel1, tuple1, assignExpr);
        }

        return [rel1,tuple1];

    }

    List processAssignExpr(Relation relation, ArrayList<Element> tuple, AssignExpression assignExpression) {
        String expr = assignExpression.getExpression();
        for (int i in (0..tuple.size()-1)){
            if (tuple[i].isVariable()){
                expr = expr.replaceAll("\\["+tuple[i].getName()+"\\]", '['+i.toString()+']');
            }
        }

        tuple.add(new Variable(assignExpression.getVariable()));//adds the assignment variable as an element of the tuple

        expr = "it[" + (tuple.size() - 1) + "]=" + expr;

        relation = this.basicOpr.set(relation, [expr]);
        return [relation, tuple]
    }

    Relation processProjections(Relation relation, ArrayList<Element> tuple, ArrayList<Element> tupleHead) {
        ArrayList<Integer> columns = new ArrayList<>();
        for (int i in (0..tupleHead.size()-1)){ //for all elements in tupleHead
            if (tupleHead[i].isVariable()){
                for (int j in (0..tuple.size()-1)){ //for all elements in tuple
                    if (tuple[j].isVariable() && tuple[j].isEqual(tupleHead[i])) { //if they share a variable in the position i,j, add i to the columns to project
                        columns.add(j);
                        break; //if added a column, break for to process the next element in tupleHead
                    }
                }
            }
        }
        if (columns.isEmpty()) return new Relation();
        return this.basicOpr.project(relation, columns);
    }

    Relation processJoin(Relation rel1, ArrayList<Element> tuple1, Relation rel2, ArrayList<Element> tuple2) {
        String conditions = "";
        for (int i in (0..tuple2.size()-1)){ //for all elements in tuple2
            if (tuple2[i].isVariable()){
                for (int j in (0..tuple1.size()-1)){ //for all elements in tuple 1
                    if (tuple1[j].isVariable() && tuple1[j].isEqual(tuple2[i])) { //if they share a variable in the position i,j, add it to the condition that will be used to join the relations
                        conditions += "&& it[$j]==it[${tuple1.size()+i}]";
                    }
                }
            }
        }
        if (conditions.isEmpty()) conditions = "true" else conditions = conditions[3..conditions.size()-1]; //if there is no common variables, join condition is true. otherwise, remove extra &&
        Closure c = this.sh.evaluate("{it -> " + conditions + "}")
        
        return this.basicOpr.tetaJoin(rel1, rel2, c);
        
    }

    private Relation processSelections(Relation relation, ArrayList<Element> tuple) {
        String conditions = "";
        for (int i in (0..tuple.size()-1)){ //for all elements in tuple2
            if (tuple[i].isConstant()){
                String value;
                Class valueClass = (tuple[i] as Constant).getValue().getClass();
                switch (valueClass){
                    case String:
                        value = "'${(tuple[i] as Constant).getValue()}'"; //if value is a string, surround with quotation marks
                        break;
                    case Float:
                        value = "${(tuple[i] as Constant).getValue()}f";
                        break;
                    default:
                        value = "${(tuple[i] as Constant).getValue()}";
                }
                conditions += "&& it[$i].equals(${value})";
            }
        }
        if (conditions.isEmpty()) return relation;
        conditions = conditions[3..conditions.size()-1]; //if there is no common variables, join condition is true. otherwise, remove extra &&
        Closure c = this.sh.evaluate("{it -> " + conditions + "}")

        return this.basicOpr.select(relation, c);
    }

    public Relation processAggQuery(Query q, Map agg, String headVar) {

        if(verbose>1) System.out.println(" processAggQuery : "+q+" map :"+agg+" headVar : "+headVar);
        String headName = q.getHead().getName().replace('?','');
        Relation result;
        ArrayList<Element> tuple;

        (result, tuple) = this.processQueryBody(q.getBody(), null);

        tuple.add(new Variable(headVar));//adds the aggregation variable as an element of the tuple (the aggregation will add it to the end of the relation)

        Operators basicOpr = new Operators();

        result = basicOpr.aggregate(result, agg);

        ArrayList<Element> tupleHead = q.getHead().getTuple();
        tupleHead.add(new Variable(headVar));//adds the aggregation variable as an element of the head tuple (the aggregation will add it to the end of the relation)

        result = this.processProjections(result, tuple, tupleHead);
        //result = result.unique();

        this.db[headName] = result;
        if(verbose>1) {
            println("Agg relation : " + headName);
            result.print();
        }

        this.lastResult = result;

        return result;
    }


    Relation processMapQuery(Query q, AssignExpression assignExpr) {
        String headName = q.getHead().getName().replace('?','');

        //if has cOut (number of neighbors) as part of the expression, extend the query to calculate the value
        if (assignExpr.expression.contains("[cOut]")){
            println "add count"
            Variable n = new Variable(q.getBody()[1].idList[0]); //variable representing the nodes
            Variable cOut = new Variable("cOut");

            def agg = [ids:[0], variable: 2, function: "size", parameter:1] //aggregation to calculate the counts

            Query qCount = new Query(new Atome("xxCountxx", [n]), [q.getBody()[1]]);


            processAggQuery(qCount, agg, "cOut")

            def elements = [new Variable(q.getBody()[1].idList[0]), new Variable("cOut")]
            Atome countOut = new Atome("xxCountxx", elements) //temporary relation name

            ArrayList<Atome> body = new ArrayList<Atome>();
            body.addAll(q.getBody());
            body.add(countOut);

            q = new Query(q.getHead(), body);
            //q.getBody().add(countOut);
        }

        Relation resp = processSimpleQuery(q, assignExpr)

        this.db[headName] = resp;

        this.lastResult = resp;

        return resp;
        
    }


    Relation processBetaQuery(Query q, int n, AssignExpression mapAssignExpr, Map reduceAssigAgg, AssignExpression updateAssignExpr, String headVar) {
        if(verbose>1) {
            System.out.println("BetaQuery with Query" + q + " n = " + n + " mapAssExp : " + mapAssignExpr + " reduceAssigAgg : " + reduceAssigAgg);
            System.out.println("Update exp : " + updateAssignExpr + " headVar : " + headVar);
        }
        String headName = q.getHead().getName().replace('?','');
        String countName = q.getBody().get(0).getName();
        Relation resp, respTemp;

        //need to remove aggregation variable from the head (TODO: fix inconsistent behavior of aggregation vs. other queries)
        ArrayList<Element> qAggHeadElem = new ArrayList<Element>(q.getHead().getTuple());
        qAggHeadElem.remove(qAggHeadElem.size() - 1);

        //Query qAgg = new Query(new Atome(q.getHead().getName(), qAggHeadElem), q.getBody());
        //System.out.println(" qAgg= "+qAgg)

        // Jac le 14/06/2017
        // on va créer la query Map
        // query for map Count(X,Y,c0)Follows(Y,Z,c1) -> Map(X,Y,Z,c2) c2 = fct(c0,c1)
        ArrayList<Element> t = new ArrayList<Element>();
        for (int cpt = 0; cpt < q.getBody().get(0).getTuple().size() - 1; ++cpt) {
            t.add(q.getBody().get(0).getTuple().get(cpt));
        }
        for (int cpt = 0; cpt < q.getBody().get(1).getTuple().size() - 1; ++cpt) {
            if (!t.contains(q.getBody().get(1).getTuple().get(cpt))) {
                t.add(q.getBody().get(1).getTuple().get(cpt));
            }
        }
        Element c1 = new Variable("c1");
        t.add(c1);
        Atome aMap = new Atome("Map", t);
        Query qMap = new Query(aMap, q.getBody());
        AssignExpression mapAssignExprbis = new AssignExpression(c1.getName(), mapAssignExpr.getExpression());

        // on va créer la query reduce
        ArrayList<Element> tr = new ArrayList<Element>();
        for (int cpt = 0; cpt < q.getHead().getTuple().size() - 1; ++cpt) {
            tr.add(q.getHead().getTuple().get(cpt));
        }

        ArrayList<Atome> bRed = new ArrayList<Atome>();
        bRed.add(aMap);
        Atome aRed = new Atome("Reduce", tr.clone());
        Query qRed = new Query(aRed, bRed);
        // recherche de la position des variables de aRed dans aMap
        reduceAssigAgg['ids'] = [];
        for (int cpt = 0; cpt < tr.size(); ++cpt) {
            int pos = 0;
            while (pos < t.size() && !t.get(pos).equals(tr.get(cpt))) {
                ++pos;
            }
            if (pos < t.size()) {
                reduceAssigAgg['ids'].add(pos);
            } else {
                System.out.println("Error in Reduce construction with variable " + tr.get(cpt));
            }
        }
        reduceAssigAgg['parameter'] = t.size() - 1;

        Relation respMap, respRed;

        for (int i=1; i<=n; ++i) {
            System.out.println("Beta with i = "+i);

            if(verbose>1) System.out.println(" qMap : " + qMap + " assign exp " + mapAssignExprbis);
            if(verbose>2) {
                System.out.println(" avec Count = ");
                this.db[countName].print();
            }

            respMap = processQuery(qMap, mapAssignExprbis);

            // le reduce
            aRed.tuple=tr.clone();
            respRed = processAggQuery(qRed, reduceAssigAgg, headVar);

            // Update
            if (updateAssignExpr.isIdentity()) {
                this.db[countName] = respRed;
                this.lastResult = respRed;
            } else {
                //todo
            }
            if("Map" in this.db){
                this.db["Map"].removeAll();
            }
            if(verbose>0){
                System.out.println("Resultat intermédiaire : Count relation ");
                this.db[countName].print();
            }
        }
        this.db[headName] = this.db[countName];
        this.lastResult = this.db[headName];
        //for (i in [1..n]){
        //    respTemp = processMapQuery(q, mapAssignExpr);

        //    //respTemp = processAggQuery(qAgg, reduceAssigAgg, headVar);

        //    respTemp = basicOpr.aggregate(respTemp, reduceAssigAgg);

        //    respTemp.print();




        //}



        //return processQuery(q, mapAssignExpr);

        System.out.println("Map return relation "+ headName);
        this.db[headName].print();

        return this.db[headName];

    }

    public void setInfRulesSet (LinkedListRules s){
        infRulesSet = s;
    };
    public void setPosConstraintsSet (LinkedListRules s){
        posConstraintsSet = s;
    };
    public void setNegConstraintsSet (LinkedListRules s){
        negConstraintsSet = s;
    };
    public void setKeyConstraintsSet  (LinkedListRules s){
        keyConstraintsSet = s;
    };
    public void setSchema (ArrayListSchema schemas){
        sch = schemas;
        for (s in schemas) {
            this.db[s.getName()] = new Relation(s.idList);
        }
    };

    public void addFact(String relation, List values){
        println(relation)
        println(values)
        this.db[relation].addRow(values);

    };

    public Relation getLastResult(){
        return this.lastResult;
    }


}