package processor;

class Constant extends Element{
    Class valueType = String.class;
    Constant(String n){
        super(n,2);
    }
    Constant(String n, Class vt){ //constructs a Constant of a specific type (Integer or Float)
        super(n,2);
        this.valueType = vt;
    }
    boolean isVariable(){return false;}
    boolean isConstant(){return true;}
    Object getValue(){
        if (valueType.isAssignableFrom(Float.class)) return Float.parseFloat(super.getName());
        if (valueType.isAssignableFrom(Integer.class)) return Integer.parseInt(super.getName());
        return (String) super.getName();
    };
}
