package processor;

import java.util.ArrayList;

class Rule{
    ArrayList<Atome> body;
    Atome head;
    Rule(Atome h, ArrayList<Atome> b){
		body = new ArrayList<Atome>();
		for(Atome a : b){
			body.add(a);
		}
		head = h;
	}
	ArrayList<Atome> getBody(){return body;}
	Atome getHead(){return head;}


	public String toString(){
		
		String res = ""+body+" -> "+head;
		return res;
	}
	
	static Rule stringToRule(String r) throws SyntaxError {
		//r=r.replace(" ", "");
		r=LinkedListRules.delSpace(r);
		r = r.replace("->","-:");
		String tete="";
		String corp="";
		int pos = r.indexOf("-:");
		boolean isAQuery = false;
		if(pos != -1){
			corp = r.substring(0, pos);
			tete = r.substring(pos+2);
		}
		else{
			pos = r.indexOf(":-");
			if(pos != -1){
				corp = r.substring(pos+2);
				tete = r.substring(0, pos);
				
			}
			else{
				throw new SyntaxError("Syntax error in "+r);
			}
		}
		if(tete.charAt(0)=='?')
		    isAQuery = true;
		
		Atome t = Atome.stringToAtome(tete);	

		// supprime eventuellement [....] les crochets autour du corp
		if(corp.charAt(0)=='['){
			corp = corp.substring(1,corp.length()-1);
		}
		corp = corp.replace("),",");");
		ArrayList<Atome> lebody = new ArrayList<Atome>();
		Atome t2;
		for(String s2 : corp.split(";")){
			t2 = Atome.stringToAtome(s2);
			lebody.add(t2);
		}
		if(isAQuery){	
			return new Query(t, lebody);
		}
		else{
			return new Rule(t, lebody);
		}
	}

	static Query stringToQuery(String r) throws SyntaxError {
		//r=r.replace(" ", "");
		r=LinkedListRules.delSpace(r);
		r = r.replace("->","-:");
		String tete="";
		String corp="";
		int pos = r.indexOf("-:");
		boolean isAQuery = false;
		if(pos != -1){
			corp = r.substring(0, pos);
			tete = r.substring(pos+2);
		}
		else{
			pos = r.indexOf(":-");
			if(pos != -1){
				corp = r.substring(pos+2);
				tete = r.substring(0, pos);

			}
			else{
				throw new SyntaxError("Syntax error in "+r);
			}
		}
		if(tete.charAt(0)=='?')
			isAQuery = true;

		Atome t = Atome.stringToAtome(tete);

		// supprime eventuellement [....] les crochets autour du corp
		if(corp.charAt(0)=='['){
			corp = corp.substring(1,corp.length()-1);
		}
		corp = corp.replace("),",");");
		ArrayList<Atome> lebody = new ArrayList<Atome>();
		Atome t2;
		for(String s2 : corp.split(";")){
			t2 = Atome.stringToAtome(s2);
			lebody.add(t2);
		}
		return new Query(t, lebody);
	}

	boolean isEqual(Rule b){
		boolean res = toString().equals(b.toString());
		return res;
	}
	
	public boolean equals(Object x){
		if(x instanceof Rule){
			Rule a = (Rule)x;
			boolean res = toString().equals(a.toString());
			return res;
		}
		else{
			return false;
		}
	}
	
	public int hashCode() {
		return (toString()).hashCode();
    }
    
	public int compareTo(Object x){
		Rule e=(Rule) x;
		return toString().compareTo(e.toString());
	}
		
	public Rule renameVar(int num){
		Atome h = head;
		h = h.renameVar(num);
		ArrayList<Atome> newb= new ArrayList<Atome>();
		for(Atome a : body){
			a = a.renameVar(num);
			newb.add(a);
		}
		return new Rule(h,newb);
	}
}
