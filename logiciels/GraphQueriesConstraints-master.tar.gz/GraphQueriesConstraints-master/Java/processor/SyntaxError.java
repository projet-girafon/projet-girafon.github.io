package processor;

public class SyntaxError extends Exception{
	SyntaxError(){
		super();
	}
	SyntaxError(String e){
		super(e);
	}
}	
