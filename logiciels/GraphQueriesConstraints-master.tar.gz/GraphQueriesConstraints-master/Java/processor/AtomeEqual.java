package processor;

import java.util.ArrayList;

class AtomeEqual extends Atome{
	
	AtomeEqual(String s1, String s2){
		super("=");
		tuple = new ArrayList<Element>();
		if(s1.charAt(0)>='A' && s1.charAt(0)<='Z'){
			tuple.add(new Variable(s1));
		}
		else{
			tuple.add(new Constant(s1));
		}
		if(s2.charAt(0)>='A' && s2.charAt(0)<='Z'){
			tuple.add(new Variable(s2));
		}
		else{
			tuple.add(new Constant(s2));
		}
	}
	
	public String toString(){
		String res = tuple.get(0) + " = " + tuple.get(1);
		return res;
	}
}
