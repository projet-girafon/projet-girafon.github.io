package processor;

import java.util.ArrayList;
import java.util.*;

class Query extends Rule{
	static int numNewVar = 1;
	static int verbose = 2;
    Query(Atome h, ArrayList<Atome> b){
		super(h, b);
	}
	
	boolean contains(Atome a){
		// return true is a is in body of the query
		for(Atome b : getBody()){
			if(a.isEqual(b)){
				return true;
			}
		}
		return false;
	}		

	public static boolean containsNew(Atome a, ArrayList<Atome> liste){
		// return true si a est dans la liste modulo le renomage des variables New reductibles
		//System.out.print("Test si "+a+ " est dans "+liste+" return ");
		for(Atome b : liste){
			if(a.identiqueModuloNew(b)){
				//System.out.println("True");
				return true;
			}
		}
		//System.out.println("False");
		return false;		
	}
	
	boolean containsNew(Atome a){
		// return true is a is in body of the query modulo le renomage des variables New reductibles
		return containsNew(a, getBody());
	}
	

		
		
	boolean completeWithOnePosConstraint(Rule pc){
		numNewVar++;
		//if(numNewVar >=6)
		//	return false;
		int numNewAdd = 0;
		pc = pc.renameVar(numNewVar); 
		if(verbose > 2) System.out.println("numNewVar = " + numNewVar +"  "+ pc);
		ArrayList<Atome> res = new ArrayList<Atome>();
		
		ArrayList<Atome> src = pc.getBody();
		ArrayList<Atome> trg = getBody();

		if(verbose > 2) System.out.println("src "+ src + " trg " + trg);
		boolean fini = false;
        boolean result = false;
		int lg = src.size();
		
		int[] tabPos = new int[lg];
		for(int j=0; j<lg; ++j){tabPos[j]=-1;}
		
		Substitution[] tabSub=new Substitution[lg];
		tabSub[0]=new Substitution();
		
		int i=0;
		
		while(!fini){
			if(verbose > 2) System.out.print(" "+i+ " tabi " + tabPos[i]);
			if(i==0){
				tabSub[i]=new Substitution();
			}
			else{
				tabSub[i]=tabSub[i-1].duplicate();
			}

			tabPos[i]=src.get(i).mapList(trg, tabSub[i], tabPos[i]);
			
			if(verbose > 2) System.out.println(" apres mapList i= " + i + " tabi :"+ tabPos[i]);
			if(verbose > 2) System.out.println(" apres mapList tabsi :"+ tabSub[i]);

			if(tabPos[i]==-1){
				if(i==0){
					fini = true;
				}
				else{
					i=i-1;
				}
			}
			else if(i==lg-1){
				numNewAdd++;
				// a chaque nouvelle instanciation les variables existencielles sont différentes.
				Atome a= tabSub[i].applySub2(pc.getHead(), numNewAdd);
				if(verbose > 2) System.out.println("processor.Atome instancie : "+a);
				if(containsNew(a) == false && containsNew(a, res)==false){
					if(verbose > 2) System.out.println("Test presence de "+a+" dans "+getBody());
                    result = true;
                    //a.renameOldNewVar(res);
					res.add(a);
				}
			}
			else{
				i=i+1;
			}
			if(fini){
				if(res.size() != 0){
					for (Atome b : res){
						b.putRedOldNewVar(body);
						body.add(b);
					}
					numNewVar++;
					pc = pc.renameVar(numNewVar);
					if(verbose > 2) System.out.println("numNewVar = " + numNewVar +"  "+ pc);
					src = pc.getBody();
					fini=false;
					res = new ArrayList<Atome>();
				}
			}
				
		}
        return result;
	}
    
    void completeWithPosConstraint(LinkedListRules posConstraintSet){
        boolean cont = true;
        Rule pc;
        while(cont){
            cont=false;
            for(int i=0; i<posConstraintSet.size(); i++){
                pc = posConstraintSet.get(i);
                if(completeWithOnePosConstraint(pc)){
                    cont = true;
                }
            }
        }
        
    }
    void completeWithSimplePosConstraint(LinkedListRules posConstraintSet){
        boolean cont = true;
        Rule pc;
        while(cont){
            cont=false;
            for(int i=0; i<posConstraintSet.size(); i++){
                pc = posConstraintSet.get(i);
                if(pc.getHead().getTuple().size()<=1){
					// on complete uniquement avec les PC qui ont un prédicat unaire en tete
					if(completeWithOnePosConstraint(pc)){
						cont = true;
					}
                }
            }
        }
        
    }

    boolean checkOneNegConstraint(Rule nc){
        // return false il there is an instanciation of the negative constraint nc in the body of the query
        ArrayList<Atome> res = new ArrayList<Atome>();
		
		ArrayList<Atome> src = nc.getBody();
		ArrayList<Atome> trg = getBody();
		
		boolean fini = false;
        boolean ok = true;
		int lg = src.size();
		
		int[] tabPos = new int[lg];
		for(int j=0; j<lg; ++j){tabPos[j]=-1;}
		
		Substitution[] tabSub=new Substitution[lg];
		tabSub[0]=new Substitution();
		
		int i=0;
		
		while(!fini && ok){
			//System.out.print(" "+i+ " tabi " + tabPos[i]);
			if(i==0){
				tabSub[i]=new Substitution();
			}
			else{
				tabSub[i]=tabSub[i-1].duplicate();
			}

			tabPos[i]=src.get(i).mapList(trg, tabSub[i], tabPos[i]);
			
			//System.out.println(" apres mapList tabi :"+ tabPos[i]);
			//System.out.println(" apres mapList tabsi :"+ tabSub[i]);

			if(tabPos[i]==-1){
				if(i==0){
					fini = true;
				}
				else{
					i=i-1;
				}
			}
			else if(i==lg-1){
				ok = false;
			}
			else{
				i=i+1;
			}
		}
        return ok;
	}
    
    int checkNegConstraint(LinkedListRules negConstraintSet){
        // return i if there is an instanciation of a negative constraint number i, in the body of the query
        // else return -1
        boolean ok = true;
        Rule nc;
        int i=0;
        int res = -1;
        while(ok && i<negConstraintSet.size()){
            nc = negConstraintSet.get(i);
            ok = checkOneNegConstraint(nc);
            if(!ok){
                res = i+1;
            }
            i++;
        }
        return res;
    }
    
    int algo1(LinkedListRules posConstraintSet, LinkedListRules negConstraintSet){
        // complete the query with positive constraints and check negative constraint
        // return -1 if check is ok else return numbre of negative constraint which is conflicted.
        completeWithPosConstraint(posConstraintSet);        
        //completeWithSimplePosConstraint(posConstraintSet);
        int res = checkNegConstraint(negConstraintSet);
        return res;
        
    }
    
    LinkedListRules algo2SimplePosConstraint(LinkedListRules posConstraintSet){
        // return the list of queries to check for an answer take account positive constraints
        LinkedListRules res = new LinkedListRules();
        ArrayList<Atome> trg = getBody();
        Rule pc;
        ArrayList<Atome> src;
        
        for(int i=0; i<posConstraintSet.size(); ++i){
            pc = posConstraintSet.get(i);
            if(pc.getHead().getTuple().size() > 1){
				src = pc.getBody();
				for(Atome a : trg){
					// pour tous les atomes de la réponses
					Substitution sub = new Substitution();
					int pos = a.mapList2(src, sub, -1);
					while(pos != -1){
						// on construit une nouvelle requette
						ArrayList<Atome> reqb = new ArrayList<Atome>();
						Atome b = sub.applySub(pc.getHead());
						reqb.add(b);
						Atome reqh = new Atome("§");
						Rule req = new Query(reqh, reqb);
						res.add(req);
                    
						sub = new Substitution();
						pos = a.mapList2(src, sub, pos);
					}
				}
            }
        }
        
        /* if(processor.QS.verbose > 1){
			System.out.println("processor.Query to check for positive constraint " +res);
		} */
        return res;
    }
        
    LinkedListRules algo2NegConstraint(LinkedListRules negConstraintSet){
        // return the list of queries to check for an answer take account negative constraints
        LinkedListRules res = new LinkedListRules();
        ArrayList<Atome> trg = getBody();
        Rule nc;
        ArrayList<Atome> src;
        
        for(int i=0; i<negConstraintSet.size(); ++i){
            nc = negConstraintSet.get(i);
            src = nc.getBody();
            for(Atome a : trg){
                // pour tous les atomes de la réponses
                Substitution sub = new Substitution();
                int pos = a.mapList2(src, sub, -1);
                while(pos != -1){
					// System.out.println("Avec la substitution : "+sub);
                    // on construit une nouvelle requette
                    ArrayList<Atome> reqb = new ArrayList<Atome>();
                    for(int j=0; j<src.size(); ++j){
                        if(j!=pos){
							Atome b = sub.applySub(src.get(j));
							// if b is not in the instancied query
							if(!contains(b)){
								reqb.add(b);
							}
                        }
					}
					if(reqb.size()==0){
						reqb.add(new Atome("!"));
					}
                    Atome reqh = new Atome("?");
                    Rule req = new Query(reqh, reqb);
                    // System.out.println("On fabrique la requete : "+req);
                    res.add(req);
                    
                    sub = new Substitution();
                    pos = a.mapList2(src, sub, pos);
                }
            }
        }
        return res;
    }
 
    LinkedListRules algo2KeyConstraint(LinkedListRules keyConstraintSet){
        // return the list of queries to check for an answer take account key constraints
        LinkedListRules res = new LinkedListRules();
        ArrayList<Atome> trg = getBody();
        Rule kc;
        ArrayList<Atome> src;
    
        for(int i=0; i<keyConstraintSet.size(); ++i){
            kc = keyConstraintSet.get(i);
            src = kc.getBody();
            for(Atome a : trg){
                // pour tous les atomes de la réponses
                Substitution sub = new Substitution();
                int pos = a.mapList2(src, sub, -1);
         
                //while(pos != -1){
				// on ne fait au plus qu'une sous requete
                if(pos != -1){
					// System.out.println("Pos vaut : "+pos);
                    // on construit une nouvelle requete
                    ArrayList<Atome> reqb = new ArrayList<Atome>();
                    for(int j=0; j<src.size(); ++j){
                        if(j!=pos){
							Atome b = sub.applySub(src.get(j));
							// if b is not in the instancied query
							if(!contains(b)){
								reqb.add(b);
							}
                        }
					}
					Atome c = new Atome("NotEqual", sub.applySub(kc.getHead()).getTuple());
					reqb.add(c);
					ArrayList<Element> reqv = new ArrayList<Element>();
					for(Element e: c.getTuple()){
						if(e.isVariable()){
							reqv.add(e);
						}
					}
                    Atome reqh = new Atome("?", reqv);
                    Rule req = new Query(reqh, reqb);
                    res.add(req);
                    
                    sub = new Substitution();
                    pos = a.mapList2(src, sub, pos);
                }
            }
        } 
        return res;
    }  
    
    LinkedListRules algo2(LinkedListRules negConstraintSet, LinkedListRules keyConstraintSet, LinkedListRules posConstraintSet){
        // return the list of queries to check for an answer
		LinkedListRules res = algo2NegConstraint(negConstraintSet);
		//processor.LinkedListRules res1 = algo2SimplePosConstraint(posConstraintSet);
		//System.out.println("Req à vérifier avec negconstraint : " + res);
		LinkedListRules res2 =algo2KeyConstraint(keyConstraintSet);
		//System.out.println("Req à vérifier avec keyconstraint : " + res2);
		
		//res.addAll(res1);
		res.addAll(res2);
		return res;
	}
	
	static Atome removeNotEqualPredicat(ArrayList<Atome> body){
		// retourne et supprime l'atome NotEqual(..,..) du body s'il est present
		// retourne null sinon
		Atome res = null;
		int i=0;
		boolean find = false;
		while(!find && i<body.size()){
			if(body.get(i).getName().equals("NotEqual")){
				find = true;
				res = body.get(i);
				body.remove(res);
			}
			else{
				i+=1;
			}
		}
		return res;
	}
	
	Query completeAllVariables(){
		// on crée une nouvelle requête qui a dans la tête toutes les variables du corps
		ArrayList<Element> nhead = new ArrayList<Element>();
		if(getHead().getTuple().size()>0){
			for(Element e : getHead().getTuple()){
				nhead.add(e);
			}
		}
		for(Atome a : getBody()){
			for(Element e : a.getTuple()){
				if(e.isVariable() && !nhead.contains(e)){
					nhead.add(e);
				}
			}
		}
		
		Atome hq2 = new Atome(getHead().getName(), nhead);
		Query q2 = new Query(hq2, getBody());
		return q2;
	}

	
	String queryToSQL(ArrayListSchema sch){
		// attention toutes les variables du corps de la query doivent être aussi dans la tete 
	    String select="select SQL_NO_CACHE ";
	    String from=" from ";
	    String where= "";
	    
	    int cptw=0;
	    ArrayList<Atome> bodyReq = getBody();
	    Atome neq = removeNotEqualPredicat(bodyReq);
	    
	    // Pour faire une correspondance entre les variables et les attributs du schéma correspondant
	    HashMap<Variable, HashSet<String>> ass = new  HashMap<Variable, HashSet<String>>();
	    
	    Atome rh = getHead();
	    String pred="", predok;
	    int cpt = 0;
	    if(rh.getTuple()!=null){
			for(Element e :rh.getTuple()){
				if(e.isVariable()){
					predok = null;
					int nba=0;
					for(Atome a : bodyReq){
						int pos = a.findElement(e, -1);
						while(pos != -1){
							try{
								pred = sch.getAttribut(a.getName(), pos);
								if(!ass.keySet().contains(e)){
									ass.put((Variable)e, new HashSet<String>());
								}
								ass.get(e).add(a.getName()+nba+"."+pred);
								if(predok==null){
									predok = a.getName()+nba+"."+pred;
								}
							} catch(SyntaxError se){
								System.out.println(se.getMessage());
								return null;
							}
							pos = a.findElement(e, pos);
						}
						nba+=1;
					}
					if(cpt > 0){
						select +=", ";
					}
					select += predok;
					cpt += 1;
				}
				else{
					System.out.println("head of query :" + rh + "is not well formed");
					return null;
				}
			}
		}
		else{
			//System.out.println("Pas de tete donc BC pure");
		}
		//System.out.println("Dans la transformation le hashmap des variables de tete est : "+ass);
		
		if(cpt==0){
			// it is a boolean query
			select += "* ";  // avant j'avais mis count(*)
		}
		
		// from part
		cpt = 0;
		for(Atome a : bodyReq){
			if(cpt>0){
				from +=", ";
			}
			from += a.getName()+" as "+a.getName()+cpt;
			cpt+=1;
		}
		
		// si dans le corps de la requete il y a des variables qui ne sont pas dans la tete
		// on va completer ass
		for(int i=0; i<bodyReq.size(); ++i){
			Atome a = bodyReq.get(i);
			for(Element e : a.getTuple()){
				if(e.isVariable()){
					//System.out.println("Recherche de "+e+ " dans "+getHead());
					if(getHead() == null || !getHead().contains(e)){
						// c'est une nouvelle variable, il faut l'ajouter à ass
						for(int j=i; j<bodyReq.size(); ++j){
							Atome b = bodyReq.get(j);
							int pos = b.findElement(e, -1);
							//System.out.println("processor.Atome b : "+b+ " pos = "+pos);
							while(pos != -1){
								try{
									pred = sch.getAttribut(b.getName(), pos);
									if(!ass.keySet().contains(e)){
										ass.put((Variable)e, new HashSet<String>());
									}
									ass.get(e).add(a.getName()+j+"."+pred);
					
								} catch(SyntaxError se){
									System.out.println(se.getMessage());
									return null;
								}
								pos = b.findElement(e, pos);
							}
						}
					}
				}
			}
		}
		
		//System.out.println("Dans la transformation le hashmap de toutes les variables est : "+ass);
		//System.out.println("Nomalement rien : ");

		// where part
		// pour chaque variable si elle est associée à plusieurs attributs on ajoute une condition where
		for(HashSet<String> s : ass.values()){
			String prem=null;
			if(s.size()>1){
				for(String pr : s){
					if(prem==null){
						prem=pr;
					}
					else{
						if(cptw==0){
							where = " where ";
						}
						else{
							where += " and ";
						}
						where += prem + " = " + pr + " ";
						cptw+=1;
					}
				}
			}
		}
		
		// si dans le corps il y a des constantes ajouter les dans le where
		int cpta=-1;
		for(Atome a : bodyReq){
			cpta++;
			for(int i=0; i<a.getTuple().size(); ++i){
				if(a.tuple.get(i).isConstant()){
					if(cptw==0){
						where = " where ";
					}
					else{
						where += " and ";
					}
					try{
						where += a.getName()+cpta+"."+sch.getAttribut(a.getName(), i)+ " = '" + a.tuple.get(i).getName()+"' ";
					}catch(SyntaxError e){
						System.out.println(e.getMessage());
						return null;
					}
					cptw+=1;
				}
			}
		}
		
		// s'il y avait un atome NotEqual, on complete le where
		if(neq!=null){
			Element e1=neq.getTuple().get(0);
			Element e2=neq.getTuple().get(1);
			String s1="";
			String s2="";
			int v=0;
			if(e1.isVariable()){
				v=1;
				// on récupère l'attribut associé à cette variable
				s1=(String)ass.get((Variable)e1).toArray()[0];
			}
			else{
				s1 = "'"+e1.getName()+"'";
			}
			if(e2.isVariable()){
				v=2;
				// on récupère l'attribut associé à cette variable
				s2=(String)ass.get((Variable)e2).toArray()[0];
			}
			else{
				s2 = "'"+e2.getName()+"'";
			}
			if(cptw==0){
				where = " where ";
			}
			else{
				where += " and ";
			}
			if(v==2){
				where += s2+"<>"+s1+ " ";
			}
			else{
				where += s1+"<>"+s2+ " ";
			}
			cptw+=1;
			
			//on va remettre neq dans le body de la requete
			bodyReq.add(neq);
		}
		
		String sql="";
		if(where != null){
			sql = select+from+where;
		}
		else{
			sql = select + from;
		}
		return sql;	
	}
	String queryToSparql(ArrayListSchema schSparql){
		/*"SELECT ?author ?birthplace ?artwork ?museum ?ville ?pays WHERE { "
				+ " ?author rdf:type dbo:Artist."
				+ " ?artwork dbo:author ?author."
				+ " ?author dbo:birthPlace ?birthplace."
				+ " ?birthplace dbo:country ?pays."
				+ " ?artwork rdf:type dbo:Artwork."
				+ " ?artwork dbo:museum ?museum."
				+ " ?museum rdf:type dbo:Museum."
				+ " ?museum dbo:location ?ville."
				+ " ?ville dbo:country ?pays."
				+ " }";*/
		String select = "SELECT ";
		String where = " WHERE { ";
		Atome rh = getHead();
	    String pred, var1, var2, predsp;
	    int cpt = 0;
	    if(rh.getTuple()!=null){
			for(Element e :rh.getTuple()){
				if(e.isVariable()){
					select += "?"+e.getName()+ " ";
				}
			}
		}
		for(Atome a : getBody()){
			pred = a.getName();
			try{
				predsp = schSparql.getAttribut(pred,0);
			} catch(SyntaxError se){
				System.out.println(se.getMessage());
				return null;
			}
			var1 = a.getTuple().get(0).getName();
			if(a.getTuple().size()==2){
				var2 = a.getTuple().get(1).getName();
				where += "?"+var1+" "+predsp+" ?"+var2+". ";
			}
			else{
				where += "?"+var1+" rdf:type "+predsp+". ";
			}
		}
		where +="}";
			
		return select+where;
	}
	
	String queryBQToSparql(ArrayListSchema schSparql){
		/*ASK {
			<http://dbpedia.org/resource/Filippo_Lippi> rdf:type dbo:Artist.
			<http://dbpedia.org/resource/Filippo_Lippi> rdf:type dbo:Policiant.
			} */
		String res = "ASK { ";
		String pred, predsp, var1;
		for(Atome a : getBody()){
			pred = a.getName();
			try{
				predsp = schSparql.getAttribut(pred,0);
			} catch(SyntaxError se){
				System.out.println(se.getMessage());
				return null;
			}
			var1 = a.getTuple().get(0).getName();
			res += "<"+var1+"> rdf:type "+predsp+". ";
		}
		res +="}";
			
		return res;
	}	
	
	String queryBQToSparqlBis(ArrayListSchema schSparql){
		/*ASK {
			<http://dbpedia.org/resource/Filippo_Lippi> rdf:type dbo:Artist.
			<http://dbpedia.org/resource/Filippo_Lippi> rdf:type dbo:Policiant.
			} */
		String res = "SELECT count(*) WHERE { ";
		String pred, predsp, var1;
		for(Atome a : getBody()){
			pred = a.getName();
			try{
				predsp = schSparql.getAttribut(pred,0);
			} catch(SyntaxError se){
				System.out.println(se.getMessage());
				return null;
			}
			var1 = a.getTuple().get(0).getName();
			res += "<"+var1+"> rdf:type "+predsp+". ";
		}
		res +="}";
			
		return res;
	}
	
	boolean isBQ(){
		return getHead().getTuple() == null;
	}
	
	String queryCountToSparql(ArrayListSchema schSparql){
		/* select  count(distinct ?Yb)
			where {
					?Yb dbo:author <http://dbpedia.org/resource/Albrecht_Dürer>.
					#FILTER (  str(?Yb) < "http://dbpedia.org/resource/Self-Portrait_(Dürer,_Munich)" || str(?Yb) > "http://dbpedia.org/resource/Self-Portrait_(Dürer,_Munich)" )
			} la comparaison des chaines ne fonctionne pas bien!*/
		String select = "SELECT COUNT(";
		String where = " WHERE { ";
		Atome rh = getHead();
	    String pred, var1, var2, predsp;
	    int cpt = 0;
	    if(rh.getTuple()!=null){
			for(Element e :rh.getTuple()){
				cpt+=1;
				if(e.isVariable()){
					select += "?"+e.getName()+ " ";
				}
			}
		}
	    if(cpt != 1){
	    	System.out.println("Syntax error with count query");
	    }
	    select +=") ";
		for(Atome a : getBody()){
			pred = a.getName();
			if(!pred.equals("NotEqual")){
			    try{
			    	predsp = schSparql.getAttribut(pred,0);
			    } catch(SyntaxError se){
			    	System.out.println(se.getMessage());
			    	return null;
			    }
			    var1 = a.getTuple().get(0).getName();
			    if(a.getTuple().size()==2){
			    	var2 = a.getTuple().get(1).getName();
			    	if(a.getTuple().get(0).isVariable()){
			    		where += "?"+var1+" "+predsp+" <"+var2+">. ";
			    	}
			    	else{
			    		where += "<"+var1+"> "+predsp+" ?"+var2+". ";
			    	}
			    }
			    else{
			    	where += "?"+var1+" rdf:type "+predsp+". ";
			    }
			}
		}
		where +="}";
			
		return select+where;
	}
		
}

