package processor;

/**
 * Created by luizcelso on 30/01/17.
 */
public class AssignExpression {
    String variable;
    String expression; // expression to be assessed in form os a closure. Example query expression: D = D1+D2 becomes it[D1]+it[D2]. Before executing the closure the variables (ex. D1, D2) must be replaced by their respective indexes in the fact relation.

    public AssignExpression(String variable, String expression) {
        this.variable = variable;
        this.expression = expression;
    }

    public String getVariable() {
        return variable;
    }

    public String getExpression() {
        return expression;
    }

    public String toString(){ return variable + " = " + expression;}

    public boolean isIdentity(){return expression.equals("it["+variable+"]");}

}
