package processor;

import processor.algebra.Relation;

import java.util.List;
import java.util.Map;

/**
 * Created by luizcelso on 09/01/17.
 */
public interface Processor {
    public Relation processQuery(Query q, AssignExpression assignExpr);
    public Relation processMapQuery(Query q, AssignExpression assignExpr);
    public Relation processAggQuery(Query q, Map aggregation, String headVar);
    public Relation processBetaQuery(Query q, int n, AssignExpression mapAssignExpr, Map reduceAssigAgg, AssignExpression updateAssignExpr, String headVar);
    public Relation getLastResult(); //returns the resulting relation for the last query in the datalog program
    public void setInfRulesSet (LinkedListRules s);
    public void setPosConstraintsSet (LinkedListRules s);
    public void setNegConstraintsSet (LinkedListRules s);
    public void setKeyConstraintsSet  (LinkedListRules s);
    public void setSchema (ArrayListSchema s);
    public void addFact(String relation, List values);
}