package processor;

import processor.algebra.Operators;
import processor.algebra.Relation;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by luizcelso on 09/01/17.
 */
public class MySQLProcessor extends MemoryProcessor {
    static int verbose = 1;
    String dataBase, user, mdp;
    ArrayListSchema sch;
    Relation result, lastResult;

    public MySQLProcessor(ArrayListSchema s, String d, String u, String p){
        this.sch = s;
        this.dataBase = d;
        this.user = u;
        this.mdp = p;
        this.result = new Relation();

    }

    public void processQuery(Query q1, String assignExpr){
        		/* We consider for instance only the first query */
        //Query q1 = (Query)queriesSet.get(0);


		/* Query is completed with positive constraints and we check if there is no inconsistance with neg constraints */
        long tempsDebut = System.currentTimeMillis();
        if(verbose>=1) System.out.println("query before algo1 : " + q1);
        int ncpb = q1.algo1(posConstraintsSet, negConstraintsSet);
        if(verbose>=1) System.out.println("query after algo1 : " + q1);
        if(ncpb != -1){
            System.out.println("STOP  query maps the negative constraint number  " + ncpb);
            return;
        }
        else{
            if(verbose>=1) System.out.println("No problem with negative constraints");
        }
        long tempsFin1 = System.currentTimeMillis();
        float seconds = (tempsFin1 - tempsDebut) / 1000F;
        System.out.println("tranfo requete effectuée en: "+ Float.toString(seconds) + " secondes.");

		/* ans of the query is obtained from datalog file : */
        // processor.LinkedListRules ansQuerySet = processor.LinkedListRules.initFromFile(directory+"AnsQuery");

		/* ans of the query is obtained from MySQL evaluator : */
        // processor.LinkedListRules ansQuerySet = MySQL.answer(q1, sch, dataBase, user, mdp);
        // on n'obtient plus les réponses mais le nombre de réponses
        // les réponses sont dans un fichier ansAlgo1.dlp

        int nbAnsAlgo1 = 0;
        //EVALUATOR
        nbAnsAlgo1 = MySQL.answer(q1, sch, dataBase, user, mdp);

		/* ans of the query is obtained from SPARQL end point : */
        //processor.LinkedListRules ansQuerySet = Sparql.answer(q1, sch);

		/* ans of the query is obtained from Raqueline answer file : */
        //nbAnsAlgo1 = processor.LinkedListRules.initFromAnsSparqlFile(directory+"ansQuerySmall", q1);  //first
        //nbAnsAlgo1 = processor.LinkedListRules.initFromAnsSparqlFile(directory+"ansQueryTotal", q1);

        long tempsFin2 = System.currentTimeMillis();
        seconds = (tempsFin2 - tempsFin1) / 1000F;
        System.out.println("reponse requete effectuée en: "+ Float.toString(seconds) + " secondes.");

		/* Pourquoi la suite : juste voir une traduction vers sparql ??? */
        /* Query qc = q1.completeAllVariables();
        String querySparql = qc.queryToSparql(schSp);
        System.out.println("Sparql Query to answer : " + querySparql); */


        //if(verbose>=1) System.out.println("Answers of a query used fro algo2 " + ansQuerySet);

        // Algo2 check if constraints are valid over answers

        System.out.println("Number of answers after algo1 : "+nbAnsAlgo1);


        LinkedListRules ansQueryValidSet = new LinkedListRules();
        int cptQV=0;
        int cptQAV=0;

        Cache queriesChecked = new Cache();

        // Pour prendre en compte les réponses à partir d'un fichier transmis
        //Cache queriesChecked = Cache.initFromAns2File(directory+"Raq_Ans2");

        int nombreEntier;
        //System.out.println("Rentrez un nombre positif ou nul :");
        Scanner lectureClavier = new Scanner(System.in);
        //nombreEntier = lectureClavier.nextInt();
        //System.out.println("Cache before validation :\n" + queriesChecked);
        //nombreEntier = lectureClavier.nextInt();

        int cpt=0;
        LinkedListRules ansQuerySet;
        try{
            // Solutions are in file ./ansAlgo1.dlp
            FileReader fr = new FileReader("./ansAlgo1.dlp");
            BufferedReader br = new BufferedReader(fr);
            boolean ended = false;
            while (!ended) {
                ansQuerySet = new LinkedListRules();
                try {
                    String line = br.readLine();
                    //Solutions were processed per packet of 5000
                    while(line != null && (cpt+1)%5000!=0){
                        cpt++;
                        try{
                            line = line.substring(0, line.length()-1);
                            ansQuerySet.add(Rule.stringToQuery(line));
                        }catch(SyntaxError es){
                            System.out.println("Syntaxe error " + es.getMessage());
                        }
                        line = br.readLine();
                    }
                    if(line != null){
                        cpt++;
                        try{
                            line = line.substring(0, line.length()-1);
                            ansQuerySet.add(Rule.stringToRule(line));
                        }catch(SyntaxError es){
                            System.out.println("Syntaxe error " + es.getMessage());
                        }
                    }
                    for(Rule r2: ansQuerySet){
                        // for each solution we build a subset of queries to check for the validation of the solution
                        Query q2 = (Query)r2;
                        // VALIDATOR
                        LinkedListRules newQueries = q2.algo2(negConstraintsSet, keyConstraintsSet, posConstraintsSet);
                        if(verbose >=2) System.out.println("\n\n For the answer : " + q2);
                        if(verbose >=2) System.out.println("Queries to check  " + newQueries);

                        boolean ok = true;
                        int i = 0;
                        Query q3 = null;
                        while(i<newQueries.size() && ok){
                            q3 = (Query) newQueries.get(i);
                            Integer checked = queriesChecked.isInCache(q3);
                            // si la requete n'est pas dans le cache
                            //Pour ne pas utiliser le cache
                            //checked = null;
                            if(checked == null){
                                if(verbose >=2) System.out.println("\n\n query not in cache : " + q3);
                                //nombreEntier = lectureClavier.nextInt();

                                cptQV++;
                                //EVALUATOR
                                ok = MySQL.checkBQ(q3, sch, dataBase, user, mdp);
                                //ok = true;
                                //System.out.println("Query to check  " + q3 + " rep " + ok);
                                //nombreEntier = lectureClavier.nextInt();
                                //ok = Sparql.checkQuery(q3, schSp);
                                Integer ans = null;
                                if(ok){
                                    ++i;
                                    ans = 1;
                                }
                                else{
                                    ans = -1;
                                }
                                // on ajoute la requete dans le cache avec sa reponse
                                queriesChecked.addInCache(q3, ans);
                            }
                            else{
                                cptQAV++;
                                // la requete est dans le cache, on prend la réponse
                                if(checked==1){
                                    ok = true;
                                    ++i;
                                }
                                else{
                                    ok = false;
                                }
                            }
                        }

                        if(ok){
                            if(verbose >=2) System.out.println(" answer is valide \n");
                            ansQueryValidSet.add(q2);
                        }
                        else{
                            if(verbose >=2) {
                                if(q3.getHead().getName()=="?"){
                                    System.out.println(" answer is not valide because  " + q3 + " has answers in BDD \n");
                                }
                                else{
                                    System.out.println(" answer is not valide because  " + q3 + " has no answers in BDD \n");
                                }
                            }
                        }
                    }
                } catch (IOException e1){
                    System.out.println("Error reading " + e1.getMessage());
                }
                if(ansQuerySet.size()<5000){
                    ended = true;
                }
            } // while not ended
        }catch (FileNotFoundException e2){
            System.out.println("File not found "+e2.getMessage());
        }
        //System.out.println("Cache after validation :\n" + queriesChecked);
        long tempsFin3 = System.currentTimeMillis();
        seconds = (tempsFin3 - tempsFin2) / 1000F;
        System.out.println("validation effectuée en: "+ Float.toString(seconds) + " secondes.");
        System.out.println("Number of queries in cache : " + queriesChecked.size());
        System.out.println("Number of new queries for validation : " + cptQV);
        System.out.println("Number of queries allready validated " + cptQAV);
        System.out.println("Number of respons after algo1: "+cpt);
        System.out.println("Number of respons : "+ansQueryValidSet.size());
        System.out.println(" Validate respons for query " + q1 + " \n are ");
        for(Rule rs : ansQueryValidSet){
            System.out.println(rs.getHead());
        }
        System.out.println("Cache after validation :\n" + queriesChecked);

        //instantiate a table from answers
        this.result = new Relation(q1.getHead().getIdList(), ansQueryValidSet);

        this.lastResult = result;
        
        this.result.print();

    }

    public Relation processAggQuery(Query q, Map aggreagation, String headVar) {

        processQuery(q, "");


        Operators basicOpr = new Operators();

        //result = basicOpr.aggregate(result, "", "total", "size", "0");
        this.result = basicOpr.aggregate(result, aggreagation);

        this.result.print();

        this.lastResult = result;

        return result;


    }

    public Relation getLastResult(){
        return this.lastResult;
    }
}