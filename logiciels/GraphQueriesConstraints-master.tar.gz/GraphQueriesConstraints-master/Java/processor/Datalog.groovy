package processor

import org.antlr.v4.runtime.tree.TerminalNode
import parser.datalogBaseVisitor
import parser.datalogLexer
import parser.datalogParser
import processor.algebra.Relation
import processor.algebra.Constants

/**
 * Created by luizcelso on 25/12/16.
 */
class Datalog extends datalogBaseVisitor {
    LinkedListRules keyConstraintsSet, posConstraintsSet, negConstraintsSet, infRulesSet, queriesSet, currentSet;
    ArrayListSchema sch, schSp;
    String dataBase, user, mdp;
    Map aggregation = [:];
    List querySchema = [];
    Processor processor;


    public Datalog(){
        sch = new ArrayListSchema();
        keyConstraintsSet = new LinkedListRules();
        posConstraintsSet = new LinkedListRules();
        negConstraintsSet = new LinkedListRules();
        infRulesSet = new LinkedListRules();
        queriesSet = new LinkedListRules();
        currentSet = infRulesSet;
        processor = new MemoryProcessor();
    }


    Processor getProcessor() {  return processor; }

    @Override public Object visitScheme(datalogParser.SchemeContext ctx) {
        //System.out.println("==scheme===" + ctx.getText());
        sch.addFromString(ctx.getText());

        return visitChildren(ctx);
    }

    @Override public Object visitSchemeList(datalogParser.SchemeListContext ctx) {
        Object o = visitChildren(ctx);
        processor.setSchema(this.sch);
        return o;
    }

//    @Override public Object visitImportScheme(datalogParser.ImportSchemeContext ctx) {
//        /* initialisation of the graph schema liste of predicate(attributs) */
//        sch.initFromFile(ctx.d.getText().replace("'","").trim()+"ArrayListSchema");
//        return visitChildren(ctx);
//    }

    @Override public Object visitImportFacts(datalogParser.ImportFactsContext ctx) {
        dataBase = ctx.db.getText().replace("'","").trim();
        user = ctx.u.getText().replace("'","").trim();
        mdp = ctx.mdp.getText().replace("'","").trim();
        processor = new MySQLProcessor(sch, dataBase, user, mdp);
        return visitChildren(ctx);
    }

    @Override public Object visitFact(datalogParser.FactContext ctx) {
        String predicate = ctx.ID();
        List values = visit(ctx.valueList());
        this.processor.addFact(predicate, values);
        return visitChildren(ctx);
    }

    @Override public Object visitInfRulesList(datalogParser.InfRulesListContext ctx) {
        this.currentSet = this.infRulesSet;
        return visitChildren(ctx);
    }

    @Override public Object visitImportInfRules(datalogParser.ImportInfRulesContext ctx) {
        /* initialisation of inference rules */
        infRulesSet = LinkedListRules.initFromFile(ctx.d.getText().replace("'","").trim()+"InfRule");
        return visitChildren(ctx);
    }

    @Override public Object visitPosRulesList(datalogParser.PosRulesListContext ctx) {
        this.currentSet = this.posConstraintsSet;
        return visitChildren(ctx);
    }

    @Override public Object visitImportPosRules(datalogParser.ImportPosRulesContext ctx) {
        /* initialisation of inference rules */
        infRulesSet = LinkedListRules.initFromFile(ctx.d.getText().replace("'","").trim()+"PosConstraint");
        return visitChildren(ctx);
    }

    @Override public Object visitKeyRulesList(datalogParser.KeyRulesListContext ctx) {
        this.currentSet = this.keyConstraintsSet;
        return visitChildren(ctx);
    }

    @Override public Object visitImportKeyRules(datalogParser.ImportKeyRulesContext ctx) {
        /* initialisation of inference rules */
        keyConstraintsSet = LinkedListRules.initFromFile(ctx.d.getText().replace("'","").trim()+"KeyConstraint");
        return visitChildren(ctx);
    }

    @Override public Object visitNegRulesList(datalogParser.NegRulesListContext ctx) {
        this.currentSet = this.negConstraintsSet;
        return visitChildren(ctx);
    }

    @Override public Object visitImportNegRules(datalogParser.ImportNegRulesContext ctx) {
        /* initialisation of inference rules */
        negConstraintsSet = LinkedListRules.initFromFile(ctx.d.getText().replace("'","").trim()+"NegConstraint");
        return visitChildren(ctx);
    }

    @Override public Object visitRuleA(datalogParser.RuleAContext ctx) {
        //System.out.println("==rule===" + ctx.getText());
        try{
            this.currentSet.add(Rule.stringToRule(ctx.getText().substring(0, ctx.getText().length()-1)));
        }
        catch(SyntaxError e){
            System.out.println(e.getMessage());
        }
        return visitChildren(ctx);
    }

    @Override public Object visitNegRuleA(datalogParser.NegRuleAContext ctx) {
        try {
            this.currentSet.add(Rule.stringToRule(ctx.getText().substring(0, ctx.getText().length() - 1)));
        } catch (SyntaxError e) {
            System.out.println(e.getMessage());
        }
        return visitChildren(ctx);
    }

    @Override public Object visitSimpleQuery(datalogParser.SimpleQueryContext ctx) {
        Query q;

        q = new Query(visit(ctx.atom()), visit(ctx.atomList()));

        AssignExpression assignExpr = null;

        //if query has an assignment expression, create such object
        if (ctx.assigExpression()) {
            assignExpr = new AssignExpression(ctx.assigExpression().ID().getText(), visit(ctx.assigExpression()));
        }

        processor.processQuery(q, assignExpr);
        return visitChildren(ctx);
    }

    @Override public Object visitAggQuery(datalogParser.AggQueryContext ctx) {
        Query q;
        def headVar = ctx.assigAggr().variable.getText();
        def func = ctx.assigAggr().func.getText().replace("count", "size");
        def ids = ctx.idList()?ctx.idList().getText().split(','):[]
        def headElements = ctx.aggQueryHeadAtom().elementList().getText().split(',');
        def bodyElements = ctx.atomList().atom().collect {it.elementList().getText().split(',')}.flatten();
        def aggVar = ctx.assigAggr().variable.getText();
        def par = ctx.assigAggr().val.getText(); //parameter of the aggregation function

        assert ids.every{headElements.contains(it)}, "Variables to aggregate (${ids}) must be in the head of the query (${headElements})."
        
        //def idIndices = ids.collect{id-> headElements.findIndexOf{it==id}}
        def idIndices = ids.collect{id-> bodyElements.findIndexOf{it==id}}  // modif Jac 09/03/2017

        assert headVar == aggVar, "Aggregation variable (${aggVar}) must be the same as the one in the head of the query (${headVar})."

        def varIndex = bodyElements.size(); //variable for the aggregation is in the last position of the body

        assert bodyElements.contains(par), "Parameter of the aggregation function (${par}) must be a variable in the body of the query (${headElements})."

        def parIndex = bodyElements.findIndexOf{it==par};


        def agg = [ids:idIndices, variable: varIndex, function: func, parameter:parIndex]

        q = new Query(visit(ctx.aggQueryHeadAtom()), visit(ctx.atomList()));

        processor.processAggQuery(q, agg, headVar);

        //println "Aggregation: " + agg

        return visitChildren(ctx);

    }

    @Override public Object visitMapQuery(datalogParser.MapQueryContext ctx) {
        Query q;
        def headVar = ctx.assigExpression().variable.getText();
        def headElements = ctx.atom(0).elementList().getText().split(',');
        def bodyElements = ctx.atom(1).elementList().getText().split(',');
        //bodyElements.add(ctx.atom(2).elementList().getText().split(','));
        def assignExpr = new AssignExpression(ctx.assigExpression().ID().getText(), visit(ctx.assigExpression()))

        ArrayList<Atome> bodyAtoms = new ArrayList<Atome>();
        bodyAtoms.add(visit(ctx.atom(1)));
        bodyAtoms.add(visit(ctx.atom(2)));

        //KnowsCount(s,c):-aggr(Knows(s,d),s,c=count(d)).
        //NewRanks(n,s,r):-map(Rank(s,r0),Knows(s,n),r= 0.85*r0/c).
        q = new Query(visit(ctx.atom(0)), bodyAtoms);

        processor.processMapQuery(q, assignExpr);
        return visitChildren(ctx);
    }

    @Override public Object visitBetaQuery(datalogParser.BetaQueryContext ctx) {
        Query q;



        def func = ctx.reduce.func.getText().replace("count", "size");
        def ids = ctx.idList()?ctx.idList().getText().split(','):[]
        def aggVar = ctx.reduce.variable.getText();
        def par = ctx.reduce.val.getText(); //parameter of the aggregation function

        def n = ctx.n.getText().toInteger();

        def headElements = ctx.head.elementList().getText().split(',');
        List bodyElements = ctx.nodes.elementList().getText().split(',');
        bodyElements.add(ctx.links.elementList().getText().split(','));

        def headVar = ""+headElements.findIndexOf{it==aggVar};

        assert ids.every{headElements.contains(it)}, "Variables to aggregate in reduce (${ids}) must be in the head of the query (${headElements})."

        def idIndices = ids.collect{id-> headElements.findIndexOf{it==id}}

        //assert headVar == aggVar, "Aggregation variable (${aggVar}) must be the same as the one in the head of the query (${headVar})."

        def varIndex = bodyElements.size(); //variable for the aggregation is in the last position of the body

        assert bodyElements.contains(par), "Parameter of the aggregation function (${par}) must be a variable in the body of the query (${headElements})."

        def parIndex = bodyElements.findIndexOf{it==par};




        def reduceAssigAgg = [ids:idIndices, variable: varIndex, function: func, parameter:parIndex]

        def mapAssignExpr = new AssignExpression(ctx.map.ID().getText(), ""+visit(ctx.map))

        def updateAssignExpr = new AssignExpression(ctx.update.ID().getText(), ""+visit(ctx.update))




        ArrayList<Atome> bodyAtoms = new ArrayList<Atome>();
        bodyAtoms.add(visit(ctx.nodes));
        bodyAtoms.add(visit(ctx.links));

        //KnowsCount(s,c):-aggr(Knows(s,d),s,c=count(d)).
        //NewRanks(n,s,r):-map(Rank(s,r0),Knows(s,n),r= 0.85*r0/c).
        q = new Query(visit(ctx.atom(0)), bodyAtoms);

        //System.out.println("before BetaQuery with Query"+q+" n = " +n+" mapAssExp : "+mapAssignExpr+" reduceAssigAgg : "+ reduceAssigAgg);
        //System.out.println("Update exp : " + updateAssignExpr + " headVar : "+ headVar);

        processor.processBetaQuery(q, n, mapAssignExpr, reduceAssigAgg, updateAssignExpr, headVar);
        return visitChildren(ctx);
    }

    @Override public Object visitQueryList(datalogParser.QueryListContext ctx) {
        processor.setInfRulesSet(this.infRulesSet);
        processor.setPosConstraintsSet(this.posConstraintsSet);
        processor.setNegConstraintsSet(this.negConstraintsSet);
        processor.setKeyConstraintsSet(this.keyConstraintsSet);


        System.out.println("Inference Rules " + infRulesSet);
        System.out.println("Positives Constraints " + posConstraintsSet);
        System.out.println("Negatives Constraints " + negConstraintsSet);
        System.out.println("Key Constraints " + keyConstraintsSet);
//        System.out.println("Queries : " + queriesSet);
        System.out.println("ArrayListSchema "+ sch);

        //this.currentSet = this.queriesSet;
        return visitChildren(ctx);
    }

    @Override public Object visitDatalogProgram(datalogParser.DatalogProgramContext ctx) {
        return visitChildren(ctx);
    }

    @Override public Atome visitAtom(datalogParser.AtomContext ctx) {
        return new Atome(ctx.ID().getText(), visit(ctx.elementList()));
    }

    @Override public Atome visitAggQueryHeadAtom(datalogParser.AggQueryHeadAtomContext ctx) {
        return new Atome(ctx.ID(0).getText(), visit(ctx.elementList()));
    }


    @Override public ArrayList<Atome>  visitAtomList(datalogParser.AtomListContext ctx) {
        ArrayList<Atome> body = new ArrayList<>();
        for (int i = 0; i < ctx.getChildCount(); i++)
            if (ctx.getChild(i) instanceof datalogParser.AtomContext) body.add(visit(ctx.getChild(i)));
        return body;
    }

    @Override public List visitValueList(datalogParser.ValueListContext ctx) {
        List l = [];
        for (int i = 0; i < ctx.getChildCount(); i++) {

            if (ctx.getChild(i) instanceof TerminalNode) {
                TerminalNode v = (TerminalNode)ctx.getChild(i);
                switch(v.getSymbol().getType()){
                    case datalogLexer.FLOAT:
                        l.add(v.getText().toFloat());
                        break;

                    case datalogLexer.INT:
                        l.add(v.getText().toInteger());
                        break;

                    case datalogLexer.STRING:
                        l.add(v.getText()[1..-2]);//removes quotation marks from strings
                        break;
                }
            }
        }
        return l;
    }

    @Override public ArrayList<Element> visitElementList(datalogParser.ElementListContext ctx) {
        ArrayList<Element> tuple = new ArrayList<>();
        for (int i = 0; i < ctx.getChildCount(); i++) {
            if (ctx.getChild(i) instanceof datalogParser.ElementContext) {
                TerminalNode v = (TerminalNode)ctx.getChild(i).getChild(0);
                switch(v. getSymbol().getType()){
                    case datalogLexer.FLOAT:
                        tuple.add(new Constant(v.getText(), Float));
                        break;
                    case datalogLexer.INT:
                        tuple.add(new Constant(v.getText(), Integer));
                        break;
                    case datalogLexer.STRING:
                        tuple.add(new Constant(v.getText()[1..-2])); //removes quotation marks from strings
                        break;
                    default:
                        tuple.add(new Variable(v.getText()))
                }
            }
        }
        return tuple;
    }

    @Override public String visitAssigExpression(datalogParser.AssigExpressionContext ctx) {
        return visit(ctx.expr())
    }

    @Override public String visitExpr_pm(datalogParser.Expr_pmContext ctx) { return visit(ctx.expr(0)) + ctx.op.text + visit(ctx.expr(1)) }

    @Override public String visitExpr_md(datalogParser.Expr_mdContext ctx) { return visit(ctx.expr(0)) + ctx.op.text + visit(ctx.expr(1)) }

    @Override public String visitExpr_int(datalogParser.Expr_intContext ctx) { return ctx.text }

    @Override public String visitExpr_float(datalogParser.Expr_floatContext ctx) { return ctx.text + 'f'}

    @Override public String visitExpr_parens(datalogParser.Expr_parensContext ctx) { return "(" + visit(ctx.expr()) + ")" }

    @Override public String visitExpr_var(datalogParser.Expr_varContext ctx) { return 'it[' + ctx.text + ']'} //the variable's name must be replaced by the position of the variable in the relation


    //Beta-temporary (adaptation of the relational beta). To be replaced with Datalog Beta

    @Override public String visitExpr_tableid(datalogParser.Expr_tableidContext ctx) { return "it." + ctx.QUALIFIED_ID().text.replace(".", "_") }

    @Override public String visitExp_agg(datalogParser.Exp_aggContext ctx) {
        def l = ctx.list_identifiers().text.split(',')*.trim() //.collect{"it." + it}
        def agg = ctx.aggr.text.toLowerCase()
        return "$l.$agg()"
    }

    @Override public List visitAssig_aggr(datalogParser.Assig_aggrContext ctx) {

        def by = ctx.idList().text.split(',')*.trim()
        def agg = ctx.aggr.text //.toLowercase()
        return [by, [aggr: agg.toLowerCase(), func: "it.${ctx.attribute.text}", as: ctx.attribute.text]]
    }
/*
    @Override public Relation visitBetaQuery(datalogParser.BetaQueryContext ctx) {

        def memory = ((MemoryProcessor) this.processor).db
        def opr = ((MemoryProcessor) this.processor).basicOpr


        assert memory[ctx.r.text], "Runtime error: Table ${ctx.r.text} not declared."
        def r = memory[ctx.r.text]

        assert memory[ctx.v.text], "Runtime error: Table ${ctx.v.text} not declared."
        def v = memory[ctx.v.text]

        assert memory[ctx.e.text], "Runtime error: Table ${ctx.e.text} not declared."
        def e = memory[ctx.e.text]

        def n = ctx.n.text.toInteger()

        ((MemoryProcessor) this.processor).db

        def dir
        switch(ctx.dir.text){
            case 'IN':
                dir = Constants.INBOUND
                break
            case 'OUT':
                dir = Constants.OUTBOUND
                break
            default:
                dir = Constants.BOTH
                break
        }

        def labels = ctx.idList().text.split(',')*.trim()

        def set = visit(ctx.set)

        def map = visit(ctx.map)

        List reduce = visit(ctx.reduce)

        def update = visit(ctx.update)

        println "$r, $e, $n, $v, $labels,\n $set, $map, $update"
        println reduce

        Relation t = opr.beta(r, v, e, n, { true }, dir, labels, [set] as List, [map] as List, reduce[0] as List, [reduce[1]] as List, [update] as List)


        //        rConnSmall = basicOpr.beta(rConnSmall, eConn, new Table(), 4, { true }, Constants.BOTH, ['connects'], ["it.minDist = 0.0f", "it.maxDist = 0.0f"], ["it.minDist = it.minDist + it.E_Weight.toFloat()", "it.maxDist = it.maxDist + it.E_Weight.toFloat()"], ["id_n", "id"], [[aggr: "min", func: "it.minDist", as: "minDist"], [aggr: "max", func: "it.maxDist", as: "maxDist"]], ["current.minDist = [newV.minDist, current.minDist].min()", "current.maxDist = [newV.maxDist, current.maxDist].max()"])


        t.print()
        System.exit(0)
        return t
    }

*/



}