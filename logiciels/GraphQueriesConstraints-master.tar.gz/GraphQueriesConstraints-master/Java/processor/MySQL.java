package processor;

import java.util.ArrayList;
import java.sql.*;
import java.io.*;

class MySQL{
	boolean connecte=false;
    Connection mysql=null;
    
    MySQL(String db, String login, String mdp){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver processor.MySQL non trouvé?");
			mysql=null;
			return;
		}
		
		try {
			String nomServeur = "localhost";
			//String nomBase = "test";
			String nomBase = db;
			String loginMySQL = login;
			String mdpMySQL=mdp;
			mysql = DriverManager.getConnection("jdbc:mysql://"+nomServeur+":3306/"+nomBase,loginMySQL, mdpMySQL);
			connecte=true;
		} catch (SQLException e) {
			System.out.println("Echec de connexion!"); 
			System.out.println(e.getMessage());
			mysql=null;
			return;
		}

		if(connecte){
			//System.out.println("Suis connecté!");
		}
	}
    
    //static processor.LinkedListRules answer(processor.Query q1, processor.ArrayListSchema sch, String db, String login, String mdp){
    static int answer(Query q1, ArrayListSchema sch, String db, String login, String mdp){
		// retourne le nombre de réponses à la requete Q1, place les réponses dans le fichier ansAlgo1.dlp
		// on crée une nouvelle requête qui a dans la tête toutes les variables du corps
		ArrayList<Element> nhead = new ArrayList<Element>();
		System.out.println("query dans ansswer : "+q1);
		if(q1.getHead().getTuple().size()>0){
			for(Element e : q1.getHead().getTuple()){
				nhead.add(e);
			}
		}
		for(Atome a : q1.getBody()){
			for(Element e : a.getTuple()){
				if(e.isVariable() && !nhead.contains(e)){
					nhead.add(e);
				}
			}
		}
		
		Atome hq2 = new Atome(q1.getHead().getName(), nhead);
		Query q2 = new Query(hq2, q1.getBody());
		
		System.out.println("processor.Query to answer : "+q2);
		String s2 = q2.queryToSQL(sch);
		System.out.println("SQL processor.Query to answer : "+s2);
		
		LinkedListRules res = new LinkedListRules();
		//on ouvre une connexion
		MySQL connex = new MySQL(db, login, mdp);
		int cpt=0;
		if(connex.connecte){
			try{
				Statement s=connex.mysql.createStatement();
				ResultSet rs=s.executeQuery(s2);
				/* while(rs.next() && cpt<5000){
					cpt++;
					//System.out.println(cpt);
					// on crée une nouvelle substitution
					processor.Substitution sub = new processor.Substitution();
					for(int i=0; i<hq2.getTuple().size(); ++i){
						sub.putValue((processor.Variable)hq2.getTuple().get(i), new processor.Constant(rs.getString(i+1)));
					}
					processor.Rule rep = sub.applySub(q1);
					res.add(rep);
					//System.out.println("Une réponse de plus"+rep);
					//System.out.println(rs.getString("nomLieu"));
				} */
				try {
					// open the file named ansAlgo1.dlp in the current directory
					FileWriter fw = new FileWriter("./ansAlgo1.dlp");

					while(rs.next()){
						cpt++;
						//System.out.println(cpt);
						// on crée une nouvelle substitution
						Substitution sub = new Substitution();
						for(int i=0; i<hq2.getTuple().size(); ++i){
							sub.putValue((Variable)hq2.getTuple().get(i), new Constant(rs.getString(i+1)));
						}
						Rule rep = sub.applySub(q1);
						fw.write(rep.toString()+".\n");
						//System.out.println("Une réponse de plus"+rep);
						//System.out.println(rs.getString("nomLieu"));
					}
					fw.flush();
					fw.close();
				}catch (IOException e2){
					System.out.println("Can't create file "+e2.getMessage());
				}
			}catch(SQLException e){
				System.out.println("Pb "+e.getMessage());
			}
			
			// on ferme la connexion
			try{
				connex.mysql.close();
			}catch(SQLException e){
				System.out.println("Pb close connexion"+e.getMessage());
			}
		}
		//return res; 
		return cpt; 
	}
	static boolean checkBQ(Query q3, ArrayListSchema sch, String db, String login, String mdp){
		if(q3.getBody().get(0).getName().equals("!")){
			return false;
		}
		
		if(QS.verbose >= 2) System.out.println("processor.Query to check : "+q3);
		String s3 = q3.queryToSQL(sch);
		if(QS.verbose >= 2) System.out.println("processor.Query traduct : "+s3);

		
		boolean res = false;
		MySQL connex = new MySQL(db, login, mdp);
		if(connex.connecte){
			try{
				Statement s=connex.mysql.createStatement();
				ResultSet rs=s.executeQuery(s3);
				//System.out.println("sql version : "+s3);
				// si il s'agit d'une requete négative 
				if(q3.getHead().getName()=="?"){
					// s'il y a au moins une réponse la requète n'est pas valide
					if(rs.next()){
						res = false;
					}
					else{
						res = true;
					}
				}
				else{ // c'est une requète positive
					// s'il y a au moins une réponse la requète n'est pas valide
					if(rs.next()){
						res = false;
					}
					else{
						res = true;
					}
				}
			}catch(SQLException e){
				System.out.println("Pb "+e.getMessage());
			}
			
			// on ferme la connexion
			try{
				connex.mysql.close();
			}catch(SQLException e){
				System.out.println("Pb close connexion"+e.getMessage());
			}
		}
		return res;
	}
}
