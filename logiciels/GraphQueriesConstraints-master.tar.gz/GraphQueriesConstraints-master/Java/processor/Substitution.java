package processor;

import java.util.*;

class Substitution {
	Map<Variable, Element> sub;
	
	Substitution(){
		sub = new HashMap<Variable, Element>();
	}
	
	Element getValue(Variable v){
		//for(processor.Variable v2 : sub.keySet()){
		//	if(v2.equals(v)){
				return sub.get(v);
		//	}
		//}
		//return null;
	}
	
	void putValue(Variable v, Element e){
		sub.put(v,e);
	}
	
	Substitution duplicate(){
		Substitution res = new Substitution();
		for(Variable v : sub.keySet()){
			res.putValue(v, getValue(v));
		}
		return res;
	}
	
	void completeWith(Substitution s2){
		for(Variable v : s2.sub.keySet()){
			//if(getValue(v)==null)
				putValue(v, s2.getValue(v));
		}
	}
	
	public String toString(){
		String res="";
		for(Variable v : sub.keySet()){
			res+=v+"-->"+getValue(v)+" ";
		}
		return res;
	}
	
	Atome applySub(Atome a){
		ArrayList<Element> s=a.getTuple();
		ArrayList<Element> r = new ArrayList<Element>();
		for(Element e : s){
			if(e.isVariable()){
				Element e2= getValue((Variable)e);
				if(e2 != null){
					if(e2.isVariable()){
						r.add(new Variable(e2.getName()));
					}
					else{
						r.add(e2);
					}
				}
				else{
					r.add(new Variable(e.getName()));
				}
			}
			else{
				r.add(e);
			}
		}
		return new Atome(a.getName(), r);
	}

	Atome applySub2(Atome a, int nbv){
		ArrayList<Element> s=a.getTuple();
		ArrayList<Element> r = new ArrayList<Element>();
		for(Element e : s){
			if(e.isVariable()){
				Element e2= getValue((Variable)e);
				if(e2 != null){
					if(e2.isVariable()){
						r.add(new Variable(e2.getName()));
					}
					else{
						r.add(e2);
					}
				}
				else{
					r.add(new Variable(e.getName()+"_"+nbv));
				}
			}
			else{
				r.add(e);
			}
		}
		return new Atome(a.getName(), r);
	}
	Query applySub(Rule r){
		Atome h = applySub(r.getHead());
		ArrayList<Atome> b = new ArrayList<Atome>();
		for(Atome a : r.getBody()){
			b.add(applySub(a));
		}
		return new Query(h,b);
	}
	
	Rule applySub2(Rule r){
		Atome h = applySub(r.getHead());
		ArrayList<Atome> b = new ArrayList<Atome>();
		for(Atome a : r.getBody()){
			b.add(applySub(a));
		}
		return new Rule(h,b);
	}	
}
