package processor;

import java.util.*;
import java.io.*;

class Cache{
	Map<Query, Integer> queries;
	
	Cache(){
		queries = new HashMap<Query, Integer>();
	}
	
	int size(){
		return queries.size();
	}
	public String toString(){
		
		String res = ""; //+queries;
		for(Query q : queries.keySet()){
			Integer ans = queries.get(q);
			res += q + " answer : ";
			 if(ans == null){
				res += "unkown";
			}
			else{
				if(ans == 1){
					res += "True";
				}
				else{
					res += "False";
				}
			} 
			res += "\n";
		}
		return res;
	}
		
	Integer isInCache(Query q){		
		//System.out.println("Suis la avec queries = "+ queries + "***" + q + "===");
		return queries.get(q);
	}
	
	void addInCache(Query q, int ans){
		queries.put(q,ans);
	}
	
	static Cache initFromAns2File(String nameFile){
		Cache res = new Cache();
		Query r = null;

		try {
			// open the file named nameFile.dlp in the repertory ./Constraint/
			//File f = open("./Constraint/"+nameFile+".dlp");
			FileReader fr = new FileReader("./"+nameFile+".dlp");
			BufferedReader br = new BufferedReader(fr);
			
			try {
				String rule = "";
				String line = br.readLine();
				while(line != null){
					//line = line.replace(" ", "");
					line = LinkedListRules.delSpace(line);
					if(line == null) { }
					else if(line.length() == 0) { }
					else if(line.charAt(0)=='%') { }
					else if(line.charAt(line.length()-1) != '.'){
						rule += line;
					}
					else{
						int pos=0;
						int ans;
						// on supprime le point à la fin
						rule += line.substring(0, line.length()-1);
						try{							
							//System.out.println("String to transform in query : "+rule);
							// on récupère la réponse Yes ou No
							if(rule.charAt(0)=='N'){
								ans = -1;
								pos = 4;
							}
							else if(rule.charAt(0)=='Y'){
								ans = 1;
								pos = 5;
							}
							else{
								throw new SyntaxError("No. or No missing before BCquery");
							}
							// supprime Yes or No
							rule = rule.substring(pos);
							// remet la query dans le bon sens ? :- 
							pos = rule.indexOf("?");
							String tete = rule.substring(pos);
							rule  = rule.substring(0, pos-3);
							rule = tete+" :- "+rule;
							System.out.println("String to transform in query : "+rule);
							r = (Query)Rule.stringToRule(rule);
							res.addInCache(r, ans);
							rule = "";
						}catch(SyntaxError e){
							System.out.println(e.getMessage());
							rule = "";
						}
					}
					line = br.readLine();
				}
			} catch (IOException e1){
				System.out.println("Error reading " + e1.getMessage());
			}
		}catch (FileNotFoundException e2){
			System.out.println("File not found "+e2.getMessage());
		} 
		return res;
	}
}

