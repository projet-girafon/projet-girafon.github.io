package processor;

import java.util.ArrayList;
import java.io.*;

class ArrayListSchema extends ArrayList<Atome>{


	String getAttribut(String predicat, int i)throws SyntaxError {
		// return name of the attribute number i of predicat
		for(Atome a: this){
			if(a.getName().equals(predicat)){
				if(i<a.getTuple().size()){
					return a.getTuple().get(i).getName();
				}
				else{
					throw new SyntaxError("Predicat "+predicat+" has not "+(i+1) + " attributes  in schema");
				}
			}
		}
		throw new SyntaxError("Predicat "+predicat+" not in schema");
	}

	public String toString(){
		return this.toString();
	}

	void addFromString(String s){
		//adds a scheme from a string (to be used inside the parser)
		try{
			this.add(Atome.stringToAtome(s.substring(0, s.length()-1)));
		}catch(SyntaxError e){
			System.out.println(e.getMessage());
		}
	}
	
	void initFromFile(String nameFile){
		Atome a;

		try {
			// open the file named nameFile.dlp in the repertory ./Constraint/
			//File f = open("./Constraint/"+nameFile+".dlp");
			FileReader fr = new FileReader("./"+nameFile+".dlp");
			BufferedReader br = new BufferedReader(fr);
			
			try {
				String pred="";
				String line = br.readLine();
				while(line != null){
					line = line.replace(" ", "");
					if(line == null) { }
					else if(line.length() == 0) { }
					else if(line.charAt(0)=='%') { }
					else if(line.charAt(line.length()-1) != '.'){
						pred += line;
					}
					else{
						pred += line.substring(0, line.length()-1);
						try{
							//System.out.println("String to transform in defintion of predicat : "+pred);
							a = Atome.stringToAtome(pred);
							this.add(a);
							pred = "";
						}catch(SyntaxError e){
							System.out.println(e.getMessage());
						}
					}
					line = br.readLine();
				}
			} catch (IOException e1){
				System.out.println("Error reading " + e1.getMessage());
			}
		}catch (FileNotFoundException e2){
			System.out.println("File not found "+e2.getMessage());
		}
	}

}
