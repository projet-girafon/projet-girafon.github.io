package processor;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import parser.datalogLexer;
import parser.datalogParser;
import processor.algebra.Relation;

class Evaluator {

    //    LinkedListRules keyConstraintsSet, posConstraintsSet, negConstraintsSet, infRulesSet, queriesSet, currentSet;
//    ArrayListSchema sch, schSp;
//    String dataBase;
//    String user;
//    String mdp;
    String directory;
    Processor processor;
    Relation result = new Relation();

    Datalog parser;

    /*Evaluator(String dir){
        directory = dir;

    }*/
    /*
    Evaluator(){
        sch = new ArrayListSchema();
        keyConstraintsSet = new LinkedListRules();
        posConstraintsSet = new LinkedListRules();
        negConstraintsSet = new LinkedListRules();
        infRulesSet = new LinkedListRules();
        queriesSet = new LinkedListRules();
        currentSet = infRulesSet;
    }
*/






    public Relation processProgram(String p){

        //System.out.println(q);
        ANTLRInputStream input = new ANTLRInputStream(p);
        datalogLexer lexer = new datalogLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        datalogParser parser = new datalogParser(tokens);
        ParseTree tree = parser.datalogProgram();
        System.out.println(tree.toStringTree(parser)); // print LISP-style tree

        this.parser = new Datalog();

        this.parser.visit(tree);
        //processor = this.parser.getProcessor();


/*
        dataBase = this.parser.getDataBase();
        user = this.parser.getUser();
        mdp = this.parser.getMdp();
*/


		/* initialisation of the sparql schema liste of predicate(type) */
		/* used for sparql translation */
        //TODO: check how to add Sparql to the parser
        //schSp = new ArrayListSchema();
        //schSp.initFromFile(directory+"SchemaSparql");
        //System.out.println("SchemaSparql : "+schSp);



        return this.parser.getProcessor().getLastResult();
    }



    public static void main(String[] args) throws IOException{

        //String program = new String(Files.readAllBytes(Paths.get("/home/luizcelso/Dropbox/workspace/GLog/Java/Examples/SimpleGraphABC/query.dlp")));
        String program = new String(Files.readAllBytes(Paths.get("/home/chabin/workspace/GraphQueriesConstraints/Java/Examples/Clinic/queryMinCfpAlesia.dlp")));
        //String program = new String(Files.readAllBytes(Paths.get("/home/chabin/workspace/GraphQueriesConstraints/Java/Examples/Restaurants/query.dlp")));
        //String program = new String(Files.readAllBytes(Paths.get("/home/chabin/workspace/GraphQueriesConstraints/Java/Examples/Bill_of_material/query.dlp")));
        //String program = new String(Files.readAllBytes(Paths.get("/home/chabin/workspace/GraphQueriesConstraints/Java/Examples/Prof/full.dlp")));


        //String program = new String(Files.readAllBytes(Paths.get("/home/luizcelso/Dropbox/workspace/GLog/Java/Examples/SimpleGraphABC/query.dlp")));
        //String program = new String(Files.readAllBytes(Paths.get("/home/luizcelso/Dropbox/workspace/GLog/Java/Examples/Restaurants/query.dlp")));
        //String program = new String(Files.readAllBytes(Paths.get("/home/chabin/workspace/GraphQueriesConstraints/Java/Examples/Prof/full.dlp")));

        Evaluator eval = new Evaluator();
        //Evaluator eval = new Evaluator("Examples/Restaurants/");
        //Evaluator eval = new Evaluator("Examples/Prof/");

        eval.processProgram(program);



    }
}