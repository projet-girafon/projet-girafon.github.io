package processor;

class Variable extends Element{
    Variable(String n){
        super(n,1);
    }
    boolean isVariable(){return true;}
    boolean isConstant(){return false;}

    /* public boolean equals(Object x){
		if(x instanceof processor.Variable){
			processor.Variable a = (processor.Variable)x;
			String anom;
			int pos = a.name.indexOf("New");
			if(pos != -1){
				anom = a.name.substring(0, pos);
			}
			else{
				anom = a.name;
			}
			String nom;
			pos = name.indexOf("New");
			if(pos != -1){
				nom = name.substring(0, pos);
			}
			else{
				nom = name;
			}
			boolean res = nom.equals(anom);
			System.out.println("Compare : "+name+" "+nom+" et "+a.name+" " + anom+" return "+res);
			return res;
		}
		else{
			return false;
		}
	} */
}
