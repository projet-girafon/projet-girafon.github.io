package processor;

import java.util.ArrayList;

class Atome{
	String name;
	ArrayList<Element> tuple;
	Atome(String n, ArrayList<Element> t){
		name = n;
		tuple = new ArrayList<Element>();
		if(t!=null){
			for(Element s : t){
				tuple.add(s);
			}
		}
	}
	Atome(String n, Element[] t){
		name = n;
		tuple = new ArrayList<Element>();
		for(Element s : t){
			tuple.add(s);
		}
	}

	Atome(String n){
		name=n;
		tuple = null;
	}

	ArrayList<Element> getTuple(){return tuple;}
	String getName(){return name;}

	public String toString(){
		String res = name;
		if(tuple != null){
			res +="(";
			int cpt = 0;
			for(Element s : tuple){
				if(cpt == 0){
					res += s;
				}
				else{
					res = res + ", " + s;
				}
				cpt++;
			}
			res += ")";
		}
		return res;
	}

	public ArrayList<String> getIdList(){
		ArrayList<String> res = new ArrayList<String>();
		if(tuple != null){
			for(Element s : tuple)
				res.add(s.toString());
		}
		return res;
	}


	ArrayList<String> listeVarNew(){
		ArrayList<String> res = new ArrayList<String>();
		for(Element e : tuple){
			if(e.isVariable() && e.getName().indexOf("New") != -1){
				res.add(e.getName());
			}
		}
		return res;
	}

	public boolean containsOldNewVar(ArrayList<Atome> liste){
		// retourne Vrai si l'atome contient une variable New qui est déjà dans la liste
		ArrayList<String> newVara = listeVarNew();
		if(newVara.size()==0){
			return false;
		}
		else{
			ArrayList<String> newVarListe = new ArrayList<String>();
			for(Atome b : liste){
				newVarListe.addAll(b.listeVarNew());
			}
			for(String v : newVara){
				if(newVarListe.contains(v)){
					return true;
				}
			}
		}
		return false;
	}

	public boolean rename(String vo, String vn){
		boolean res = false;
		for(Element e : tuple){
			if(e.getName().equals(vo)){
				res = true;
				e.putName(vn);
			}
		}
		return res;
	}

	public void renameOldNewVar(ArrayList<Atome> liste){
		// renome les variables New de la liste qui sont aussi dans l'atome (ce ne sont plus des New)
		ArrayList<String> newVara = listeVarNew();
		if(newVara.size()!=0){
			for(String v : newVara){
				int pos = v.indexOf("New");
				String vn = v.substring(0,pos)+"Old"+v.substring(pos+3);
				System.out.println(" renomage v "+v+ " en "+vn);
				ArrayList<String> newVarListe = new ArrayList<String>();
				boolean ok = false;
				for(Atome b : liste){
					if(b.rename(v, vn)){
						ok = true;
					}
				}
				if(ok){
					rename(v,vn);
				}
			}
		}
	}

	static boolean varPresentIn(String v, ArrayList<Atome> liste){
		// retourne true si la variable v est présente dans les atomes de la liste
		for(Atome a : liste){
			for(Element e : a.getTuple()){
				if(e.getName().equals(v)){
					return true;
				}
			}
		}
		return false;
	}

	public void putRedOldNewVar(ArrayList<Atome> liste){
		// rend non "reductible"(pour la comparaison) les variables new de l'atome qui sont déjà dans la liste
		ArrayList<Element> ae=tuple;
		int pos;
		String nom;
		for (Element e : ae){
			nom = e.getName();
			pos = nom.indexOf("New");
			if(pos != -1){
				if(varPresentIn(e.getName(), liste)){
					e.putRed(false);
				}
			}
		}
	}

	boolean identiqueModuloNew(Atome b){
		// retourne true si les deux atomes sont identiques modulo le renomage des variables nouvelles
		if(name.equals(b.name)){
			for(int i=0; i<tuple.size(); ++i){
				if(tuple.get(i).identiqueModuloNew(b.tuple.get(i)) == false)
					return false;
			}
			return true;
		}
		else{
			return false;
		}
	}

	boolean isEqual(Atome b){
		if(name.equals(b.name)){
			for(int i=0; i<tuple.size(); ++i){
				if(tuple.get(i).isEqual(b.tuple.get(i)) == false)
					return false;
			}
			return true;
		}
		else{
			return false;
		}
	}

	public boolean equals(Object x){
		if(x instanceof Atome){
			Atome a = (Atome)x;
			if(name.equals(a.name)){
				for(int i=0; i<tuple.size(); ++i){
					if(tuple.get(i).isEqual(a.tuple.get(i)) == false)
						return false;
				}
				return true;
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}

	static Atome stringToAtome(String a) throws SyntaxError {
		if(a.equals("!"))
			return new Atome(a);
		if(a.equals("?"))
			return new Atome(a);
		int pos1, pos2;
		pos1 = a.indexOf("(");
		pos2 = a.indexOf(")");
		if(pos1==-1 || pos2==-1){
			throw new SyntaxError("Syntax error in atome "+a);
		}
		String n = a.substring(0, pos1);
		String l = a.substring(pos1+1, pos2);
		ArrayList<Element> t = new ArrayList<Element>();
		for(String s : l.split(",")){
			//if(s.charAt(0)>='A' && s.charAt(0)<='Z'){
			if(s.charAt(0)=='X'){
				t.add(new Variable(s));
			}
			else{
				if(s.charAt(0)=='"' || s.charAt(0)=='\''){
					s=s.substring(1, s.length()-1);
				}
				t.add(new Constant(s));
			}
		}

		return new Atome(n, t);
	}
	public Atome renameVar(int num){
		ArrayList<Element> newt = new ArrayList<Element>();
		Element e2;
		for(Element e : tuple){
			if(e.isVariable()){
				e2 = new Variable(e.getName()+"New"+num);
				newt.add(e2);
			}
			else{
				newt.add(e);
			}
		}
		return new Atome(name, newt);
	}

	Substitution map(Atome b, Substitution s){
		// return s'°s  such that s'(s(this))==b null if not possible
		if (name.equals(b.name)){
			for(int i=0; i<tuple.size(); ++i){
				if(tuple.get(i).isVariable()){
					Variable vi = (Variable)tuple.get(i);
					if(s.getValue(vi) == null){
						s.putValue(vi, b.tuple.get(i));
					}
					else if(s.getValue(vi).equals(b.tuple.get(i))) {

					}
					else{
						return null;
					}
				}
				else if(tuple.get(i).equals(b.tuple.get(i))){

				}
				else {
					return null;
				}
			}
			return s;
		}
		else{
			return null;
		}
	}

	int mapList(ArrayList<Atome> trg, Substitution s, int pos){
		// return the position after pos in trg such that s(this) = trg[res]
		// -1 if not exists
		int i = pos+1;
		boolean ok = false;
		Substitution s2;
		while(!ok && i < trg.size()){
			s2=s.duplicate();
			s2 = map(trg.get(i), s2);
			if(s2 != null){
				ok = true;
				s.completeWith(s2);
				//System.out.println("La substitution trouvee dans mapList : "+s);
			}
			else{
				i+=1;
			}
		}
		if(!ok){
			return -1;
		}
		else{
			return i;
		}
	}

	int mapList2(ArrayList<Atome> src, Substitution s, int pos){
		// return the position after pos in src such that this = s(src[res])
		// -1 if not exists
		int i = pos+1;
		boolean ok = false;
		Substitution s2;
		while(!ok && i < src.size()){
			s2=s.duplicate();
			s2 = src.get(i).map(this, s2);
			if(s2 != null){
				ok = true;
				s.completeWith(s2);
				//System.out.println("La substitution trouvee dans mapList : "+s);
			}
			else{
				i+=1;
			}
		}
		if(!ok){
			return -1;
		}
		else{
			return i;
		}
	}

	int findElement(Element e, int pos){
		// retourne la première position après pos qui contient l'element e
		// -1 s'il elle n'existe pas
		if(tuple==null){
			return -1;
		}
		pos +=1;
		while(pos < tuple.size()){
			if(tuple.get(pos).equals(e)){
				return pos;
			}
			else{
				pos+=1;
			}
		}
		return -1;
	}

	public boolean contains(Element e){
		return (findElement(e, -1) != -1);
	}
}


