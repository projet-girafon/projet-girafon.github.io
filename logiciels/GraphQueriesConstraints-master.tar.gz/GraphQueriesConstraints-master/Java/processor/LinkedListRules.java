package processor;

import java.util.LinkedList;
import java.io.*;
import java.util.ArrayList;

public class LinkedListRules extends LinkedList<Rule> {
	public static String delSpace(String s){
		String res ="";
		boolean ok = true;
		for(int i=0; i<s.length(); ++i){
			if(s.charAt(i) =='"'){
				ok = !ok;
			}
			if(s.charAt(i)==' '){
				if(!ok){
					res+=s.charAt(i);
				}
			}
			else{
				res+=s.charAt(i);
			}
		}
		return res;
	}

	static LinkedListRules initFromFile(String nameFile){
		LinkedListRules res = new LinkedListRules();
		Rule r = null;

		try {
			// open the file named nameFile.dlp in the repertory ./Constraint/
			//File f = open("./Constraint/"+nameFile+".dlp");
			FileReader fr = new FileReader("./"+nameFile+".dlp");
			BufferedReader br = new BufferedReader(fr);
			
			try {
				String rule = "";
				String line = br.readLine();
				while(line != null){
					//line = line.replace(" ", "");
					line = delSpace(line);
					if(line == null) { }
					else if(line.length() == 0) { }
					else if(line.charAt(0)=='%') { }
					else if(line.charAt(line.length()-1) != '.'){
						rule += line;
					}
					else{
						rule += line.substring(0, line.length()-1);
						try{
							//System.out.println("String to transform in rule : "+rule);
							r = Rule.stringToRule(rule);
							res.add(r);
							rule = "";
						}catch(SyntaxError e){
							System.out.println(e.getMessage());
						}
					}
					line = br.readLine();
				}
			} catch (IOException e1){
				System.out.println("Error reading " + e1.getMessage());
			}
		}catch (FileNotFoundException e2){
			System.out.println("File not found "+e2.getMessage());
		}
		return res;
	}
	
//	static processor.LinkedListRules initFromAnsSparqlFile(String nameFile, processor.Rule q){
	static int initFromAnsSparqlFile(String nameFile, Rule q){
		//processor.LinkedListRules res = new processor.LinkedListRules();
		Rule r = null;
		int nbsol=0;
		
		try {
			// open the file named nameFile.dlp in the repertory ./Constraint/
			//File f = open("./Constraint/"+nameFile+".dlp");
			FileReader fr = new FileReader("./"+nameFile+".dlp");
			BufferedReader br = new BufferedReader(fr);
			
			// trouver la première ligne non vide qui ne commence pas par %
			boolean ok = false;
			String line=" ";
			ArrayList<Variable> vars = new ArrayList<Variable>();
			try {
				while(!ok){
					line = br.readLine();
					if(line == null) { }
					else if(line.length() == 0) { }
					else if(line.charAt(0)=='%') { }
					else ok = true;
				}
			}catch (IOException e1){
				System.out.println("Error reading " + e1.getMessage() + " in file " + nameFile );
			}
			if(ok){
				//System.out.println(line);
				// initialiser la liste des variables
				line = line.replace(" ", "");
				Variable v2;
				Element e2;
				for(String s2 : line.split(",")){
					v2 = new Variable(s2);
					vars.add(v2);
				}
				String s3="XUnknown1";	
				v2 = new Variable(s3);				
				vars.add(v2);
				s3="XUnknown2";					
				v2 = new Variable(s3);				
				vars.add(v2);
				//System.out.println("Liste des variables : "+vars);
				
				try {
					// open the file named ansAlgo1.dlp in the current directory
					FileWriter fw = new FileWriter("./ansAlgo1.dlp");

					Substitution sub=null;
					try{
						line = br.readLine();
						while(line != null){
					
							if(line.length() == 0) { }
							else if(line.charAt(0)=='%') { }
							else {
								// on supprime le numero du début
								int pos = 0;
								while(line.charAt(pos)>='0' && line.charAt(pos) <='9'){
									//System.out.print(line.charAt(pos));
									pos++;
								}
								//System.out.println(".");
								line = line.substring(pos+1);
								//System.out.println("une rep : " + line);
								sub = new Substitution();
								int numv=0;

								for(String s2 : line.split(",")){
									//System.out.println(" constant : " + s2 + " pour " + vars.get(numv));
									e2 = new Constant(s2);
									sub.putValue(vars.get(numv), e2);
									numv++;
								}
								//System.out.println("nbconstants : " + numv);
								//System.out.println("La substitution : " + sub);
								r = sub.applySub(q);
								fw.write(r.toString()+".\n");
								nbsol++;
								//res.add(r);
							}
							line = br.readLine();
						}
					} catch (IOException e1){
						System.out.println("Error reading " + e1.getMessage());
					}
					fw.flush();
					fw.close();
				}catch (IOException e3){
					System.out.println("Can't create file "+e3.getMessage());
				}
			}
		}catch (FileNotFoundException e2){
			System.out.println("File not found "+e2.getMessage());
		} 
		//return res;
		return nbsol;
	}
}
