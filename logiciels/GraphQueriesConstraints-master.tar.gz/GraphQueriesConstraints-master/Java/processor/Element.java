package processor;

abstract class Element implements Comparable{
    String name;
    int typ;
    boolean red;
    Element(String n, int t){
        name=n;
        typ=t;
        red = true;
    }
    abstract boolean isVariable();
    abstract boolean isConstant();
    String getName(){return name;}
    //public String toString(){if(red){return name+'-';} else{return name+'+';}}
    public String toString(){return name;}

	public void putName(String newName){
		name=newName;
	}
	
    boolean getRed(){return red;}
    void putRed(boolean nr){red = nr;}
    
    boolean isEqual(Element b){
		boolean res = name.equals(b.name) && typ==b.typ;
		//System.out.println("CompareICI : "+name+typ+" et "+b.name+b.typ+" return "+res);
		return res;
	}

	boolean identiqueModuloNew(Element b){
		int pos1, pos2;
		if(getRed()){
			pos1 = name.indexOf("New");
		}
		else{
			pos1=-1;
		}
		if(b.getRed()){
			pos2 = b.name.indexOf("New");
		}
		else{
			pos2=-1;
		}
		boolean res;
		if(pos1 != -1 && pos2 != -1){
			String nom = name.substring(0, pos1);
			String bnom = b.name.substring(0, pos2);
			res = nom.equals(bnom);
		}
		else{
			res = name.equals(b.name) && typ==b.typ;
		}
		//System.out.println("CompareICI : "+name+typ+" et "+b.name+b.typ+" return "+res);
		return res;
	}
	
	public boolean equals(Object x){
		if(x instanceof Element){
			Element a = (Element)x;
			boolean res = name.equals(a.name) && typ==a.typ;
			//System.out.println("CompareLA : "+name+typ+" et "+a.name+a.typ+" return "+res);
			return res;
		}
		else{
			return false;
		}
	}
	
	public int hashCode() {
		return (name+typ).hashCode();
    }
    
	public int compareTo(Object x){
		Element e=(Element) x;
		if(typ < e.typ){
			return 1;
		}
		else if(typ > e.typ){
			return -1;
		}
		else{
			return name.compareTo(e.name);
		}
	}
		

}
