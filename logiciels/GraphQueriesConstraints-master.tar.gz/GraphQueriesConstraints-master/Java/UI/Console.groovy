package UI


import groovy.model.DefaultTableColumn
import groovy.model.PropertyModel
import groovy.swing.SwingBuilder
import processor.Evaluator
import processor.algebra.Relation

import javax.swing.JFileChooser
import javax.swing.JTable
import java.awt.BorderLayout       as BL
import javax.swing.WindowConstants as WC
import javax.swing.BorderFactory   as BF

/**
 * Created by luizcelso on 20/12/16.
 */


def defaultQuery = """
Schemes:
    Person(id, name).
    Road(id, name).
    Rest(id,name,desc).
    Class(id, name).
    Knows(person1,person2).
    Likes(person,rest).
    IsA(class1,class2).
    InstanceOf(rest,class).
    Connects(source, target, id, weight).

Facts:
    Person(14,'Andre').
    Person(15,'Ive').
    Person(16,'Celso').
    Person(17,'Bruno').
    Person(18,'Daniel').
    Person(19,'Lucas').
    Person(20,'Jacque').
    Person(21,'Matheus').
    Person(22,'Jordi').

    Road(1,'I1').
    Road(2,'I2').
    Road(3,'I3').
    Road(4,'I4').
    Road(5,'I5').
    Road(6,'I6').
    Road(7,'I7').
    Road(8,'I8').
    Road(9,'I9').
    Road(10,'I10').

    Rest(11,'Mamas','Home-style cooking comfort food hand-made family friendly').
    Rest(12,'Erreu','Rotisserie and grill chicken dishes whole food family environment').
    Rest(13,'FlashFast','Fastfood sandwiches soft drinks').

    Class(23,'Restaurant').
    Class(24,'Fine Dining').
    Class(25,'Casual Dining').
    Class(26,'Fast Food').
    Class(27,'Pizza').
    Class(28,'Sandwich').

    Knows(14,17).
    Knows(14,19).
    Knows(14,21).
    Knows(15,16).
    Knows(15,17).
    Knows(15,20).
    Knows(15,21).
    Knows(16,22).
    Knows(17,18).
    Knows(18,20).
    Knows(18,22).
    Knows(19,20).
    Knows(19,21).

    Knows(17,14).
    Knows(19,14).
    Knows(21,14).
    Knows(16,15).
    Knows(17,15).
    Knows(20,15).
    Knows(21,15).
    Knows(22,16).
    Knows(18,17).
    Knows(20,18).
    Knows(22,18).
    Knows(20,19).
    Knows(21,19).

    Likes(14,11).
    Likes(15,12).
    Likes(18,13).

    IsA(24,23).
    IsA(25,23).
    IsA(26,23).
    IsA(27,26).
    IsA(28,26).

    InstanceOf(11,25).
    InstanceOf(12,24).
    InstanceOf(13,28).

    Connects(1,3,4,0.2).
    Connects(3,1,5,0.2).
    Connects(3,6,7,0.3).
    Connects(4,3,6,0.3).
    Connects(6,3,8,0.3).
    Connects(6,5,9,0.2).
    Connects(6,7,10,0.3).
    Connects(7,6,11,0.3).
    Connects(7,9,13,0.4).
    Connects(8,2,17,0.5).
    Connects(8,6,12,0.3).
    Connects(8,11,18,0.4).
    Connects(8,12,19,0.1).
    Connects(9,8,14,0.4).
    Connects(9,13,20,0.2).
    Connects(10,8,16,0.2).
    Connects(11,2,21,0.1).
    Connects(12,6,22,0.2).
    Connects(13,8,23,0.2).


Inference Rules:

Positive Constraints:

Negative Constraints:

Key Constraints:

Program:

    %All minimum paths
    %=================
    %Path(X,Y,d):-Connects(X,Y,A,B),d=1.
    %Path(X,Y,d):-Path(X,Z,d1),Path(Z,Y,d2),d=d1+d2.

    %MinPath(X,Y,m):-aggr(Path(X,Y,d),X,Y,m=min(d)).

    %PageRank
    %=================
    PersonId(id):-Person(id,O).
    Rank(n,r):-Person(n), r=1.0/9.

    KnowsCount(s,c):-aggr(Knows(s,d),s,c=count(d)).

    %While...
        NewRanks(n,s,r):-Rank(s,r0),Knows(s,n),KnowsCount(s,c),r= 0.85*r0/c.
        AggRank(n,r):-aggr(NewRanks(n,s,r0),n,r=sum(r0)).
        Rank(n,r):-AggRank(n,r0),r=r0+0.15*1.0/9.
        
"""

swing = new SwingBuilder()

frame = swing.frame(title:'Datalog Console',
        location:[50,50], size:[1300,600],
        defaultCloseOperation:WC.EXIT_ON_CLOSE, show: true) {

    panel (border:BF.createEmptyBorder(6,6,6,6)) {
        borderLayout()
        vbox (constraints: BL.NORTH){
            hbox {
                hstrut(width:10)
                //label 'Language: '
                //comboLanguage = comboBox(items:['beta', 'cypher'], constraints:BL.NORTH, toolTipText:'Choose the language')
                dir = textField(id:'dir', editable: false, '/home/luizcelso/Dropbox/workspace/ProtoJava/Java/Examples/Restaurants/query.dlp')
                button(text:'Choose Query File',
                        actionPerformed: {dir.text = fileChooser();
                            def defaultText = ""
                            def file = new File(dir.text)
                            if (file.exists()) defaultText = file.getText()
                            qText.text = defaultText
                        })
            }
        }
        vbox(constraints: BL.CENTER){
            hbox(border:BF.createTitledBorder('Query')) {
                scrollPane{
//                    def defaultText = ""
//                    def file = new File(dir.text)
//                    if (file.exists()) defaultText = file.getText()
//                    qText = textPane(text:defaultText)
                    qText = textPane(text:defaultQuery)
                }
            }
            hbox(border:BF.createTitledBorder('Output')) {
                scrollPane {

                    tableOut = table() {
                        tableModel() {
                        }
                    }
                }
            }

        }

        hbox (constraints: BL.SOUTH){
            button(text:'Please run my little query...',
                    actionPerformed: {fireQuery(qText.text, tableOut)})
        }

    }


}


String fileChooser(){
    def initialPath = System.getProperty("user.dir");
    def path = ''
    JFileChooser fc = new JFileChooser(initialPath);
    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    //fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
    int result = fc.showOpenDialog( null );
    switch ( result )
    {
        case JFileChooser.APPROVE_OPTION:
            File file = fc.getSelectedFile();

            path =  file.toString(); // fc.getCurrentDirectory().getAbsolutePath()

            break;
        case JFileChooser.CANCEL_OPTION:
        case JFileChooser.ERROR_OPTION:
            break;
    }
    return path
}


def fireQuery(query,  JTable tableOut){
    swing = new SwingBuilder()


    //println query

    def rq = new Evaluator()
    Relation results = rq.processProgram(query)

    //results = [[name:'celso'], [name:'luiz'], [name:'jade', favColor:'pink']]
    List headers = results.getSchema()
//    headers.add('rowCount')
    //results.each {headers.addAll(it.keySet())}


    tableOut.model = swing.tableModel()

    headers.each{
        tableOut.model.addColumn(new DefaultTableColumn(it.toString(), new PropertyModel(tableOut.model.rowModel, it.toString())))
    }

    def count = 0
    results.each{
        row = [headers.collect{it.toString()},it].transpose().flatten().toSpreadMap()
//        row["rowCount"] = count++
        tableOut.model.rowsModel.value.add(row)
    }
    tableOut.model.fireTableStructureChanged()

    tableOut.model.fireTableDataChanged()



}


