// Generated from /home/chabin/workspace/GraphQueriesConstraints/Java/parser/datalog.g4 by ANTLR 4.6
package parser;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class datalogParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.6", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, COMMA=6, PERIOD=7, Q_MARK=8, LEFT_PAREN=9, 
		RIGHT_PAREN=10, COLON=11, COLON_DASH=12, ATTRIBUTION=13, MULTIPLY=14, 
		ADD=15, NEG=16, SHELL=17, AGG=18, MAP=19, BETA=20, MIN=21, MAX=22, SUM=23, 
		COUNT=24, SCHEMES=25, FACTS=26, RULES=27, POSITIVE=28, NEGATIVE=29, KEY=30, 
		PROGRAM=31, IMPORT=32, FROM=33, DIR=34, MYSQL=35, IN=36, OUT=37, BOTH=38, 
		VTABLE=39, ETABLE=40, NEW=41, CURRENT=42, ID=43, QUALIFIED_ID=44, STRING=45, 
		FLOAT=46, INT=47, COMMENT=48, WS=49;
	public static final int
		RULE_datalogProgram = 0, RULE_scheme = 1, RULE_schemeList = 2, RULE_fact = 3, 
		RULE_factList = 4, RULE_importFacts = 5, RULE_ruleA = 6, RULE_infRulesList = 7, 
		RULE_importInfRules = 8, RULE_posRulesList = 9, RULE_importPosRules = 10, 
		RULE_negRuleA = 11, RULE_negRulesList = 12, RULE_importNegRules = 13, 
		RULE_keyRulesList = 14, RULE_importKeyRules = 15, RULE_aggQueryHeadAtom = 16, 
		RULE_atom = 17, RULE_atomList = 18, RULE_element = 19, RULE_elementList = 20, 
		RULE_idList = 21, RULE_query = 22, RULE_simpleQuery = 23, RULE_aggQuery = 24, 
		RULE_mapQuery = 25, RULE_betaQuery = 26, RULE_queryList = 27, RULE_assigExpression = 28, 
		RULE_assigAggr = 29, RULE_assig_aggr = 30, RULE_list_identifiers = 31, 
		RULE_expr = 32, RULE_valueList = 33;
	public static final String[] ruleNames = {
		"datalogProgram", "scheme", "schemeList", "fact", "factList", "importFacts", 
		"ruleA", "infRulesList", "importInfRules", "posRulesList", "importPosRules", 
		"negRuleA", "negRulesList", "importNegRules", "keyRulesList", "importKeyRules", 
		"aggQueryHeadAtom", "atom", "atomList", "element", "elementList", "idList", 
		"query", "simpleQuery", "aggQuery", "mapQuery", "betaQuery", "queryList", 
		"assigExpression", "assigAggr", "assig_aggr", "list_identifiers", "expr", 
		"valueList"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'BY'", "'['", "']'", "'/'", "'-'", "','", "'.'", "'?'", "'('", 
		"')'", "':'", null, "'='", "'*'", "'+'", "'!'", "'$'", "'aggr'", "'map'", 
		"'beta'", "'min'", "'max'", "'sum'", "'count'", "'Schemes'", "'Facts'", 
		"'Inference Rules'", "'Positive Constraints'", "'Negative Constraints'", 
		"'Key Constraints'", "'Program'", "'IMPORT'", "'FROM'", "'DIR'", "'MYSQL'", 
		"'IN'", "'OUT'", "'BOTH'", "'V'", "'E'", "'newV'", "'current'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, null, null, null, null, null, "COMMA", "PERIOD", "Q_MARK", "LEFT_PAREN", 
		"RIGHT_PAREN", "COLON", "COLON_DASH", "ATTRIBUTION", "MULTIPLY", "ADD", 
		"NEG", "SHELL", "AGG", "MAP", "BETA", "MIN", "MAX", "SUM", "COUNT", "SCHEMES", 
		"FACTS", "RULES", "POSITIVE", "NEGATIVE", "KEY", "PROGRAM", "IMPORT", 
		"FROM", "DIR", "MYSQL", "IN", "OUT", "BOTH", "VTABLE", "ETABLE", "NEW", 
		"CURRENT", "ID", "QUALIFIED_ID", "STRING", "FLOAT", "INT", "COMMENT", 
		"WS"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "datalog.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public datalogParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class DatalogProgramContext extends ParserRuleContext {
		public TerminalNode SCHEMES() { return getToken(datalogParser.SCHEMES, 0); }
		public List<TerminalNode> COLON() { return getTokens(datalogParser.COLON); }
		public TerminalNode COLON(int i) {
			return getToken(datalogParser.COLON, i);
		}
		public TerminalNode FACTS() { return getToken(datalogParser.FACTS, 0); }
		public TerminalNode RULES() { return getToken(datalogParser.RULES, 0); }
		public TerminalNode POSITIVE() { return getToken(datalogParser.POSITIVE, 0); }
		public TerminalNode NEGATIVE() { return getToken(datalogParser.NEGATIVE, 0); }
		public TerminalNode KEY() { return getToken(datalogParser.KEY, 0); }
		public TerminalNode PROGRAM() { return getToken(datalogParser.PROGRAM, 0); }
		public QueryListContext queryList() {
			return getRuleContext(QueryListContext.class,0);
		}
		public SchemeListContext schemeList() {
			return getRuleContext(SchemeListContext.class,0);
		}
		public FactListContext factList() {
			return getRuleContext(FactListContext.class,0);
		}
		public ImportFactsContext importFacts() {
			return getRuleContext(ImportFactsContext.class,0);
		}
		public InfRulesListContext infRulesList() {
			return getRuleContext(InfRulesListContext.class,0);
		}
		public ImportInfRulesContext importInfRules() {
			return getRuleContext(ImportInfRulesContext.class,0);
		}
		public PosRulesListContext posRulesList() {
			return getRuleContext(PosRulesListContext.class,0);
		}
		public ImportPosRulesContext importPosRules() {
			return getRuleContext(ImportPosRulesContext.class,0);
		}
		public NegRulesListContext negRulesList() {
			return getRuleContext(NegRulesListContext.class,0);
		}
		public ImportNegRulesContext importNegRules() {
			return getRuleContext(ImportNegRulesContext.class,0);
		}
		public KeyRulesListContext keyRulesList() {
			return getRuleContext(KeyRulesListContext.class,0);
		}
		public ImportKeyRulesContext importKeyRules() {
			return getRuleContext(ImportKeyRulesContext.class,0);
		}
		public DatalogProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datalogProgram; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterDatalogProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitDatalogProgram(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitDatalogProgram(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DatalogProgramContext datalogProgram() throws RecognitionException {
		DatalogProgramContext _localctx = new DatalogProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_datalogProgram);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(68);
			match(SCHEMES);
			setState(69);
			match(COLON);
			{
			setState(70);
			schemeList();
			}
			setState(71);
			match(FACTS);
			setState(72);
			match(COLON);
			setState(75);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
				{
				setState(73);
				factList();
				}
				break;
			case SHELL:
				{
				setState(74);
				importFacts();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(77);
			match(RULES);
			setState(78);
			match(COLON);
			setState(81);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case POSITIVE:
			case ID:
				{
				setState(79);
				infRulesList();
				}
				break;
			case SHELL:
				{
				setState(80);
				importInfRules();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(83);
			match(POSITIVE);
			setState(84);
			match(COLON);
			setState(87);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NEGATIVE:
			case ID:
				{
				setState(85);
				posRulesList();
				}
				break;
			case SHELL:
				{
				setState(86);
				importPosRules();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(89);
			match(NEGATIVE);
			setState(90);
			match(COLON);
			setState(93);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NEG:
			case KEY:
				{
				setState(91);
				negRulesList();
				}
				break;
			case SHELL:
				{
				setState(92);
				importNegRules();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(95);
			match(KEY);
			setState(96);
			match(COLON);
			setState(99);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case PROGRAM:
			case ID:
				{
				setState(97);
				keyRulesList();
				}
				break;
			case SHELL:
				{
				setState(98);
				importKeyRules();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(101);
			match(PROGRAM);
			setState(102);
			match(COLON);
			setState(103);
			queryList();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SchemeContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(datalogParser.ID, 0); }
		public TerminalNode LEFT_PAREN() { return getToken(datalogParser.LEFT_PAREN, 0); }
		public IdListContext idList() {
			return getRuleContext(IdListContext.class,0);
		}
		public TerminalNode RIGHT_PAREN() { return getToken(datalogParser.RIGHT_PAREN, 0); }
		public TerminalNode PERIOD() { return getToken(datalogParser.PERIOD, 0); }
		public SchemeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scheme; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterScheme(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitScheme(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitScheme(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SchemeContext scheme() throws RecognitionException {
		SchemeContext _localctx = new SchemeContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_scheme);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(105);
			match(ID);
			setState(106);
			match(LEFT_PAREN);
			setState(107);
			idList();
			setState(108);
			match(RIGHT_PAREN);
			setState(109);
			match(PERIOD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SchemeListContext extends ParserRuleContext {
		public List<SchemeContext> scheme() {
			return getRuleContexts(SchemeContext.class);
		}
		public SchemeContext scheme(int i) {
			return getRuleContext(SchemeContext.class,i);
		}
		public SchemeListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_schemeList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterSchemeList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitSchemeList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitSchemeList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SchemeListContext schemeList() throws RecognitionException {
		SchemeListContext _localctx = new SchemeListContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_schemeList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(112); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(111);
				scheme();
				}
				}
				setState(114); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ID );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FactContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(datalogParser.ID, 0); }
		public TerminalNode LEFT_PAREN() { return getToken(datalogParser.LEFT_PAREN, 0); }
		public ValueListContext valueList() {
			return getRuleContext(ValueListContext.class,0);
		}
		public TerminalNode RIGHT_PAREN() { return getToken(datalogParser.RIGHT_PAREN, 0); }
		public TerminalNode PERIOD() { return getToken(datalogParser.PERIOD, 0); }
		public FactContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fact; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterFact(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitFact(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitFact(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FactContext fact() throws RecognitionException {
		FactContext _localctx = new FactContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_fact);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(116);
			match(ID);
			setState(117);
			match(LEFT_PAREN);
			setState(118);
			valueList();
			setState(119);
			match(RIGHT_PAREN);
			setState(120);
			match(PERIOD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FactListContext extends ParserRuleContext {
		public List<FactContext> fact() {
			return getRuleContexts(FactContext.class);
		}
		public FactContext fact(int i) {
			return getRuleContext(FactContext.class,i);
		}
		public FactListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_factList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterFactList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitFactList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitFactList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FactListContext factList() throws RecognitionException {
		FactListContext _localctx = new FactListContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_factList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(123); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(122);
				fact();
				}
				}
				setState(125); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ID );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImportFactsContext extends ParserRuleContext {
		public Token db;
		public Token u;
		public Token mdp;
		public TerminalNode SHELL() { return getToken(datalogParser.SHELL, 0); }
		public TerminalNode IMPORT() { return getToken(datalogParser.IMPORT, 0); }
		public TerminalNode FROM() { return getToken(datalogParser.FROM, 0); }
		public TerminalNode MYSQL() { return getToken(datalogParser.MYSQL, 0); }
		public List<TerminalNode> STRING() { return getTokens(datalogParser.STRING); }
		public TerminalNode STRING(int i) {
			return getToken(datalogParser.STRING, i);
		}
		public ImportFactsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_importFacts; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterImportFacts(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitImportFacts(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitImportFacts(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ImportFactsContext importFacts() throws RecognitionException {
		ImportFactsContext _localctx = new ImportFactsContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_importFacts);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(127);
			match(SHELL);
			setState(128);
			match(IMPORT);
			setState(129);
			match(FROM);
			setState(130);
			match(MYSQL);
			setState(131);
			((ImportFactsContext)_localctx).db = match(STRING);
			setState(132);
			((ImportFactsContext)_localctx).u = match(STRING);
			setState(133);
			((ImportFactsContext)_localctx).mdp = match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RuleAContext extends ParserRuleContext {
		public AtomContext atom() {
			return getRuleContext(AtomContext.class,0);
		}
		public TerminalNode COLON_DASH() { return getToken(datalogParser.COLON_DASH, 0); }
		public AtomListContext atomList() {
			return getRuleContext(AtomListContext.class,0);
		}
		public TerminalNode PERIOD() { return getToken(datalogParser.PERIOD, 0); }
		public RuleAContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ruleA; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterRuleA(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitRuleA(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitRuleA(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RuleAContext ruleA() throws RecognitionException {
		RuleAContext _localctx = new RuleAContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_ruleA);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(135);
			atom();
			setState(136);
			match(COLON_DASH);
			setState(137);
			atomList();
			setState(138);
			match(PERIOD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InfRulesListContext extends ParserRuleContext {
		public List<RuleAContext> ruleA() {
			return getRuleContexts(RuleAContext.class);
		}
		public RuleAContext ruleA(int i) {
			return getRuleContext(RuleAContext.class,i);
		}
		public InfRulesListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_infRulesList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterInfRulesList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitInfRulesList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitInfRulesList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InfRulesListContext infRulesList() throws RecognitionException {
		InfRulesListContext _localctx = new InfRulesListContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_infRulesList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(143);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ID) {
				{
				{
				setState(140);
				ruleA();
				}
				}
				setState(145);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImportInfRulesContext extends ParserRuleContext {
		public Token d;
		public TerminalNode SHELL() { return getToken(datalogParser.SHELL, 0); }
		public TerminalNode IMPORT() { return getToken(datalogParser.IMPORT, 0); }
		public TerminalNode FROM() { return getToken(datalogParser.FROM, 0); }
		public TerminalNode DIR() { return getToken(datalogParser.DIR, 0); }
		public TerminalNode STRING() { return getToken(datalogParser.STRING, 0); }
		public ImportInfRulesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_importInfRules; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterImportInfRules(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitImportInfRules(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitImportInfRules(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ImportInfRulesContext importInfRules() throws RecognitionException {
		ImportInfRulesContext _localctx = new ImportInfRulesContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_importInfRules);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(146);
			match(SHELL);
			setState(147);
			match(IMPORT);
			setState(148);
			match(FROM);
			setState(149);
			match(DIR);
			setState(150);
			((ImportInfRulesContext)_localctx).d = match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PosRulesListContext extends ParserRuleContext {
		public List<RuleAContext> ruleA() {
			return getRuleContexts(RuleAContext.class);
		}
		public RuleAContext ruleA(int i) {
			return getRuleContext(RuleAContext.class,i);
		}
		public PosRulesListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_posRulesList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterPosRulesList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitPosRulesList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitPosRulesList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PosRulesListContext posRulesList() throws RecognitionException {
		PosRulesListContext _localctx = new PosRulesListContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_posRulesList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(155);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ID) {
				{
				{
				setState(152);
				ruleA();
				}
				}
				setState(157);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImportPosRulesContext extends ParserRuleContext {
		public Token d;
		public TerminalNode SHELL() { return getToken(datalogParser.SHELL, 0); }
		public TerminalNode IMPORT() { return getToken(datalogParser.IMPORT, 0); }
		public TerminalNode FROM() { return getToken(datalogParser.FROM, 0); }
		public TerminalNode DIR() { return getToken(datalogParser.DIR, 0); }
		public TerminalNode STRING() { return getToken(datalogParser.STRING, 0); }
		public ImportPosRulesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_importPosRules; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterImportPosRules(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitImportPosRules(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitImportPosRules(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ImportPosRulesContext importPosRules() throws RecognitionException {
		ImportPosRulesContext _localctx = new ImportPosRulesContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_importPosRules);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(158);
			match(SHELL);
			setState(159);
			match(IMPORT);
			setState(160);
			match(FROM);
			setState(161);
			match(DIR);
			setState(162);
			((ImportPosRulesContext)_localctx).d = match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NegRuleAContext extends ParserRuleContext {
		public TerminalNode NEG() { return getToken(datalogParser.NEG, 0); }
		public TerminalNode COLON_DASH() { return getToken(datalogParser.COLON_DASH, 0); }
		public AtomListContext atomList() {
			return getRuleContext(AtomListContext.class,0);
		}
		public TerminalNode PERIOD() { return getToken(datalogParser.PERIOD, 0); }
		public NegRuleAContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_negRuleA; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterNegRuleA(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitNegRuleA(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitNegRuleA(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NegRuleAContext negRuleA() throws RecognitionException {
		NegRuleAContext _localctx = new NegRuleAContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_negRuleA);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(164);
			match(NEG);
			setState(165);
			match(COLON_DASH);
			setState(166);
			atomList();
			setState(167);
			match(PERIOD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NegRulesListContext extends ParserRuleContext {
		public List<NegRuleAContext> negRuleA() {
			return getRuleContexts(NegRuleAContext.class);
		}
		public NegRuleAContext negRuleA(int i) {
			return getRuleContext(NegRuleAContext.class,i);
		}
		public NegRulesListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_negRulesList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterNegRulesList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitNegRulesList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitNegRulesList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NegRulesListContext negRulesList() throws RecognitionException {
		NegRulesListContext _localctx = new NegRulesListContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_negRulesList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(172);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NEG) {
				{
				{
				setState(169);
				negRuleA();
				}
				}
				setState(174);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImportNegRulesContext extends ParserRuleContext {
		public Token d;
		public TerminalNode SHELL() { return getToken(datalogParser.SHELL, 0); }
		public TerminalNode IMPORT() { return getToken(datalogParser.IMPORT, 0); }
		public TerminalNode FROM() { return getToken(datalogParser.FROM, 0); }
		public TerminalNode DIR() { return getToken(datalogParser.DIR, 0); }
		public TerminalNode STRING() { return getToken(datalogParser.STRING, 0); }
		public ImportNegRulesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_importNegRules; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterImportNegRules(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitImportNegRules(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitImportNegRules(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ImportNegRulesContext importNegRules() throws RecognitionException {
		ImportNegRulesContext _localctx = new ImportNegRulesContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_importNegRules);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(175);
			match(SHELL);
			setState(176);
			match(IMPORT);
			setState(177);
			match(FROM);
			setState(178);
			match(DIR);
			setState(179);
			((ImportNegRulesContext)_localctx).d = match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class KeyRulesListContext extends ParserRuleContext {
		public List<RuleAContext> ruleA() {
			return getRuleContexts(RuleAContext.class);
		}
		public RuleAContext ruleA(int i) {
			return getRuleContext(RuleAContext.class,i);
		}
		public KeyRulesListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_keyRulesList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterKeyRulesList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitKeyRulesList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitKeyRulesList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final KeyRulesListContext keyRulesList() throws RecognitionException {
		KeyRulesListContext _localctx = new KeyRulesListContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_keyRulesList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(184);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ID) {
				{
				{
				setState(181);
				ruleA();
				}
				}
				setState(186);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImportKeyRulesContext extends ParserRuleContext {
		public Token d;
		public TerminalNode SHELL() { return getToken(datalogParser.SHELL, 0); }
		public TerminalNode IMPORT() { return getToken(datalogParser.IMPORT, 0); }
		public TerminalNode FROM() { return getToken(datalogParser.FROM, 0); }
		public TerminalNode DIR() { return getToken(datalogParser.DIR, 0); }
		public TerminalNode STRING() { return getToken(datalogParser.STRING, 0); }
		public ImportKeyRulesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_importKeyRules; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterImportKeyRules(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitImportKeyRules(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitImportKeyRules(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ImportKeyRulesContext importKeyRules() throws RecognitionException {
		ImportKeyRulesContext _localctx = new ImportKeyRulesContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_importKeyRules);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(187);
			match(SHELL);
			setState(188);
			match(IMPORT);
			setState(189);
			match(FROM);
			setState(190);
			match(DIR);
			setState(191);
			((ImportKeyRulesContext)_localctx).d = match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AggQueryHeadAtomContext extends ParserRuleContext {
		public Token pd;
		public TerminalNode LEFT_PAREN() { return getToken(datalogParser.LEFT_PAREN, 0); }
		public ElementListContext elementList() {
			return getRuleContext(ElementListContext.class,0);
		}
		public TerminalNode COMMA() { return getToken(datalogParser.COMMA, 0); }
		public List<TerminalNode> ID() { return getTokens(datalogParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(datalogParser.ID, i);
		}
		public TerminalNode RIGHT_PAREN() { return getToken(datalogParser.RIGHT_PAREN, 0); }
		public AggQueryHeadAtomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggQueryHeadAtom; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterAggQueryHeadAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitAggQueryHeadAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitAggQueryHeadAtom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AggQueryHeadAtomContext aggQueryHeadAtom() throws RecognitionException {
		AggQueryHeadAtomContext _localctx = new AggQueryHeadAtomContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_aggQueryHeadAtom);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(193);
			((AggQueryHeadAtomContext)_localctx).pd = match(ID);
			setState(194);
			match(LEFT_PAREN);
			setState(195);
			elementList();
			setState(196);
			match(COMMA);
			setState(197);
			match(ID);
			setState(198);
			match(RIGHT_PAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtomContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(datalogParser.ID, 0); }
		public TerminalNode LEFT_PAREN() { return getToken(datalogParser.LEFT_PAREN, 0); }
		public ElementListContext elementList() {
			return getRuleContext(ElementListContext.class,0);
		}
		public TerminalNode RIGHT_PAREN() { return getToken(datalogParser.RIGHT_PAREN, 0); }
		public AtomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atom; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitAtom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtomContext atom() throws RecognitionException {
		AtomContext _localctx = new AtomContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_atom);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(200);
			match(ID);
			setState(201);
			match(LEFT_PAREN);
			setState(202);
			elementList();
			setState(203);
			match(RIGHT_PAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtomListContext extends ParserRuleContext {
		public List<AtomContext> atom() {
			return getRuleContexts(AtomContext.class);
		}
		public AtomContext atom(int i) {
			return getRuleContext(AtomContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(datalogParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(datalogParser.COMMA, i);
		}
		public AtomListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atomList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterAtomList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitAtomList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitAtomList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtomListContext atomList() throws RecognitionException {
		AtomListContext _localctx = new AtomListContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_atomList);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(210);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(205);
					atom();
					setState(206);
					match(COMMA);
					}
					} 
				}
				setState(212);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			}
			setState(213);
			atom();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElementContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(datalogParser.ID, 0); }
		public TerminalNode STRING() { return getToken(datalogParser.STRING, 0); }
		public TerminalNode INT() { return getToken(datalogParser.INT, 0); }
		public TerminalNode FLOAT() { return getToken(datalogParser.FLOAT, 0); }
		public ElementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_element; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterElement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitElement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitElement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElementContext element() throws RecognitionException {
		ElementContext _localctx = new ElementContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_element);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(215);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ID) | (1L << STRING) | (1L << FLOAT) | (1L << INT))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElementListContext extends ParserRuleContext {
		public List<ElementContext> element() {
			return getRuleContexts(ElementContext.class);
		}
		public ElementContext element(int i) {
			return getRuleContext(ElementContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(datalogParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(datalogParser.COMMA, i);
		}
		public ElementListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elementList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterElementList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitElementList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitElementList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElementListContext elementList() throws RecognitionException {
		ElementListContext _localctx = new ElementListContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_elementList);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(222);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,12,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(217);
					element();
					setState(218);
					match(COMMA);
					}
					} 
				}
				setState(224);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,12,_ctx);
			}
			setState(225);
			element();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdListContext extends ParserRuleContext {
		public List<TerminalNode> ID() { return getTokens(datalogParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(datalogParser.ID, i);
		}
		public List<TerminalNode> COMMA() { return getTokens(datalogParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(datalogParser.COMMA, i);
		}
		public IdListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_idList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterIdList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitIdList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitIdList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdListContext idList() throws RecognitionException {
		IdListContext _localctx = new IdListContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_idList);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(231);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,13,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(227);
					match(ID);
					setState(228);
					match(COMMA);
					}
					} 
				}
				setState(233);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,13,_ctx);
			}
			setState(234);
			match(ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QueryContext extends ParserRuleContext {
		public SimpleQueryContext simpleQuery() {
			return getRuleContext(SimpleQueryContext.class,0);
		}
		public AggQueryContext aggQuery() {
			return getRuleContext(AggQueryContext.class,0);
		}
		public MapQueryContext mapQuery() {
			return getRuleContext(MapQueryContext.class,0);
		}
		public BetaQueryContext betaQuery() {
			return getRuleContext(BetaQueryContext.class,0);
		}
		public QueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_query; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QueryContext query() throws RecognitionException {
		QueryContext _localctx = new QueryContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_query);
		try {
			setState(240);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,14,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(236);
				simpleQuery();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(237);
				aggQuery();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(238);
				mapQuery();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(239);
				betaQuery();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SimpleQueryContext extends ParserRuleContext {
		public AtomContext atom() {
			return getRuleContext(AtomContext.class,0);
		}
		public TerminalNode COLON_DASH() { return getToken(datalogParser.COLON_DASH, 0); }
		public AtomListContext atomList() {
			return getRuleContext(AtomListContext.class,0);
		}
		public TerminalNode PERIOD() { return getToken(datalogParser.PERIOD, 0); }
		public TerminalNode Q_MARK() { return getToken(datalogParser.Q_MARK, 0); }
		public TerminalNode COMMA() { return getToken(datalogParser.COMMA, 0); }
		public AssigExpressionContext assigExpression() {
			return getRuleContext(AssigExpressionContext.class,0);
		}
		public SimpleQueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simpleQuery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterSimpleQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitSimpleQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitSimpleQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimpleQueryContext simpleQuery() throws RecognitionException {
		SimpleQueryContext _localctx = new SimpleQueryContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_simpleQuery);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(243);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==Q_MARK) {
				{
				setState(242);
				match(Q_MARK);
				}
			}

			setState(245);
			atom();
			setState(246);
			match(COLON_DASH);
			setState(247);
			atomList();
			setState(250);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==COMMA) {
				{
				setState(248);
				match(COMMA);
				setState(249);
				assigExpression();
				}
			}

			setState(252);
			match(PERIOD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AggQueryContext extends ParserRuleContext {
		public AggQueryHeadAtomContext aggQueryHeadAtom() {
			return getRuleContext(AggQueryHeadAtomContext.class,0);
		}
		public TerminalNode COLON_DASH() { return getToken(datalogParser.COLON_DASH, 0); }
		public TerminalNode AGG() { return getToken(datalogParser.AGG, 0); }
		public TerminalNode LEFT_PAREN() { return getToken(datalogParser.LEFT_PAREN, 0); }
		public AtomListContext atomList() {
			return getRuleContext(AtomListContext.class,0);
		}
		public List<TerminalNode> COMMA() { return getTokens(datalogParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(datalogParser.COMMA, i);
		}
		public AssigAggrContext assigAggr() {
			return getRuleContext(AssigAggrContext.class,0);
		}
		public TerminalNode RIGHT_PAREN() { return getToken(datalogParser.RIGHT_PAREN, 0); }
		public TerminalNode PERIOD() { return getToken(datalogParser.PERIOD, 0); }
		public TerminalNode Q_MARK() { return getToken(datalogParser.Q_MARK, 0); }
		public IdListContext idList() {
			return getRuleContext(IdListContext.class,0);
		}
		public AggQueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggQuery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterAggQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitAggQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitAggQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AggQueryContext aggQuery() throws RecognitionException {
		AggQueryContext _localctx = new AggQueryContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_aggQuery);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(255);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==Q_MARK) {
				{
				setState(254);
				match(Q_MARK);
				}
			}

			setState(257);
			aggQueryHeadAtom();
			setState(258);
			match(COLON_DASH);
			setState(259);
			match(AGG);
			setState(260);
			match(LEFT_PAREN);
			setState(261);
			atomList();
			setState(264);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,18,_ctx) ) {
			case 1:
				{
				setState(262);
				match(COMMA);
				setState(263);
				idList();
				}
				break;
			}
			setState(266);
			match(COMMA);
			setState(267);
			assigAggr();
			setState(268);
			match(RIGHT_PAREN);
			setState(269);
			match(PERIOD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MapQueryContext extends ParserRuleContext {
		public AtomContext nodes;
		public AtomContext links;
		public List<AtomContext> atom() {
			return getRuleContexts(AtomContext.class);
		}
		public AtomContext atom(int i) {
			return getRuleContext(AtomContext.class,i);
		}
		public TerminalNode COLON_DASH() { return getToken(datalogParser.COLON_DASH, 0); }
		public TerminalNode MAP() { return getToken(datalogParser.MAP, 0); }
		public TerminalNode LEFT_PAREN() { return getToken(datalogParser.LEFT_PAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(datalogParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(datalogParser.COMMA, i);
		}
		public AssigExpressionContext assigExpression() {
			return getRuleContext(AssigExpressionContext.class,0);
		}
		public TerminalNode RIGHT_PAREN() { return getToken(datalogParser.RIGHT_PAREN, 0); }
		public TerminalNode PERIOD() { return getToken(datalogParser.PERIOD, 0); }
		public TerminalNode Q_MARK() { return getToken(datalogParser.Q_MARK, 0); }
		public MapQueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mapQuery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterMapQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitMapQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitMapQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MapQueryContext mapQuery() throws RecognitionException {
		MapQueryContext _localctx = new MapQueryContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_mapQuery);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(272);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==Q_MARK) {
				{
				setState(271);
				match(Q_MARK);
				}
			}

			setState(274);
			atom();
			setState(275);
			match(COLON_DASH);
			setState(276);
			match(MAP);
			setState(277);
			match(LEFT_PAREN);
			setState(278);
			((MapQueryContext)_localctx).nodes = atom();
			setState(279);
			match(COMMA);
			setState(280);
			((MapQueryContext)_localctx).links = atom();
			setState(281);
			match(COMMA);
			setState(282);
			assigExpression();
			setState(283);
			match(RIGHT_PAREN);
			setState(284);
			match(PERIOD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BetaQueryContext extends ParserRuleContext {
		public AtomContext head;
		public AtomContext nodes;
		public AtomContext links;
		public Token n;
		public AssigExpressionContext map;
		public AssigAggrContext reduce;
		public AssigExpressionContext update;
		public TerminalNode COLON_DASH() { return getToken(datalogParser.COLON_DASH, 0); }
		public TerminalNode BETA() { return getToken(datalogParser.BETA, 0); }
		public TerminalNode LEFT_PAREN() { return getToken(datalogParser.LEFT_PAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(datalogParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(datalogParser.COMMA, i);
		}
		public TerminalNode RIGHT_PAREN() { return getToken(datalogParser.RIGHT_PAREN, 0); }
		public TerminalNode PERIOD() { return getToken(datalogParser.PERIOD, 0); }
		public List<AtomContext> atom() {
			return getRuleContexts(AtomContext.class);
		}
		public AtomContext atom(int i) {
			return getRuleContext(AtomContext.class,i);
		}
		public TerminalNode INT() { return getToken(datalogParser.INT, 0); }
		public List<AssigExpressionContext> assigExpression() {
			return getRuleContexts(AssigExpressionContext.class);
		}
		public AssigExpressionContext assigExpression(int i) {
			return getRuleContext(AssigExpressionContext.class,i);
		}
		public AssigAggrContext assigAggr() {
			return getRuleContext(AssigAggrContext.class,0);
		}
		public TerminalNode Q_MARK() { return getToken(datalogParser.Q_MARK, 0); }
		public IdListContext idList() {
			return getRuleContext(IdListContext.class,0);
		}
		public BetaQueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_betaQuery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterBetaQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitBetaQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitBetaQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BetaQueryContext betaQuery() throws RecognitionException {
		BetaQueryContext _localctx = new BetaQueryContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_betaQuery);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(287);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==Q_MARK) {
				{
				setState(286);
				match(Q_MARK);
				}
			}

			setState(289);
			((BetaQueryContext)_localctx).head = atom();
			setState(290);
			match(COLON_DASH);
			setState(291);
			match(BETA);
			setState(292);
			match(LEFT_PAREN);
			setState(293);
			((BetaQueryContext)_localctx).nodes = atom();
			setState(294);
			match(COMMA);
			setState(295);
			((BetaQueryContext)_localctx).links = atom();
			setState(296);
			match(COMMA);
			setState(297);
			((BetaQueryContext)_localctx).n = match(INT);
			setState(300);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
			case 1:
				{
				setState(298);
				match(COMMA);
				setState(299);
				idList();
				}
				break;
			}
			setState(302);
			match(COMMA);
			setState(303);
			((BetaQueryContext)_localctx).map = assigExpression();
			setState(304);
			match(COMMA);
			setState(305);
			((BetaQueryContext)_localctx).reduce = assigAggr();
			setState(306);
			match(COMMA);
			setState(307);
			((BetaQueryContext)_localctx).update = assigExpression();
			setState(308);
			match(RIGHT_PAREN);
			setState(309);
			match(PERIOD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QueryListContext extends ParserRuleContext {
		public List<QueryContext> query() {
			return getRuleContexts(QueryContext.class);
		}
		public QueryContext query(int i) {
			return getRuleContext(QueryContext.class,i);
		}
		public QueryListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_queryList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterQueryList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitQueryList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitQueryList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QueryListContext queryList() throws RecognitionException {
		QueryListContext _localctx = new QueryListContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_queryList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(312); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(311);
				query();
				}
				}
				setState(314); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==Q_MARK || _la==ID );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssigExpressionContext extends ParserRuleContext {
		public Token variable;
		public TerminalNode ATTRIBUTION() { return getToken(datalogParser.ATTRIBUTION, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode ID() { return getToken(datalogParser.ID, 0); }
		public TerminalNode QUALIFIED_ID() { return getToken(datalogParser.QUALIFIED_ID, 0); }
		public AssigExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assigExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterAssigExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitAssigExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitAssigExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssigExpressionContext assigExpression() throws RecognitionException {
		AssigExpressionContext _localctx = new AssigExpressionContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_assigExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(316);
			((AssigExpressionContext)_localctx).variable = _input.LT(1);
			_la = _input.LA(1);
			if ( !(_la==ID || _la==QUALIFIED_ID) ) {
				((AssigExpressionContext)_localctx).variable = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(317);
			match(ATTRIBUTION);
			setState(318);
			expr(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssigAggrContext extends ParserRuleContext {
		public Token variable;
		public Token func;
		public Token val;
		public TerminalNode ATTRIBUTION() { return getToken(datalogParser.ATTRIBUTION, 0); }
		public TerminalNode LEFT_PAREN() { return getToken(datalogParser.LEFT_PAREN, 0); }
		public TerminalNode RIGHT_PAREN() { return getToken(datalogParser.RIGHT_PAREN, 0); }
		public List<TerminalNode> ID() { return getTokens(datalogParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(datalogParser.ID, i);
		}
		public TerminalNode MIN() { return getToken(datalogParser.MIN, 0); }
		public TerminalNode MAX() { return getToken(datalogParser.MAX, 0); }
		public TerminalNode SUM() { return getToken(datalogParser.SUM, 0); }
		public TerminalNode COUNT() { return getToken(datalogParser.COUNT, 0); }
		public AssigAggrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assigAggr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterAssigAggr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitAssigAggr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitAssigAggr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssigAggrContext assigAggr() throws RecognitionException {
		AssigAggrContext _localctx = new AssigAggrContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_assigAggr);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(320);
			((AssigAggrContext)_localctx).variable = match(ID);
			setState(321);
			match(ATTRIBUTION);
			setState(322);
			((AssigAggrContext)_localctx).func = _input.LT(1);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << MIN) | (1L << MAX) | (1L << SUM) | (1L << COUNT))) != 0)) ) {
				((AssigAggrContext)_localctx).func = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(323);
			match(LEFT_PAREN);
			setState(324);
			((AssigAggrContext)_localctx).val = match(ID);
			setState(325);
			match(RIGHT_PAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Assig_aggrContext extends ParserRuleContext {
		public Token attribute;
		public Token aggr;
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public IdListContext idList() {
			return getRuleContext(IdListContext.class,0);
		}
		public TerminalNode ID() { return getToken(datalogParser.ID, 0); }
		public TerminalNode QUALIFIED_ID() { return getToken(datalogParser.QUALIFIED_ID, 0); }
		public TerminalNode MIN() { return getToken(datalogParser.MIN, 0); }
		public TerminalNode MAX() { return getToken(datalogParser.MAX, 0); }
		public TerminalNode SUM() { return getToken(datalogParser.SUM, 0); }
		public Assig_aggrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assig_aggr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterAssig_aggr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitAssig_aggr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitAssig_aggr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Assig_aggrContext assig_aggr() throws RecognitionException {
		Assig_aggrContext _localctx = new Assig_aggrContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_assig_aggr);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(327);
			((Assig_aggrContext)_localctx).attribute = _input.LT(1);
			_la = _input.LA(1);
			if ( !(_la==ID || _la==QUALIFIED_ID) ) {
				((Assig_aggrContext)_localctx).attribute = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(328);
			match(ATTRIBUTION);
			setState(329);
			((Assig_aggrContext)_localctx).aggr = _input.LT(1);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << MIN) | (1L << MAX) | (1L << SUM))) != 0)) ) {
				((Assig_aggrContext)_localctx).aggr = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(330);
			match(LEFT_PAREN);
			setState(331);
			expr(0);
			setState(332);
			match(RIGHT_PAREN);
			setState(333);
			match(T__0);
			setState(334);
			match(T__1);
			setState(335);
			idList();
			setState(336);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class List_identifiersContext extends ParserRuleContext {
		public List<TerminalNode> QUALIFIED_ID() { return getTokens(datalogParser.QUALIFIED_ID); }
		public TerminalNode QUALIFIED_ID(int i) {
			return getToken(datalogParser.QUALIFIED_ID, i);
		}
		public List_identifiersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_list_identifiers; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterList_identifiers(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitList_identifiers(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitList_identifiers(this);
			else return visitor.visitChildren(this);
		}
	}

	public final List_identifiersContext list_identifiers() throws RecognitionException {
		List_identifiersContext _localctx = new List_identifiersContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_list_identifiers);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(342);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,23,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(338);
					match(QUALIFIED_ID);
					setState(339);
					match(COMMA);
					}
					} 
				}
				setState(344);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,23,_ctx);
			}
			setState(345);
			match(QUALIFIED_ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	 
		public ExprContext() { }
		public void copyFrom(ExprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class Expr_intContext extends ExprContext {
		public TerminalNode INT() { return getToken(datalogParser.INT, 0); }
		public Expr_intContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterExpr_int(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitExpr_int(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitExpr_int(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class Expr_floatContext extends ExprContext {
		public TerminalNode FLOAT() { return getToken(datalogParser.FLOAT, 0); }
		public Expr_floatContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterExpr_float(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitExpr_float(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitExpr_float(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class Expr_varContext extends ExprContext {
		public TerminalNode ID() { return getToken(datalogParser.ID, 0); }
		public Expr_varContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterExpr_var(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitExpr_var(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitExpr_var(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class Expr_tableidContext extends ExprContext {
		public Token table;
		public TerminalNode QUALIFIED_ID() { return getToken(datalogParser.QUALIFIED_ID, 0); }
		public Expr_tableidContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterExpr_tableid(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitExpr_tableid(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitExpr_tableid(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class Expr_parensContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public Expr_parensContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterExpr_parens(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitExpr_parens(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitExpr_parens(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class Expr_mdContext extends ExprContext {
		public Token op;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public Expr_mdContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterExpr_md(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitExpr_md(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitExpr_md(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class Expr_pmContext extends ExprContext {
		public Token op;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public Expr_pmContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterExpr_pm(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitExpr_pm(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitExpr_pm(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class Exp_aggContext extends ExprContext {
		public Token aggr;
		public List_identifiersContext list_identifiers() {
			return getRuleContext(List_identifiersContext.class,0);
		}
		public TerminalNode MIN() { return getToken(datalogParser.MIN, 0); }
		public TerminalNode MAX() { return getToken(datalogParser.MAX, 0); }
		public TerminalNode SUM() { return getToken(datalogParser.SUM, 0); }
		public Exp_aggContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterExp_agg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitExp_agg(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitExp_agg(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 64;
		enterRecursionRule(_localctx, 64, RULE_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(363);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
				{
				_localctx = new Expr_intContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(348);
				match(INT);
				}
				break;
			case FLOAT:
				{
				_localctx = new Expr_floatContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(349);
				match(FLOAT);
				}
				break;
			case ID:
				{
				_localctx = new Expr_varContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(350);
				match(ID);
				}
				break;
			case QUALIFIED_ID:
				{
				_localctx = new Expr_tableidContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(351);
				((Expr_tableidContext)_localctx).table = match(QUALIFIED_ID);
				}
				break;
			case MIN:
			case MAX:
			case SUM:
				{
				_localctx = new Exp_aggContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(352);
				((Exp_aggContext)_localctx).aggr = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << MIN) | (1L << MAX) | (1L << SUM))) != 0)) ) {
					((Exp_aggContext)_localctx).aggr = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(353);
				match(LEFT_PAREN);
				setState(354);
				match(T__1);
				setState(355);
				list_identifiers();
				setState(356);
				match(T__2);
				setState(357);
				match(RIGHT_PAREN);
				}
				break;
			case LEFT_PAREN:
				{
				_localctx = new Expr_parensContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(359);
				match(LEFT_PAREN);
				setState(360);
				expr(0);
				setState(361);
				match(RIGHT_PAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(373);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,26,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(371);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,25,_ctx) ) {
					case 1:
						{
						_localctx = new Expr_mdContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(365);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(366);
						((Expr_mdContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__3 || _la==MULTIPLY) ) {
							((Expr_mdContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(367);
						expr(9);
						}
						break;
					case 2:
						{
						_localctx = new Expr_pmContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(368);
						if (!(precpred(_ctx, 7))) throw new FailedPredicateException(this, "precpred(_ctx, 7)");
						setState(369);
						((Expr_pmContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__4 || _la==ADD) ) {
							((Expr_pmContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(370);
						expr(8);
						}
						break;
					}
					} 
				}
				setState(375);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,26,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class ValueListContext extends ParserRuleContext {
		public List<TerminalNode> STRING() { return getTokens(datalogParser.STRING); }
		public TerminalNode STRING(int i) {
			return getToken(datalogParser.STRING, i);
		}
		public List<TerminalNode> INT() { return getTokens(datalogParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(datalogParser.INT, i);
		}
		public List<TerminalNode> FLOAT() { return getTokens(datalogParser.FLOAT); }
		public TerminalNode FLOAT(int i) {
			return getToken(datalogParser.FLOAT, i);
		}
		public List<TerminalNode> COMMA() { return getTokens(datalogParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(datalogParser.COMMA, i);
		}
		public ValueListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_valueList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).enterValueList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof datalogListener ) ((datalogListener)listener).exitValueList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof datalogVisitor ) return ((datalogVisitor<? extends T>)visitor).visitValueList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValueListContext valueList() throws RecognitionException {
		ValueListContext _localctx = new ValueListContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_valueList);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(380);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,27,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(376);
					_la = _input.LA(1);
					if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << STRING) | (1L << FLOAT) | (1L << INT))) != 0)) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(377);
					match(COMMA);
					}
					} 
				}
				setState(382);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,27,_ctx);
			}
			setState(383);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << STRING) | (1L << FLOAT) | (1L << INT))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 32:
			return expr_sempred((ExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 8);
		case 1:
			return precpred(_ctx, 7);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3\63\u0184\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\3\2\3\2\3\2\3\2\3\2\3\2\3\2\5\2N\n\2\3\2\3\2\3\2\3\2"+
		"\5\2T\n\2\3\2\3\2\3\2\3\2\5\2Z\n\2\3\2\3\2\3\2\3\2\5\2`\n\2\3\2\3\2\3"+
		"\2\3\2\5\2f\n\2\3\2\3\2\3\2\3\2\3\3\3\3\3\3\3\3\3\3\3\3\3\4\6\4s\n\4\r"+
		"\4\16\4t\3\5\3\5\3\5\3\5\3\5\3\5\3\6\6\6~\n\6\r\6\16\6\177\3\7\3\7\3\7"+
		"\3\7\3\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\b\3\t\7\t\u0090\n\t\f\t\16\t\u0093"+
		"\13\t\3\n\3\n\3\n\3\n\3\n\3\n\3\13\7\13\u009c\n\13\f\13\16\13\u009f\13"+
		"\13\3\f\3\f\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r\3\r\3\16\7\16\u00ad\n\16\f"+
		"\16\16\16\u00b0\13\16\3\17\3\17\3\17\3\17\3\17\3\17\3\20\7\20\u00b9\n"+
		"\20\f\20\16\20\u00bc\13\20\3\21\3\21\3\21\3\21\3\21\3\21\3\22\3\22\3\22"+
		"\3\22\3\22\3\22\3\22\3\23\3\23\3\23\3\23\3\23\3\24\3\24\3\24\7\24\u00d3"+
		"\n\24\f\24\16\24\u00d6\13\24\3\24\3\24\3\25\3\25\3\26\3\26\3\26\7\26\u00df"+
		"\n\26\f\26\16\26\u00e2\13\26\3\26\3\26\3\27\3\27\7\27\u00e8\n\27\f\27"+
		"\16\27\u00eb\13\27\3\27\3\27\3\30\3\30\3\30\3\30\5\30\u00f3\n\30\3\31"+
		"\5\31\u00f6\n\31\3\31\3\31\3\31\3\31\3\31\5\31\u00fd\n\31\3\31\3\31\3"+
		"\32\5\32\u0102\n\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\5\32\u010b\n\32"+
		"\3\32\3\32\3\32\3\32\3\32\3\33\5\33\u0113\n\33\3\33\3\33\3\33\3\33\3\33"+
		"\3\33\3\33\3\33\3\33\3\33\3\33\3\33\3\34\5\34\u0122\n\34\3\34\3\34\3\34"+
		"\3\34\3\34\3\34\3\34\3\34\3\34\3\34\3\34\5\34\u012f\n\34\3\34\3\34\3\34"+
		"\3\34\3\34\3\34\3\34\3\34\3\34\3\35\6\35\u013b\n\35\r\35\16\35\u013c\3"+
		"\36\3\36\3\36\3\36\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3 \3 \3 \3 \3 \3"+
		" \3 \3 \3 \3 \3 \3!\3!\7!\u0157\n!\f!\16!\u015a\13!\3!\3!\3\"\3\"\3\""+
		"\3\"\3\"\3\"\3\"\3\"\3\"\3\"\3\"\3\"\3\"\3\"\3\"\3\"\5\"\u016e\n\"\3\""+
		"\3\"\3\"\3\"\3\"\3\"\7\"\u0176\n\"\f\"\16\"\u0179\13\"\3#\3#\7#\u017d"+
		"\n#\f#\16#\u0180\13#\3#\3#\3#\2\3B$\2\4\6\b\n\f\16\20\22\24\26\30\32\34"+
		"\36 \"$&(*,.\60\62\64\668:<>@BD\2\t\4\2--/\61\3\2-.\3\2\27\32\3\2\27\31"+
		"\4\2\6\6\20\20\4\2\7\7\21\21\3\2/\61\u0183\2F\3\2\2\2\4k\3\2\2\2\6r\3"+
		"\2\2\2\bv\3\2\2\2\n}\3\2\2\2\f\u0081\3\2\2\2\16\u0089\3\2\2\2\20\u0091"+
		"\3\2\2\2\22\u0094\3\2\2\2\24\u009d\3\2\2\2\26\u00a0\3\2\2\2\30\u00a6\3"+
		"\2\2\2\32\u00ae\3\2\2\2\34\u00b1\3\2\2\2\36\u00ba\3\2\2\2 \u00bd\3\2\2"+
		"\2\"\u00c3\3\2\2\2$\u00ca\3\2\2\2&\u00d4\3\2\2\2(\u00d9\3\2\2\2*\u00e0"+
		"\3\2\2\2,\u00e9\3\2\2\2.\u00f2\3\2\2\2\60\u00f5\3\2\2\2\62\u0101\3\2\2"+
		"\2\64\u0112\3\2\2\2\66\u0121\3\2\2\28\u013a\3\2\2\2:\u013e\3\2\2\2<\u0142"+
		"\3\2\2\2>\u0149\3\2\2\2@\u0158\3\2\2\2B\u016d\3\2\2\2D\u017e\3\2\2\2F"+
		"G\7\33\2\2GH\7\r\2\2HI\5\6\4\2IJ\7\34\2\2JM\7\r\2\2KN\5\n\6\2LN\5\f\7"+
		"\2MK\3\2\2\2ML\3\2\2\2NO\3\2\2\2OP\7\35\2\2PS\7\r\2\2QT\5\20\t\2RT\5\22"+
		"\n\2SQ\3\2\2\2SR\3\2\2\2TU\3\2\2\2UV\7\36\2\2VY\7\r\2\2WZ\5\24\13\2XZ"+
		"\5\26\f\2YW\3\2\2\2YX\3\2\2\2Z[\3\2\2\2[\\\7\37\2\2\\_\7\r\2\2]`\5\32"+
		"\16\2^`\5\34\17\2_]\3\2\2\2_^\3\2\2\2`a\3\2\2\2ab\7 \2\2be\7\r\2\2cf\5"+
		"\36\20\2df\5 \21\2ec\3\2\2\2ed\3\2\2\2fg\3\2\2\2gh\7!\2\2hi\7\r\2\2ij"+
		"\58\35\2j\3\3\2\2\2kl\7-\2\2lm\7\13\2\2mn\5,\27\2no\7\f\2\2op\7\t\2\2"+
		"p\5\3\2\2\2qs\5\4\3\2rq\3\2\2\2st\3\2\2\2tr\3\2\2\2tu\3\2\2\2u\7\3\2\2"+
		"\2vw\7-\2\2wx\7\13\2\2xy\5D#\2yz\7\f\2\2z{\7\t\2\2{\t\3\2\2\2|~\5\b\5"+
		"\2}|\3\2\2\2~\177\3\2\2\2\177}\3\2\2\2\177\u0080\3\2\2\2\u0080\13\3\2"+
		"\2\2\u0081\u0082\7\23\2\2\u0082\u0083\7\"\2\2\u0083\u0084\7#\2\2\u0084"+
		"\u0085\7%\2\2\u0085\u0086\7/\2\2\u0086\u0087\7/\2\2\u0087\u0088\7/\2\2"+
		"\u0088\r\3\2\2\2\u0089\u008a\5$\23\2\u008a\u008b\7\16\2\2\u008b\u008c"+
		"\5&\24\2\u008c\u008d\7\t\2\2\u008d\17\3\2\2\2\u008e\u0090\5\16\b\2\u008f"+
		"\u008e\3\2\2\2\u0090\u0093\3\2\2\2\u0091\u008f\3\2\2\2\u0091\u0092\3\2"+
		"\2\2\u0092\21\3\2\2\2\u0093\u0091\3\2\2\2\u0094\u0095\7\23\2\2\u0095\u0096"+
		"\7\"\2\2\u0096\u0097\7#\2\2\u0097\u0098\7$\2\2\u0098\u0099\7/\2\2\u0099"+
		"\23\3\2\2\2\u009a\u009c\5\16\b\2\u009b\u009a\3\2\2\2\u009c\u009f\3\2\2"+
		"\2\u009d\u009b\3\2\2\2\u009d\u009e\3\2\2\2\u009e\25\3\2\2\2\u009f\u009d"+
		"\3\2\2\2\u00a0\u00a1\7\23\2\2\u00a1\u00a2\7\"\2\2\u00a2\u00a3\7#\2\2\u00a3"+
		"\u00a4\7$\2\2\u00a4\u00a5\7/\2\2\u00a5\27\3\2\2\2\u00a6\u00a7\7\22\2\2"+
		"\u00a7\u00a8\7\16\2\2\u00a8\u00a9\5&\24\2\u00a9\u00aa\7\t\2\2\u00aa\31"+
		"\3\2\2\2\u00ab\u00ad\5\30\r\2\u00ac\u00ab\3\2\2\2\u00ad\u00b0\3\2\2\2"+
		"\u00ae\u00ac\3\2\2\2\u00ae\u00af\3\2\2\2\u00af\33\3\2\2\2\u00b0\u00ae"+
		"\3\2\2\2\u00b1\u00b2\7\23\2\2\u00b2\u00b3\7\"\2\2\u00b3\u00b4\7#\2\2\u00b4"+
		"\u00b5\7$\2\2\u00b5\u00b6\7/\2\2\u00b6\35\3\2\2\2\u00b7\u00b9\5\16\b\2"+
		"\u00b8\u00b7\3\2\2\2\u00b9\u00bc\3\2\2\2\u00ba\u00b8\3\2\2\2\u00ba\u00bb"+
		"\3\2\2\2\u00bb\37\3\2\2\2\u00bc\u00ba\3\2\2\2\u00bd\u00be\7\23\2\2\u00be"+
		"\u00bf\7\"\2\2\u00bf\u00c0\7#\2\2\u00c0\u00c1\7$\2\2\u00c1\u00c2\7/\2"+
		"\2\u00c2!\3\2\2\2\u00c3\u00c4\7-\2\2\u00c4\u00c5\7\13\2\2\u00c5\u00c6"+
		"\5*\26\2\u00c6\u00c7\7\b\2\2\u00c7\u00c8\7-\2\2\u00c8\u00c9\7\f\2\2\u00c9"+
		"#\3\2\2\2\u00ca\u00cb\7-\2\2\u00cb\u00cc\7\13\2\2\u00cc\u00cd\5*\26\2"+
		"\u00cd\u00ce\7\f\2\2\u00ce%\3\2\2\2\u00cf\u00d0\5$\23\2\u00d0\u00d1\7"+
		"\b\2\2\u00d1\u00d3\3\2\2\2\u00d2\u00cf\3\2\2\2\u00d3\u00d6\3\2\2\2\u00d4"+
		"\u00d2\3\2\2\2\u00d4\u00d5\3\2\2\2\u00d5\u00d7\3\2\2\2\u00d6\u00d4\3\2"+
		"\2\2\u00d7\u00d8\5$\23\2\u00d8\'\3\2\2\2\u00d9\u00da\t\2\2\2\u00da)\3"+
		"\2\2\2\u00db\u00dc\5(\25\2\u00dc\u00dd\7\b\2\2\u00dd\u00df\3\2\2\2\u00de"+
		"\u00db\3\2\2\2\u00df\u00e2\3\2\2\2\u00e0\u00de\3\2\2\2\u00e0\u00e1\3\2"+
		"\2\2\u00e1\u00e3\3\2\2\2\u00e2\u00e0\3\2\2\2\u00e3\u00e4\5(\25\2\u00e4"+
		"+\3\2\2\2\u00e5\u00e6\7-\2\2\u00e6\u00e8\7\b\2\2\u00e7\u00e5\3\2\2\2\u00e8"+
		"\u00eb\3\2\2\2\u00e9\u00e7\3\2\2\2\u00e9\u00ea\3\2\2\2\u00ea\u00ec\3\2"+
		"\2\2\u00eb\u00e9\3\2\2\2\u00ec\u00ed\7-\2\2\u00ed-\3\2\2\2\u00ee\u00f3"+
		"\5\60\31\2\u00ef\u00f3\5\62\32\2\u00f0\u00f3\5\64\33\2\u00f1\u00f3\5\66"+
		"\34\2\u00f2\u00ee\3\2\2\2\u00f2\u00ef\3\2\2\2\u00f2\u00f0\3\2\2\2\u00f2"+
		"\u00f1\3\2\2\2\u00f3/\3\2\2\2\u00f4\u00f6\7\n\2\2\u00f5\u00f4\3\2\2\2"+
		"\u00f5\u00f6\3\2\2\2\u00f6\u00f7\3\2\2\2\u00f7\u00f8\5$\23\2\u00f8\u00f9"+
		"\7\16\2\2\u00f9\u00fc\5&\24\2\u00fa\u00fb\7\b\2\2\u00fb\u00fd\5:\36\2"+
		"\u00fc\u00fa\3\2\2\2\u00fc\u00fd\3\2\2\2\u00fd\u00fe\3\2\2\2\u00fe\u00ff"+
		"\7\t\2\2\u00ff\61\3\2\2\2\u0100\u0102\7\n\2\2\u0101\u0100\3\2\2\2\u0101"+
		"\u0102\3\2\2\2\u0102\u0103\3\2\2\2\u0103\u0104\5\"\22\2\u0104\u0105\7"+
		"\16\2\2\u0105\u0106\7\24\2\2\u0106\u0107\7\13\2\2\u0107\u010a\5&\24\2"+
		"\u0108\u0109\7\b\2\2\u0109\u010b\5,\27\2\u010a\u0108\3\2\2\2\u010a\u010b"+
		"\3\2\2\2\u010b\u010c\3\2\2\2\u010c\u010d\7\b\2\2\u010d\u010e\5<\37\2\u010e"+
		"\u010f\7\f\2\2\u010f\u0110\7\t\2\2\u0110\63\3\2\2\2\u0111\u0113\7\n\2"+
		"\2\u0112\u0111\3\2\2\2\u0112\u0113\3\2\2\2\u0113\u0114\3\2\2\2\u0114\u0115"+
		"\5$\23\2\u0115\u0116\7\16\2\2\u0116\u0117\7\25\2\2\u0117\u0118\7\13\2"+
		"\2\u0118\u0119\5$\23\2\u0119\u011a\7\b\2\2\u011a\u011b\5$\23\2\u011b\u011c"+
		"\7\b\2\2\u011c\u011d\5:\36\2\u011d\u011e\7\f\2\2\u011e\u011f\7\t\2\2\u011f"+
		"\65\3\2\2\2\u0120\u0122\7\n\2\2\u0121\u0120\3\2\2\2\u0121\u0122\3\2\2"+
		"\2\u0122\u0123\3\2\2\2\u0123\u0124\5$\23\2\u0124\u0125\7\16\2\2\u0125"+
		"\u0126\7\26\2\2\u0126\u0127\7\13\2\2\u0127\u0128\5$\23\2\u0128\u0129\7"+
		"\b\2\2\u0129\u012a\5$\23\2\u012a\u012b\7\b\2\2\u012b\u012e\7\61\2\2\u012c"+
		"\u012d\7\b\2\2\u012d\u012f\5,\27\2\u012e\u012c\3\2\2\2\u012e\u012f\3\2"+
		"\2\2\u012f\u0130\3\2\2\2\u0130\u0131\7\b\2\2\u0131\u0132\5:\36\2\u0132"+
		"\u0133\7\b\2\2\u0133\u0134\5<\37\2\u0134\u0135\7\b\2\2\u0135\u0136\5:"+
		"\36\2\u0136\u0137\7\f\2\2\u0137\u0138\7\t\2\2\u0138\67\3\2\2\2\u0139\u013b"+
		"\5.\30\2\u013a\u0139\3\2\2\2\u013b\u013c\3\2\2\2\u013c\u013a\3\2\2\2\u013c"+
		"\u013d\3\2\2\2\u013d9\3\2\2\2\u013e\u013f\t\3\2\2\u013f\u0140\7\17\2\2"+
		"\u0140\u0141\5B\"\2\u0141;\3\2\2\2\u0142\u0143\7-\2\2\u0143\u0144\7\17"+
		"\2\2\u0144\u0145\t\4\2\2\u0145\u0146\7\13\2\2\u0146\u0147\7-\2\2\u0147"+
		"\u0148\7\f\2\2\u0148=\3\2\2\2\u0149\u014a\t\3\2\2\u014a\u014b\7\17\2\2"+
		"\u014b\u014c\t\5\2\2\u014c\u014d\7\13\2\2\u014d\u014e\5B\"\2\u014e\u014f"+
		"\7\f\2\2\u014f\u0150\7\3\2\2\u0150\u0151\7\4\2\2\u0151\u0152\5,\27\2\u0152"+
		"\u0153\7\5\2\2\u0153?\3\2\2\2\u0154\u0155\7.\2\2\u0155\u0157\7\b\2\2\u0156"+
		"\u0154\3\2\2\2\u0157\u015a\3\2\2\2\u0158\u0156\3\2\2\2\u0158\u0159\3\2"+
		"\2\2\u0159\u015b\3\2\2\2\u015a\u0158\3\2\2\2\u015b\u015c\7.\2\2\u015c"+
		"A\3\2\2\2\u015d\u015e\b\"\1\2\u015e\u016e\7\61\2\2\u015f\u016e\7\60\2"+
		"\2\u0160\u016e\7-\2\2\u0161\u016e\7.\2\2\u0162\u0163\t\5\2\2\u0163\u0164"+
		"\7\13\2\2\u0164\u0165\7\4\2\2\u0165\u0166\5@!\2\u0166\u0167\7\5\2\2\u0167"+
		"\u0168\7\f\2\2\u0168\u016e\3\2\2\2\u0169\u016a\7\13\2\2\u016a\u016b\5"+
		"B\"\2\u016b\u016c\7\f\2\2\u016c\u016e\3\2\2\2\u016d\u015d\3\2\2\2\u016d"+
		"\u015f\3\2\2\2\u016d\u0160\3\2\2\2\u016d\u0161\3\2\2\2\u016d\u0162\3\2"+
		"\2\2\u016d\u0169\3\2\2\2\u016e\u0177\3\2\2\2\u016f\u0170\f\n\2\2\u0170"+
		"\u0171\t\6\2\2\u0171\u0176\5B\"\13\u0172\u0173\f\t\2\2\u0173\u0174\t\7"+
		"\2\2\u0174\u0176\5B\"\n\u0175\u016f\3\2\2\2\u0175\u0172\3\2\2\2\u0176"+
		"\u0179\3\2\2\2\u0177\u0175\3\2\2\2\u0177\u0178\3\2\2\2\u0178C\3\2\2\2"+
		"\u0179\u0177\3\2\2\2\u017a\u017b\t\b\2\2\u017b\u017d\7\b\2\2\u017c\u017a"+
		"\3\2\2\2\u017d\u0180\3\2\2\2\u017e\u017c\3\2\2\2\u017e\u017f\3\2\2\2\u017f"+
		"\u0181\3\2\2\2\u0180\u017e\3\2\2\2\u0181\u0182\t\b\2\2\u0182E\3\2\2\2"+
		"\36MSY_et\177\u0091\u009d\u00ae\u00ba\u00d4\u00e0\u00e9\u00f2\u00f5\u00fc"+
		"\u0101\u010a\u0112\u0121\u012e\u013c\u0158\u016d\u0175\u0177\u017e";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}