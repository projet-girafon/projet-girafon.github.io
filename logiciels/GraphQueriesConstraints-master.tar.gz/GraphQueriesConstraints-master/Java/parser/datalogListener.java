// Generated from /home/chabin/workspace/GraphQueriesConstraints/Java/parser/datalog.g4 by ANTLR 4.6
package parser;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link datalogParser}.
 */
public interface datalogListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link datalogParser#datalogProgram}.
	 * @param ctx the parse tree
	 */
	void enterDatalogProgram(datalogParser.DatalogProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#datalogProgram}.
	 * @param ctx the parse tree
	 */
	void exitDatalogProgram(datalogParser.DatalogProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#scheme}.
	 * @param ctx the parse tree
	 */
	void enterScheme(datalogParser.SchemeContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#scheme}.
	 * @param ctx the parse tree
	 */
	void exitScheme(datalogParser.SchemeContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#schemeList}.
	 * @param ctx the parse tree
	 */
	void enterSchemeList(datalogParser.SchemeListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#schemeList}.
	 * @param ctx the parse tree
	 */
	void exitSchemeList(datalogParser.SchemeListContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#fact}.
	 * @param ctx the parse tree
	 */
	void enterFact(datalogParser.FactContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#fact}.
	 * @param ctx the parse tree
	 */
	void exitFact(datalogParser.FactContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#factList}.
	 * @param ctx the parse tree
	 */
	void enterFactList(datalogParser.FactListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#factList}.
	 * @param ctx the parse tree
	 */
	void exitFactList(datalogParser.FactListContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#importFacts}.
	 * @param ctx the parse tree
	 */
	void enterImportFacts(datalogParser.ImportFactsContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#importFacts}.
	 * @param ctx the parse tree
	 */
	void exitImportFacts(datalogParser.ImportFactsContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#ruleA}.
	 * @param ctx the parse tree
	 */
	void enterRuleA(datalogParser.RuleAContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#ruleA}.
	 * @param ctx the parse tree
	 */
	void exitRuleA(datalogParser.RuleAContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#infRulesList}.
	 * @param ctx the parse tree
	 */
	void enterInfRulesList(datalogParser.InfRulesListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#infRulesList}.
	 * @param ctx the parse tree
	 */
	void exitInfRulesList(datalogParser.InfRulesListContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#importInfRules}.
	 * @param ctx the parse tree
	 */
	void enterImportInfRules(datalogParser.ImportInfRulesContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#importInfRules}.
	 * @param ctx the parse tree
	 */
	void exitImportInfRules(datalogParser.ImportInfRulesContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#posRulesList}.
	 * @param ctx the parse tree
	 */
	void enterPosRulesList(datalogParser.PosRulesListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#posRulesList}.
	 * @param ctx the parse tree
	 */
	void exitPosRulesList(datalogParser.PosRulesListContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#importPosRules}.
	 * @param ctx the parse tree
	 */
	void enterImportPosRules(datalogParser.ImportPosRulesContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#importPosRules}.
	 * @param ctx the parse tree
	 */
	void exitImportPosRules(datalogParser.ImportPosRulesContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#negRuleA}.
	 * @param ctx the parse tree
	 */
	void enterNegRuleA(datalogParser.NegRuleAContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#negRuleA}.
	 * @param ctx the parse tree
	 */
	void exitNegRuleA(datalogParser.NegRuleAContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#negRulesList}.
	 * @param ctx the parse tree
	 */
	void enterNegRulesList(datalogParser.NegRulesListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#negRulesList}.
	 * @param ctx the parse tree
	 */
	void exitNegRulesList(datalogParser.NegRulesListContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#importNegRules}.
	 * @param ctx the parse tree
	 */
	void enterImportNegRules(datalogParser.ImportNegRulesContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#importNegRules}.
	 * @param ctx the parse tree
	 */
	void exitImportNegRules(datalogParser.ImportNegRulesContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#keyRulesList}.
	 * @param ctx the parse tree
	 */
	void enterKeyRulesList(datalogParser.KeyRulesListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#keyRulesList}.
	 * @param ctx the parse tree
	 */
	void exitKeyRulesList(datalogParser.KeyRulesListContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#importKeyRules}.
	 * @param ctx the parse tree
	 */
	void enterImportKeyRules(datalogParser.ImportKeyRulesContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#importKeyRules}.
	 * @param ctx the parse tree
	 */
	void exitImportKeyRules(datalogParser.ImportKeyRulesContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#aggQueryHeadAtom}.
	 * @param ctx the parse tree
	 */
	void enterAggQueryHeadAtom(datalogParser.AggQueryHeadAtomContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#aggQueryHeadAtom}.
	 * @param ctx the parse tree
	 */
	void exitAggQueryHeadAtom(datalogParser.AggQueryHeadAtomContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterAtom(datalogParser.AtomContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitAtom(datalogParser.AtomContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#atomList}.
	 * @param ctx the parse tree
	 */
	void enterAtomList(datalogParser.AtomListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#atomList}.
	 * @param ctx the parse tree
	 */
	void exitAtomList(datalogParser.AtomListContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#element}.
	 * @param ctx the parse tree
	 */
	void enterElement(datalogParser.ElementContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#element}.
	 * @param ctx the parse tree
	 */
	void exitElement(datalogParser.ElementContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#elementList}.
	 * @param ctx the parse tree
	 */
	void enterElementList(datalogParser.ElementListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#elementList}.
	 * @param ctx the parse tree
	 */
	void exitElementList(datalogParser.ElementListContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#idList}.
	 * @param ctx the parse tree
	 */
	void enterIdList(datalogParser.IdListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#idList}.
	 * @param ctx the parse tree
	 */
	void exitIdList(datalogParser.IdListContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#query}.
	 * @param ctx the parse tree
	 */
	void enterQuery(datalogParser.QueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#query}.
	 * @param ctx the parse tree
	 */
	void exitQuery(datalogParser.QueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#simpleQuery}.
	 * @param ctx the parse tree
	 */
	void enterSimpleQuery(datalogParser.SimpleQueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#simpleQuery}.
	 * @param ctx the parse tree
	 */
	void exitSimpleQuery(datalogParser.SimpleQueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#aggQuery}.
	 * @param ctx the parse tree
	 */
	void enterAggQuery(datalogParser.AggQueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#aggQuery}.
	 * @param ctx the parse tree
	 */
	void exitAggQuery(datalogParser.AggQueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#mapQuery}.
	 * @param ctx the parse tree
	 */
	void enterMapQuery(datalogParser.MapQueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#mapQuery}.
	 * @param ctx the parse tree
	 */
	void exitMapQuery(datalogParser.MapQueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#betaQuery}.
	 * @param ctx the parse tree
	 */
	void enterBetaQuery(datalogParser.BetaQueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#betaQuery}.
	 * @param ctx the parse tree
	 */
	void exitBetaQuery(datalogParser.BetaQueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#queryList}.
	 * @param ctx the parse tree
	 */
	void enterQueryList(datalogParser.QueryListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#queryList}.
	 * @param ctx the parse tree
	 */
	void exitQueryList(datalogParser.QueryListContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#assigExpression}.
	 * @param ctx the parse tree
	 */
	void enterAssigExpression(datalogParser.AssigExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#assigExpression}.
	 * @param ctx the parse tree
	 */
	void exitAssigExpression(datalogParser.AssigExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#assigAggr}.
	 * @param ctx the parse tree
	 */
	void enterAssigAggr(datalogParser.AssigAggrContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#assigAggr}.
	 * @param ctx the parse tree
	 */
	void exitAssigAggr(datalogParser.AssigAggrContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#assig_aggr}.
	 * @param ctx the parse tree
	 */
	void enterAssig_aggr(datalogParser.Assig_aggrContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#assig_aggr}.
	 * @param ctx the parse tree
	 */
	void exitAssig_aggr(datalogParser.Assig_aggrContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#list_identifiers}.
	 * @param ctx the parse tree
	 */
	void enterList_identifiers(datalogParser.List_identifiersContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#list_identifiers}.
	 * @param ctx the parse tree
	 */
	void exitList_identifiers(datalogParser.List_identifiersContext ctx);
	/**
	 * Enter a parse tree produced by the {@code expr_int}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr_int(datalogParser.Expr_intContext ctx);
	/**
	 * Exit a parse tree produced by the {@code expr_int}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr_int(datalogParser.Expr_intContext ctx);
	/**
	 * Enter a parse tree produced by the {@code expr_float}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr_float(datalogParser.Expr_floatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code expr_float}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr_float(datalogParser.Expr_floatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code expr_var}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr_var(datalogParser.Expr_varContext ctx);
	/**
	 * Exit a parse tree produced by the {@code expr_var}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr_var(datalogParser.Expr_varContext ctx);
	/**
	 * Enter a parse tree produced by the {@code expr_tableid}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr_tableid(datalogParser.Expr_tableidContext ctx);
	/**
	 * Exit a parse tree produced by the {@code expr_tableid}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr_tableid(datalogParser.Expr_tableidContext ctx);
	/**
	 * Enter a parse tree produced by the {@code expr_parens}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr_parens(datalogParser.Expr_parensContext ctx);
	/**
	 * Exit a parse tree produced by the {@code expr_parens}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr_parens(datalogParser.Expr_parensContext ctx);
	/**
	 * Enter a parse tree produced by the {@code expr_md}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr_md(datalogParser.Expr_mdContext ctx);
	/**
	 * Exit a parse tree produced by the {@code expr_md}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr_md(datalogParser.Expr_mdContext ctx);
	/**
	 * Enter a parse tree produced by the {@code expr_pm}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr_pm(datalogParser.Expr_pmContext ctx);
	/**
	 * Exit a parse tree produced by the {@code expr_pm}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr_pm(datalogParser.Expr_pmContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exp_agg}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExp_agg(datalogParser.Exp_aggContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exp_agg}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExp_agg(datalogParser.Exp_aggContext ctx);
	/**
	 * Enter a parse tree produced by {@link datalogParser#valueList}.
	 * @param ctx the parse tree
	 */
	void enterValueList(datalogParser.ValueListContext ctx);
	/**
	 * Exit a parse tree produced by {@link datalogParser#valueList}.
	 * @param ctx the parse tree
	 */
	void exitValueList(datalogParser.ValueListContext ctx);
}