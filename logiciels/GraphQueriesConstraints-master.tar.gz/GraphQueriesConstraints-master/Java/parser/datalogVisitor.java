// Generated from /home/chabin/workspace/GraphQueriesConstraints/Java/parser/datalog.g4 by ANTLR 4.6
package parser;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link datalogParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface datalogVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link datalogParser#datalogProgram}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDatalogProgram(datalogParser.DatalogProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#scheme}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScheme(datalogParser.SchemeContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#schemeList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSchemeList(datalogParser.SchemeListContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#fact}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFact(datalogParser.FactContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#factList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFactList(datalogParser.FactListContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#importFacts}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImportFacts(datalogParser.ImportFactsContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#ruleA}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRuleA(datalogParser.RuleAContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#infRulesList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInfRulesList(datalogParser.InfRulesListContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#importInfRules}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImportInfRules(datalogParser.ImportInfRulesContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#posRulesList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPosRulesList(datalogParser.PosRulesListContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#importPosRules}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImportPosRules(datalogParser.ImportPosRulesContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#negRuleA}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegRuleA(datalogParser.NegRuleAContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#negRulesList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegRulesList(datalogParser.NegRulesListContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#importNegRules}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImportNegRules(datalogParser.ImportNegRulesContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#keyRulesList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeyRulesList(datalogParser.KeyRulesListContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#importKeyRules}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImportKeyRules(datalogParser.ImportKeyRulesContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#aggQueryHeadAtom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggQueryHeadAtom(datalogParser.AggQueryHeadAtomContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtom(datalogParser.AtomContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#atomList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtomList(datalogParser.AtomListContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElement(datalogParser.ElementContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#elementList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElementList(datalogParser.ElementListContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#idList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdList(datalogParser.IdListContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#query}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery(datalogParser.QueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#simpleQuery}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimpleQuery(datalogParser.SimpleQueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#aggQuery}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAggQuery(datalogParser.AggQueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#mapQuery}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMapQuery(datalogParser.MapQueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#betaQuery}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetaQuery(datalogParser.BetaQueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#queryList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQueryList(datalogParser.QueryListContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#assigExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssigExpression(datalogParser.AssigExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#assigAggr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssigAggr(datalogParser.AssigAggrContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#assig_aggr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssig_aggr(datalogParser.Assig_aggrContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#list_identifiers}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList_identifiers(datalogParser.List_identifiersContext ctx);
	/**
	 * Visit a parse tree produced by the {@code expr_int}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr_int(datalogParser.Expr_intContext ctx);
	/**
	 * Visit a parse tree produced by the {@code expr_float}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr_float(datalogParser.Expr_floatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code expr_var}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr_var(datalogParser.Expr_varContext ctx);
	/**
	 * Visit a parse tree produced by the {@code expr_tableid}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr_tableid(datalogParser.Expr_tableidContext ctx);
	/**
	 * Visit a parse tree produced by the {@code expr_parens}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr_parens(datalogParser.Expr_parensContext ctx);
	/**
	 * Visit a parse tree produced by the {@code expr_md}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr_md(datalogParser.Expr_mdContext ctx);
	/**
	 * Visit a parse tree produced by the {@code expr_pm}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr_pm(datalogParser.Expr_pmContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exp_agg}
	 * labeled alternative in {@link datalogParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExp_agg(datalogParser.Exp_aggContext ctx);
	/**
	 * Visit a parse tree produced by {@link datalogParser#valueList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValueList(datalogParser.ValueListContext ctx);
}