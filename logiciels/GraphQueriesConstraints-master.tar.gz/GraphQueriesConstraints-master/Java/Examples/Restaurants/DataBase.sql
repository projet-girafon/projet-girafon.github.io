
CREATE TABLE `rest`.`Connects` (
  `Source` INT NOT NULL,
  `Target` INT NOT NULL,
  `Id` INT NULL,
  `Weight` FLOAT NULL,
  PRIMARY KEY (`Source`, `Target`));

